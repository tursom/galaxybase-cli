# -*- coding    : utf-8 -*-
# @Time         : 2021/3/9 11:21
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
import binascii
import base64
import math
import random

public_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCXgctF+noMbOXv5c8hVef4vE6eK/" \
                 "mwnzEpMoHpZJjphuyTcowsD9DBWe+PrqZOEm1PomzD/" \
                 "TxOn9eMhn9O+w3yuuv8fipMs6OjU6Y+rKLrGJ8aCZpzd7Y5eewQS/" \
                 "0hOGmWtQlLdayJaUT0B0Fpz3yhR7u7vtVhKwbCYYfHxhg1PQIDAQAB"


class RSAUtil:
    @staticmethod
    def parse_public_key(public_key: str):
        # 将DER格式的公钥字符串转换为字节串
        public_key_bytes = binascii.unhexlify(base64.b64decode(public_key).hex())

        offset = 1
        if public_key_bytes[offset] == 0x81:
            offset += 1

        offset += 12 + public_key_bytes[offset + 10]

        # 解析模数
        mod_len = public_key_bytes[offset]
        offset += 1
        mod = public_key_bytes[offset: offset + mod_len]
        offset += mod_len + 1

        # 解析指数
        exp_len = public_key_bytes[offset]
        offset += 1
        exp = public_key_bytes[offset: offset + exp_len]

        # 将模数和指数转换为整数
        n = int.from_bytes(mod, 'big')
        e = int.from_bytes(exp, 'big')

        return e, n

    @staticmethod
    def pkcs1_v1_5_pad(msg: bytes, block_size: int) -> bytes:
        # 计算填充的字节数
        pad_len = block_size - len(msg) - 3
        if pad_len < 0:
            raise ValueError("Plaintext is too long.")
        padding = b'\x00\x02' + bytes([random.randint(1, 255) for _ in range(pad_len)]) + b'\x00'
        return padding + msg

    @staticmethod
    def rsa_encrypt(msg: str, public_key: tuple) -> str:
        e, n = public_key
        block_size = math.ceil(n.bit_length() / 8)
        msg_bytes = msg.encode('utf-8')
        padded_msg = RSAUtil.pkcs1_v1_5_pad(msg_bytes, block_size)
        m = int.from_bytes(padded_msg, 'big')
        c = pow(m, e, n)
        c_bytes = c.to_bytes(block_size, 'big')
        return str(base64.b64encode(c_bytes), encoding='utf-8')

    @staticmethod
    def encrypt(st: str):
        """
        获取加密后的字符

        :param st: 待加密的字符串
        :return:
        """
        return RSAUtil.rsa_encrypt(st, RSAUtil.parse_public_key(public_key))