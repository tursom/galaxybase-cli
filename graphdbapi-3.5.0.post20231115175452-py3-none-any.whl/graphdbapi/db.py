# -*- coding    : utf-8 -*-
# @Time         : 2021/3/9 10:40
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
import json

from typing import Set, Union, List, Dict

from graphdbapi.compat import deprecated
from bolt.routing import OrderedSet,SocketAddress
from graphdbapi import basic_auth
from graphdbapi import GraphDatabase, Driver
from graphdbapi.v1.utils.Assert import Assert
from graphdbapi.v1.graph.GsGraph import GsGraph
from graphdbapi.auth import AuthValidateUtil
from .MetricInfo import MetricInfo
from bolt.message import Param, GraphMethod, TempText
from bolt.exceptions import DatabaseException, ClientException, ServiceUnavailableException
from bolt.compat import urlparse


class GraphDb:
    VOID = TempText.VOID.value
    CLUSTER = "cluster://"

    @staticmethod
    def __judge_load_balancer(driver, strategy):
        from bolt.routing import LoadBalancingStrategy
        from graphdbapi import RoutingDriver
        if not isinstance(driver, RoutingDriver):
            raise ValueError("It's not routingDriver. Load balancing strategy is not needed!")
        if not isinstance(strategy, LoadBalancingStrategy):
            raise ValueError("Unknown balancing strategy '%s'" % strategy.__class__.__name__)

    @staticmethod
    def new_instance(uri, username, password, **config) -> Driver:
        Assert.not_empty_allowed(uri, Param.uri)
        Assert.not_empty_allowed(username, Param.username)
        Assert.not_empty_allowed(password, Param.password)
        config.update({"auth": basic_auth(username, password), "encrypted": False})
        driver = GraphDatabase().driver(uri, **config)
        return driver

    @staticmethod
    @deprecated("Param[uri, username, password, config] will be removed soon")
    def driver(
            driver: Union[Driver, None] = None, graph_name: str = "",
            uri: str = "",  username: str = "", password: str = "", strategy=None, **config
    ) -> GsGraph:
        """
        链接到图服务
            链接方式一: driver + graph_name \n
            链接方式二: graph_name + uri + username + password  后续将移除此方式

        :param driver:      图链接
        :param graph_name:  图名称
        :param uri:         链接地址
        :param username:    用户名
        :param password:    密码
        :return:
        """
        Assert.not_empty_allowed(graph_name, Param.graphName)
        if not driver:
            driver = GraphDb.new_instance(uri, username, password, **config)

        return GraphDb.driver_by_name(driver, graph_name, strategy=strategy)

    @staticmethod
    def get_driver_version() -> str:
        return TempText.CLIENT_VERSION.value

    @staticmethod
    def driver_by_name(driver: Driver, graph_name: str, strategy=None) -> GsGraph:
        Assert.not_empty_allowed(graph_name, Param.graphName)
        with driver.session() as session:
            result = session.run("%s%s" % (GraphDb.VOID, GraphMethod.getGraph.get_index()), {"graphName": graph_name})
            graph_index = result.values()[0][0]

        return GraphDb.__init_gsgraph(graph_index, graph_name, driver, strategy)

    @staticmethod
    def driver_by_index(driver: Driver, graph_index: int, strategy=None) -> GsGraph:
        AuthValidateUtil.is_nonnegative("graph_index", graph_index)
        with driver.session() as session:
            result = session.run("%s%s" % (GraphDb.VOID, GraphMethod.getGraph.get_index()), {"graphIndex": graph_index})
            graph_name = result.values()[0][0]

        return GraphDb.__init_gsgraph(graph_index, graph_name, driver, strategy)

    @staticmethod
    def connect(uri: str, username: str, password: str, **config) -> Driver:
        """
        连接到图服务

        :param uri:        链接地址
        :param username:   用户名
        :param password:   密码
        :return:
        """
        return GraphDb.new_instance(uri, username, password, **config)

    @staticmethod
    def connect_cluster(uris: Union[str, Set[str]], username: str, password: str, **config) -> Driver:
        """

        :param uris: 例如：culster://192.168.0.1:7687,192.168.0.1:7687，或者 {192.168.0.1:7687，192.168.0.2:7687}
        :param username:
        :param password:
        :param config:
        :return:
        """
        driver = None
        uris = GraphDb.__split_uris(uris)

        if isinstance(uris, set):
            if not uris:
                raise ValueError("No address entered!")
            routing_uris = set()
            for uri in uris:
                if len(uri.split(":")) != 2:
                    raise ValueError("Invalid address format `" + uri + "`")
                routing_uris.add(GraphDb.CLUSTER + uri)
            GraphDb.assert_routing_uris(routing_uris)

            for uri in routing_uris:
                driver = GraphDb.new_instance(uri, username, password, **config)
                break
            if not driver:
                raise ServiceUnavailableException(message="Failed to discover an available server")

            servers = driver.remote_address()
            for uri in uris:
                if uri not in servers:
                    driver.close()
                    raise ValueError("Existing address does not belong to the cluster or URI format is wrong!")

            return driver

        raise ValueError("Unsupported type with uris<%s>"%type(uris).__name__)

    @staticmethod
    def driver_by_routing_table(uris: Union[str, Set[str]], username: str, password: str, **config) -> Driver:
        """
        根据指定路由表获取路由driver（不允许使用AutoPartitionLoadBalancingStrategy策略）
        :param uris: 例如：cluster://192.168.0.1:7687,192.168.0.1:7687，或者 {192.168.0.1:7687，192.168.0.2:7687}
        :param username:
        :param password:
        :param config:
        :return:
        """
        driver = None
        uris = GraphDb.__split_uris(uris)

        config["routing_table"] = OrderedSet(map(lambda _: SocketAddress.parse(_), sorted(uris)))
        config["routing_table_flush_delay"] = 3600 * 24 * 365 * 10000

        if isinstance(uris, set):
            if not uris:
                raise ValueError("No address entered!")
            routing_uris = set()
            for uri in uris:
                if len(uri.split(":")) != 2:
                    raise ValueError("Invalid address format `" + uri + "`")
                routing_uris.add(GraphDb.CLUSTER + uri)
            GraphDb.assert_routing_uris(routing_uris)

            for uri in routing_uris:
                driver = GraphDb.new_instance(uri, username, password, **config)
                break
            if not driver:
                raise ServiceUnavailableException(message="Failed to discover an available server")

            return driver

    @staticmethod
    def __split_uris(uris):
        if isinstance(uris, str):
            _parse = urlparse(uris)
            if _parse.scheme != TempText.CLUSTER_URI_SCHEME.value:
                raise ClientException(message="Unsupported URI scheme: %s" % _parse.scheme)
            uris = set(map(lambda _: _.strip(), _parse.netloc.split(",")))
        return uris


    @staticmethod
    def assert_routing_uris(uris: Union[Set[str]]):
        for uri in uris:
            _parse = urlparse(uri)
            if _parse.scheme != TempText.CLUSTER_URI_SCHEME.value:
                raise ClientException(message="Unsupported URI scheme: %s" % _parse.scheme)

    @staticmethod
    def new_graph(driver: Driver, graph_name: str, group_name: str = "", strategy=None) -> GsGraph:
        """
        创建空图

        :param driver:       图链接
        :param graph_name:   图名称
        :param group_name:   所属组（已弃用，下版本移除）
        :return:
        """
        Assert.not_empty_allowed(graph_name, Param.graphName)

        with driver.session() as session:
            parameters = {}
            parameters["graphName"] = graph_name
            result = session.run("%s%s" % (GraphDb.VOID, GraphMethod.newGraph.get_index()), parameters)
            result.records().__next__()
        return GraphDb.__driver(driver=driver, graph_name=graph_name, strategy=strategy)

    @staticmethod
    def graphs(driver: Driver) -> Set[str]:
        """
        获取所有图名称

        :param driver:
        :return:
        """
        with driver.session() as session:
            result = session.run("%s%s" % (GraphDb.VOID, GraphMethod.getGraphs.get_index()), {}).value()[0]
        return set(result.keys())

    @staticmethod
    def graphx_indexs(driver: Driver) -> Dict[str, int]:
        """
        获取图索引

        :param driver:
        :return:
        """
        with driver.session() as session:
            result = session.run("%s%s" % (GraphDb.VOID, GraphMethod.getGraphs.get_index()), {})
        return result.records().__next__()[0]

    @staticmethod
    def metrics(driver: Driver) -> List[MetricInfo]:
        """
        获取节点的metric信息

        :param driver:
        :return:
        """
        with driver.session() as session:
            metrics = []
            result = session.run("%s%s" % (GraphDb.VOID, GraphMethod.metrics.get_index()), {})
            for _ in result:
                records = json.loads(_[0])
                for m in records:
                    obj = MetricInfo(**m)
                    metrics.append(obj)
        return metrics

    @staticmethod
    def __driver(driver: Driver, graph_name: str, strategy=None) -> GsGraph:
        graphs = GraphDb.graphx_indexs(driver)
        if graph_name not in graphs:
            raise DatabaseException("The database was not created: " + graph_name, code="NO_GRAPH")

        return GraphDb.__init_gsgraph(graphs[graph_name], graph_name, driver, strategy)

    @staticmethod
    def __init_gsgraph(graph_index, graph_name, driver, strategy=None) -> GsGraph:
        if strategy:
            GraphDb.__judge_load_balancer(driver, strategy)
            return GsGraph(graph_index, graph_name, driver, strategy=strategy)
        else:
            return GsGraph(graph_index, graph_name, driver)