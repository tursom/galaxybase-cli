from typing import Any
from bolt.exceptions import ClientException
from bolt.message import TipsText


class AuthValidateUtil:
    @staticmethod
    def is_empty(param: str, value: Any):
        if value is None:
            raise ClientException(message=TipsText.FIELD_CAN_NOT_NULL % param)
        if isinstance(value, str) and value.strip() == "":
            raise ClientException(message=TipsText.FIELD_CAN_NOT_EMPTY % param)

    @staticmethod
    def is_nonnegative(param: str, value: int):
        if value < 0:
            raise ClientException(message=TipsText.FIELD_CAN_NOT_NEGATIVE % param)