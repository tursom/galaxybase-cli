#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020/3/31 16:58
# @Author : jimmy
# @File : _graph.py
# @Software: PyCharm

from graphdbapi.compat import xstr, deprecated, Mapping
from bolt.message.utils.IdGenerator import IdGenerator


__all__ = [
    "Graph",
    "Entity",
    "Node",
    "Relationship",
    "Path",
    "Vertex",
    "Edge",
]


class Graph(object):
    """
    Local, self-contained graph object that acts as a container for
    :class:`.Node` and :class:`.Relationship` instances.
    """

    def __init__(self):
        self._nodes = {}
        self._relationships = {}
        self._relationship_types = {}
        self._node_set_view = EntitySetView(self._nodes)
        self._relationship_set_view = EntitySetView(self._relationships)

    @property
    def nodes(self):
        """
        Access a set view of the nodes in this graph.
        """
        return self._node_set_view

    @property
    def relationships(self):
        """
        Access a set view of the relationships in this graph.
        """
        return self._relationship_set_view

    def relationship_type(self, name):
        """
        Obtain a :class:`.Relationship` subclass for a given
        relationship type name.
        """
        try:
            cls = self._relationship_types[name]
        except KeyError:
            cls = self._relationship_types[name] = type(xstr(name), (Relationship,), {})
        return cls

    def put_node(self, n_id, labels='', properties=None, **kwproperties):
        inst = Node(self, n_id)
        inst._label=labels
        inst._update(properties, **kwproperties)
        return inst

    def put_relationship(self, index, type_index, start_node, end_node, r_type, properties=None, **kwproperties):
        if not isinstance(start_node, Node) or not isinstance(end_node, Node):
            raise TypeError("Start and end nodes must be Node instances (%s and %s passed)" %
                            (type(start_node).__name__, type(end_node).__name__))
        r_id = IdGenerator.get_edge_id(start_node.id, type_index, end_node.id, index)
        inst = _put_unbound_relationship(self, r_id, r_type, properties, **kwproperties)
        inst._start_node = start_node
        inst._end_node = end_node
        return inst


def _put_unbound_relationship(graph, r_id, r_type, properties=None, **kwproperties):
    inst = Relationship(graph, r_id, r_type)
    inst._update(properties, **kwproperties)
    return inst


class Entity(Mapping):
    """
    Base class for :class:`.Node` and :class:`.Relationship` that
    provides :class:`.Graph` membership and property containment
    functionality.
    """

    def __new__(cls, graph, id):
        inst = object.__new__(cls)
        inst._graph = graph
        inst._id = id
        inst._properties = {}
        return inst

    def __eq__(self, other):
        try:
            return type(self) == type(other) and self.graph == other.graph and self.id == other.id
        except AttributeError:
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(self.id)

    def __len__(self):
        return len(self._properties)

    def __getitem__(self, name):
        return self._properties.get(name)

    def __contains__(self, name):
        return name in self._properties

    def __iter__(self):
        return iter(self._properties)

    @property
    def graph(self):
        """
        The :class:`.Graph` to which this entity belongs.
        """
        return self._graph

    @property
    def id(self):
        """
        The identity of this entity in its container :class:`.Graph`.
        """
        return self._id

    def _update(self, properties, **kwproperties):
        properties = dict(properties or {}, **kwproperties)
        self._properties.update((k, v) for k, v in properties.items() if v is not None)

    def get(self, name, default=None):
        """
        Get a property value by name, optionally with a default.
        """
        return self._properties.get(name, default)

    def keys(self):
        """
        Return an iterable of all property names.
        """
        return self._properties.keys()

    def values(self):
        """
        Return an iterable of all property values.
        """
        return self._properties.values()

    def items(self):
        """
        Return an iterable of all property name-value pairs.
        """
        return self._properties.items()


class EntitySetView(Mapping):
    """
    View of a set of :class:`.Entity` instances within a :class:`.Graph`.
    """

    def __init__(self, entity_dict):
        self._entity_dict = entity_dict

    def __getitem__(self, e_id):
        return self._entity_dict[e_id]

    def __len__(self):
        return len(self._entity_dict)

    def __iter__(self):
        return iter(self._entity_dict.values())


class Node(Entity):
    """
    Self-contained graph node.
    """

    def __new__(cls, graph, n_id):
        inst = Entity.__new__(cls, graph, n_id)
        inst._label = ''
        return inst

    def __repr__(self):
        return "<Node id=%r label=%r properties=%r>" % (self._id, self._label, self._properties)

    @property
    def label(self):
        """ The set of labels attached to this node.
        """
        return self._label


class Relationship(Entity):
    """
    Self-contained graph relationship.
    """

    def __new__(cls, graph, r_id, r_type):
        inst = Entity.__new__(cls, graph, r_id)
        inst.__class__ = graph.relationship_type(r_type)
        inst._start_node = None
        inst._end_node = None
        return inst

    def __repr__(self):
        return "<Relationship id=%r nodes=(%r, %r) type=%r properties=%r>" % (
            self._id, self._start_node, self._end_node, self.type, self._properties)

    @property
    def nodes(self):
        """
        The pair of nodes which this relationship connects.
        """
        return self._start_node, self._end_node

    @property
    def start_node(self):
        """
        The start node of this relationship.
        """
        return self._start_node

    @property
    def end_node(self):
        """
        The end node of this relationship.
        """
        return self._end_node

    @property
    def type(self):
        """
        The type name of this relationship.
        This is functionally equivalent to ``type(relationship).__name__``.
        """
        return type(self).__name__

    @property
    @deprecated("Relationship.start is deprecated, please use Relationship.start_node.id instead")
    def start(self):
        return self.start_node.id

    @property
    @deprecated("Relationship.end is deprecated, please use Relationship.end_node.id instead")
    def end(self):
        return self.end_node.id


class Path(object):
    """
    Self-contained graph path.
    """

    def __init__(self, start_node, *relationships):
        assert isinstance(start_node, Node)
        nodes = [start_node]
        for i, relationship in enumerate(relationships, start=1):
            assert isinstance(relationship, Relationship)
            if relationship.start_node == nodes[-1]:
                nodes.append(relationship.end_node)
            elif relationship.end_node == nodes[-1]:
                nodes.append(relationship.start_node)
            else:
                raise ValueError("Relationship %d does not connect to the last node" % i)
        self._nodes = tuple(nodes)
        self._relationships = relationships

    def __repr__(self):
        return "<Path start=%r end=%r size=%s>" % \
               (self.start_node, self.end_node, len(self))

    def __eq__(self, other):
        try:
            return self.start_node == other.start_node and self.relationships == other.relationships
        except AttributeError:
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        value = hash(self._nodes[0])
        for relationship in self._relationships:
            value ^= hash(relationship)
        return value

    def __len__(self):
        return len(self._relationships)

    def __iter__(self):
        return iter(self._relationships)

    @property
    def graph(self):
        """
        The :class:`.Graph` to which this path belongs.
        """
        return self._nodes[0].graph

    @property
    def nodes(self):
        """
        The sequence of :class:`.Node` objects in this path.
        """
        return self._nodes

    @property
    def start_node(self):
        """
        The first :class:`.Node` in this path.
        """
        return self._nodes[0]

    @property
    def end_node(self):
        """
        The last :class:`.Node` in this path.
        """
        return self._nodes[-1]

    @property
    def relationships(self):
        """
        The sequence of :class:`.Relationship` objects in this path.
        """
        return self._relationships

    @property
    @deprecated("Path.start is deprecated, please use Path.start_node instead")
    def start(self):
        return self.start_node

    @property
    @deprecated("Path.end is deprecated, please use Path.end_node instead")
    def end(self):
        return self.end_node


class GsProperty:
    """
    图元素（点和边）的公共基类，也是操作属性接口，{Vertex} 和 {Edge} 继承该接口。
    点/边类型定义了结构后，理论上点类型下所有点的属性没赋值前都是None。
    删除了某个属性之后，这个属性还是会有个默认值也是None。 因此GraphDb没有返回值为None的属性了
    """
    def __init__(self, entity):
        self.__entity = entity

    def has_property(self, key: str) -> bool:
        """
        判断是否有某个属性名

        :param key: 属性名
        :return: true 有值，false 没值
        """
        return key in self.__entity

    def get_property(self, key: str):
        """
        获取某个属性名对应的值

        :param key: 属性名
        :return:
        """
        return self.__entity[key]

    def get_property_keys(self) -> list:
        """
        返回所有的属性名

        :return:
        """
        return list(self.__entity.keys())

    def get_all_properties(self) -> dict:
        """
        返回所有属性集合

        :return:
        """
        properties = {}
        for k in self.__entity:
            properties[k] = self.__entity[k]
        return properties


class GsVertex(GsProperty):
    """
    操作点接口
    """
    def __init__(self, node: Node, graph):
        super(GsVertex, self).__init__(node)
        self.__node = node
        self.__graph = graph

    def get_id(self) -> int:
        """
        获取点的id

        :return:
        """
        return self.__node.id

    def get_type(self) -> str:
        """
        获取点的类型

        :return:
        """
        return self.__node.label

    def __str__(self) -> str:
        return self.__node.__str__()


class Vertex(GsVertex):
    """

    """


class GsEdge(GsProperty):
    """
    操作边接口
    """
    def __init__(self, relationship: Relationship, graph):
        super(GsEdge, self).__init__(relationship)
        self.__relationship = relationship
        self.__graph = graph

    def get_id(self) -> str:
        """
        获取边的id

        :return:
        """
        return self.__relationship.id

    def get_type(self) -> str:
        """
        获取边的类型

        :return:
        """
        return self.__relationship.type

    def get_from_vertex_id(self) -> int:
        """
        获取起始点id

        :return:
        """
        return self.__relationship.start_node.id

    def get_from_vertex(self) -> Vertex:
        """
        获取起始点信息。
        不是同边信息一同返回，额外调用了{@link Graph#retrieveVertex(long)}方法获取。

        :return:
        """
        return self.__graph.retrieve_vertex(self.get_from_vertex_id())

    def get_to_vertex_id(self) -> int:
        """
        获取终止点id。

        :return:
        """
        return self.__relationship.end_node.id

    def get_to_vertex(self) -> Vertex:
        """
        获取终止点信息。
        不是同边信息一同返回，额外调用了{@link Graph#retrieveVertex(long)}方法获取。

        :return:
        """
        return self.__graph.retrieve_vertex(self.get_to_vertex_id())

    def __str__(self) -> str:
        return self.__relationship.__str__()


class Edge(GsEdge):
    """

    """

def hydrate_path(nodes, relationships, sequence):
    assert len(nodes) >= 1
    assert len(sequence) % 2 == 0
    last_node = nodes[0]
    entities = [last_node]
    for i, rel_index in enumerate(sequence[::2]):
        assert rel_index != 0
        next_node = nodes[sequence[2 * i + 1]]
        if rel_index > 0:
            r = relationships[rel_index - 1]
            r._start_node = last_node
            r._end_node = next_node
            entities.append(r)
        else:
            r = relationships[-rel_index - 1]
            r._start_node = next_node
            r._end_node = last_node
            entities.append(r)
        last_node = next_node
    return Path(*entities)

# TODO 解析Relationship
def hydration_functions(graph):
    return {
        b"N": graph.put_node,
        b"R": lambda index, type_index, start_urn, end_urn, r_type, properties:
            graph.put_relationship(index, type_index, Node(graph, start_urn), Node(graph, end_urn), r_type, properties),
        b"r": lambda *args: _put_unbound_relationship(graph, *args),
        b"P": hydrate_path,
    }


def dehydration_functions():
    # There is no support for passing graph types into queries as parameters
    return {}

