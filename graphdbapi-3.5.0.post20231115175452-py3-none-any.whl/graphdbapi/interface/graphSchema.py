# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 19:17
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from typing import Dict, Union, List, Set, Optional

from graphdbapi.v1.enum import PropertyType
from graphdbapi.v1.graph.AbstractGraph import AbstractGraph
from graphdbapi.v1.graph import CombinedEdgeType


class GraphSchemaInterface(AbstractGraph):
    """
    图schema操作类，不支持事务。
    """
    def create_vertex_type(self, type: str, pk_name: str, class_map: Union[Dict[str, PropertyType], None]) -> None:
        """
        添加点类型。为图新增一个点类型。

        :param type: 点类型，<b>不能为空。</b>
        :param pk_name: 主键名称，<b>不能为空。</b>
        :param class_map: 属性类型的映射，其中key是属性名，value是属性类型，<b>允许为空。</b>
        :return:
        :exception ParamException:     参数格式不正确，当类型为空、外部唯一标识属性名为空、属性名为空时将抛出异常。
        :exception TypeFoundException: 边类型在图中已存在时将抛出异常。
        :exception DatabaseException:  数据库内部异常。
        """
        raise NotImplementedError

    def drop_vertex_type(self, type: str) -> None:
        """
        删除点类型。删除图中已存在的一个点类型。

        :param type: 点类型，<b>不能为空。</b>
        :return:
        :exception ParamException:        参数格式不正确，当类型为空时将抛出异常。
        :exception TypeNotFoundException: 点类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def create_edge_type(
            self, type: str, combine_edge_types: Union[List[CombinedEdgeType], CombinedEdgeType],
            direct: bool, allow_repeat: bool, combine_key: Union[str, None], class_map: Union[Dict[str, PropertyType], None]
        ) -> None:
        """
         添加边类型。为图中新增一个边类型，并创建从from到to的CombinedEdgeType。

        :param type:  边类型，<b>不能为空。</b>
        :param combine_edge_types: 起始点类型和终止点类型组合集合，<b>不能为空。</b>
        :param direct: 边的方向
        :param allow_repeat: 是否允许重复
        :param combine_key: 基于属性进行去重，<b>为空表示基于边类型进行去重。</b>
        :param class_map: 属性类型的映射，其中key是属性名，value是属性类型,<b>属性类型不能为空。</b>
        :return:
        :exception ParamException:        参数格式不正确，当边类型名为空、起始点类型名为空、终止点类型名为空、属性类型为空、allow_repeat为True时combine_key不为null或combineKey在classMap中不存在时将抛出异常。
        :exception TypeFoundException:    边类型在图中已存在时将抛出异常。
        :exception TypeNotFoundException: 起始点类型或终止点类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def get_vertex_types(self) -> Set[str]:
        """
        获取所有的点类型名。

        :return: 所有点的类型名集合
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def drop_edge_type(self, type: str) -> None:
        """
        删除边类型。删除图中已存在的一个边类型。

        :param type: 边类型，<b>不能为空。</b>
        :return:
        :exception ParamException:        参数格式不正确，当边类型为空时将抛出异常。
        :exception TypeNotFoundException: 边类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def drop_combined_edge_type(self, type: str, from_type: str, to_type: str) -> None:
        """
        删除边类型中的一对起止点类型。 \n
        例：存在以下关系 \n
        人--关注-->公司 \n
        人--关注-->人 \n
        若：type为关注,fromType为人,toType为公司 \n
        则：人--关注-->公司（人到公司的关注关系被删除） \n

        :param type: 边类型，<b>不能为空。</b>
        :param fome_type: 起始点类型，<b>不能为空。</b>
        :param to_type: 终止点类型，<b>不能为空。</b>
        :return: 
        :exception ParamException:        参数格式不正确，当边类型为空、起始点类型为空或终止点类型为空时将抛出异常。
        :exception TypeNotFoundException: 边类型在图中不存在时将抛出异常。
        :exception TypeErrorException:    from到to的映射不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def get_edge_types(self) -> Set[str]:
        """
        获取所有的边类型名。

        :return: 所有边的类型名集合
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def create_property(self, type: str, is_vertex: bool, property_name: str, is_index: bool, property_type: PropertyType) -> None:
        """
        为某个类型增加属性列。

        :param type: 点/边类型，<b>不能为空。</b>
        :param is_vertex: 点类型填True，边类型填False，<b>is_vertex需要跟type对应。</b>
        :param property_name: 属性名，<b>不能为空。</b>
        :param is_index: 是否要加索引。True添加索引，False不添加索引
        :param property_type: 属性类型，<b>不能为空。</b>
        :return:
        :exception ParamException:         参数格式不正确，当类型为空、属性名为空、属性类型为空时将抛出异常。
        :exception TypeNotFoundException:  点/边类型在图中不存在时将抛出异常。
        :exception PropertyFoundException: 属性名在对应类型中已存在时将抛出异常。
        :exception DatabaseException:      数据库内部异常。
        """
        raise NotImplementedError

    def drop_property(self, type: str, is_vertex: bool, property_name: str) -> None:
        """
        删除某个类型的某个属性。

        :param type: 点/边类型，<b>不能为空。</b>
        :param is_vertex: 点类型填True，边类型填False，<b>is_vertex需要跟type对应。</b>
        :param property_name: 属性名，<b>不能为空。</b>
        :return:
        :exception ParamException:            参数格式不正确，当类型为空、属性名为空、属性类型为空时将抛出异常。
        :exception TypeNotFoundException:     点/边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在对应类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常
        """
        raise NotImplementedError

    def get_property_keys(self, type: str, is_vertex: bool) -> Dict[str, PropertyType]:
        """
        获取某个点/边类型下的属性名和属性类型。

        :param type: 点/边类型，<b>不能为空。</b>
        :param is_vertex: 点类型为True，边类型为False，<b>is_vertex需要跟type对应。</b>
        :return: 该类型所有属性的映射，其中key是属性名，value是属性类型
        :exception ParamException:        参数格式不正确，当类型为空时将抛出异常。
        :exception TypeNotFoundException: 点/边类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def get_property_pk(self, type: str) -> str:
        """
        获取某个点类型下的外部唯一标识。

        :param type: 点类型，<b>不能为空。</b>
        :return: 点类型下的外部唯一标识
        :exception ParamException:        参数格式不正确，当类型为空时将抛出异常。
        :exception TypeNotFoundException: 点类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def edit_direct(self, type: str, direct: bool) -> None:
        """
        更新某个边类型的方向。无向or有向。

        :param type: 边类型，<b>不能为空。</b>
        :param direct: 方向
        :return:
        :exception ParamException:        参数格式不正确，当边类型为空时将抛出异常。
        :exception TypeNotFoundException: 边类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def get_edge_direct(self, type: str) -> bool:
        """
        获取某个边类型的方向。

        :param type: 边类型，<b>不能为空。</b>
        :return: True有向边， False无向边
        :exception ParamException:        参数格式不正确，当类型为空时将抛出异常。
        :exception TypeNotFoundException: 边类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def create_combined_edge_type(self, type: str, from_type: str, to_type: str) -> None:
        """
        为指定边类型创建从from到to的CombinedEdgeType集合。

        :param type: 边类型，<b>不能为空。</b>
        :param from_type: 起始点类型名，<b>不能为空。</b>
        :param to_type: 终止点类型名，<b>不能为空。</b>
        :return:
        :exception ParamException:        参数格式不正确，当边类型名为空、起始点类型名为空、终止点类型名为空时将抛出异常。
        :exception EdgeNotFoundException: 边在图中不存在时将抛出异常。
        :exception TypeNotFoundException: 起始点类型或终止点类型在图中不存在时将抛出异常。
        :exception TypeErrorException:    from到to的映射已存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def get_combined_edge_type(self, type: str) -> List[CombinedEdgeType]:
        """
        根据边类型获取起始点和终止点类型名。

        :param type: 边类型，<b>不能为空。</b>
        :return: 起始点和终止点类型名组合列表
        :exception ParamException:        参数格式不正确，当边类型为空时将抛出异常。
        :exception EdgeNotFoundException: 边在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def rename_type_name(self, type: str, is_vertex: bool, new_type: str) -> None:
        """
        更新某个类型名。

        :param type: 点/边类型，<b>不能为空。</b>
        :param is_vertex: 点类型填True，边类型填False，<b>is_vertex需要跟type对应。</b>
        :param new_type: 新类型名，<b>不能为空。</b>
        :return:
        :exception ParamException:        参数格式不正确，当类型为空、新类型名为空时将抛出异常。
        :exception TypeNotFoundException: 点/边类型在图中不存在时将抛出异常。
        :exception TypeFoundException:    新类型名在图中已存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def rename_property_name(self, type: str, is_vertex: bool, old_prop_name: str, new_prop_name: str) -> None:
        """
        更新某个类型的某个属性名。

        :param type: 点/边类型，<b>不能为空。</b>
        :param is_vertex: 点类型填True，边类型填False，<b>is_vertex需要跟type对应。</b>
        :param old_prop_name: 原属性名，<b>不能为空。</b>
        :param new_prop_name: 新属性名，<b>不能为空。</b>
        :return:
        :exception ParamException:            参数格式不正确，当点/边类型为空、原属性名为空、新属性名为空时将抛出异常。
        :exception TypeNotFoundException:     点/边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 原属性名在对应类型中不存在时将抛出异常。
        :exception PropertyFoundException:    新属性名在对应类型中已存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def create_prop_index(self, type: str, is_vertex: bool, property: str) -> None:
        """
        为某个类型的某个属性添加简单索引。

        :param type: 点/边类型，<b>不能为空。</b>
        :param is_vertex: 点类型填True，边类型填False，<b>is_vertex需要跟type对应。</b>
        :param property: 属性名，<b>不能为空。</b>
        :return:
        :exception ParamException:            参数格式不正确，当类型为空、属性名为空
        :exception TypeNotFoundException:     点/边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在对应类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def drop_prop_index(self, type: str, is_vertex: bool, property: str) -> None:
        """
        删除某个类型的某个属性索引。

        :param type: 点/边类型，<b>不能为空。</b>
        :param is_vertex: 点类型填True，边类型填False，<b>is_vertex需要跟type对应。</b>
        :param property: 属性名，<b>不能为空。</b>
        :return:
        :exception ParamException:            参数格式不正确，当类型为空、属性名为空时将抛出异常。
        :exception TypeNotFoundException:     点/边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在对应类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def edit_property_desc(self, type: str, is_vertex: bool, prop_name: str, desc: str) -> None:
        """
        修改属性描述

        :param type: 点/边类型
        :param is_vertex: 是否是点类型
        :param prop_name: 属性名
        :param desc: 描述信息
        :return:
        """

    def get_property_desc(self, type: str, is_vertex: bool, prop_name: str) -> Optional[str]:
        """
        获取属性描述

        :param type: 点/边类型
        :param is_vertex: 是否为点
        :param prop_name: 属性名
        :return: 属性描述
        """

    def edit_graph_desc(self, desc: str) -> None:
        """
        修改图描述

        :param desc: 图描述
        :return:
        """

    def get_graph_desc(self) -> Optional[str]:
        """
        获取图描述

        :return: 图描述
        """

    def edit_type_desc(self, type: str, is_vertex: bool, desc: str) -> None:
        """
        修改类型描述

        :param type: 点/边类型
        :param is_vertex: 是否是点类型
        :param desc: 描述信息
        :return:
        """

    def get_type_desc(self, type: str, is_vertex: bool) -> Optional[str]:
        """
        获取类型描述

        :param type: 点/边类型
        :param is_vertex: 是否为点
        :return: 属性描述
        """



