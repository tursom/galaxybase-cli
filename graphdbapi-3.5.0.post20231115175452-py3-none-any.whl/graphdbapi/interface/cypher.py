# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 16:15
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from __future__ import annotations

from typing import Union, Dict, Any, Optional, NoReturn

from graphdbapi import BoltStatementResult
from graphdbapi.interface.graph import GraphInterface
from graphdbapi.v1 import CypherQuery


class CypherInterface(GraphInterface):
    def execute_query(self, cypher: str, timeout: Optional[int] = None, def_limit: Optional[int] = None) -> BoltStatementResult:
        """
        执行 cypher 查询。

        :param cypher: 查询语句,<b>不能为空</b>
        :param timeout: 超时时间，<b>必须大于0, 或者为None。</b>
        :param def_limit: 返回结果数限制，<b>小于0或者为None表示不进行限制。</b>
        :return: cypher执行结果
        :exception ParamException: 参数格式不正确，当cypher为空、timeout小于等于0时将抛出异常。
        :exception DatabaseException: 数据库内部异常，在cypher语法错误时将抛出异常。
        """
        raise NotImplementedError

    def execute_cypher(self, cypher: str, parameters: Union[Dict[str, Any], None] = None) -> BoltStatementResult:
        """
        执行 cypher 查询。

        :param cypher: 查询语句，<b>不能为空。</b>
        :param parameters: 查询可用的参数
        :return: cypher执行结果
        :exception ParamException: 参数类型不正确，当cypher为空时将抛出异常。
        :exception DatabaseException: 数据库内部异常，在cypher语法错误时将抛出异常。
        """
        raise NotImplementedError

    def get_cypher_metrics(self) -> Dict[int, CypherQuery]:
        """
        获取正在执行的 cypher语句信息。

        :return: cypher执行信息 事务信息
        """
        raise NotImplementedError

    def stop_cypher(self, task_id: int) -> NoReturn:
        """
        停止指定taskId的 cypher语句。

        :param task_id: cypher taskId，<b>不能小于0。</b>
        :return:
        :exception ParamException: 参数格式不正确，当taskId小于0时将抛出异常。
        """
        raise NotImplementedError