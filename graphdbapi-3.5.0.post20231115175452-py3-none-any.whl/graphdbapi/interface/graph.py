# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 15:19
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from typing import List, Dict, Any

from bolt.message import GraphMethod
from graphdbapi import BoltStatementResult
from graphdbapi.v1.graph.AbstractGraph import AbstractGraph


class GraphInterface(AbstractGraph):
    def delete_graph(self) -> None:
        """
        删除图。将删除图中的schema和所有数据。
        
        :return:
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def clear_graph(self) -> None:
        """
        删除图的数据。保留图结构，只删除数据。
        
        :return:
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def execute_procedure(self, procedure_name: str, *input_params: Any) -> BoltStatementResult:
        """
        通过bolt执行procedure方法

        :param procedure_name: procedure方法名。
        :param input_params: 入参（需按照procedure方法的参数顺序）。
        :return: 执行结果迭代器
        """
        raise NotImplementedError

    def is_enable(self):
        raise NotImplementedError

    def send_message_operator(self, method: GraphMethod, parameters: Dict[str, List[Any]]) -> List[Any]:
        raise NotImplementedError

