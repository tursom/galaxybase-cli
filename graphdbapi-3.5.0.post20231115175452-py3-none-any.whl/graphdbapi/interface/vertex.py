# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 14:34
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from typing import Dict, Any, Union, Iterator, List, Set

from graphdbapi.interface.graph import GraphInterface
from graphdbapi.types import Vertex
from graphdbapi.v1.graph import VertexInfoByPk, VertexInfoById, ResponseItem
from graphdbapi.v1.enum import Direction
from graphdbapi.v1 import SearchPredicate, SearchOrder
from graphdbapi.v1.graph.query.condition import VisitCondition
from graphdbapi.v1.graph.query import EdgeDegreeInfo


class VertexInterface(GraphInterface):
    def get_vertex_id_by_pk(self, pk: str) -> Set[int]:
        """
        查询点id。根据点pk查询点id。\n
        该方法不限定点类型，将去所有点类型中查询是否有点pk存在，返回点id集合。

        :param pk: 点pk，<b>不能为空。</b>
        :return: 点id集合。
        :exception ParamException:       参数格式不正确，当pk为空时将抛出异常。
        :exception DatabaseException:    数据库内部异常。

        Examples:
            >>> ids = self.get_vertex_id_by_pk("10110")
        """
        raise NotImplementedError

    def get_vertex_id_by_pk_and_type(self, pk: str, type: str) -> int:
        """
        查询点id。根据点pk和类型获取点id。\n
        在一个确定的点类型下，点pk和点id是一一对应的。

        :param pk: 点pk，<b>不能为空。</b>
        :param type: 点类型, <b>不能为空。</b>
        :return: 点id。
        :exception ParamException:       参数格式不正确，当pk为空时将抛出异常。
        :exception DatabaseException:    数据库内部异常。

        Examples:
            >>> id = self.get_vertex_id_by_pk_and_type("10110", "个人")
        """
        raise NotImplementedError

    def retrieve_vertex(self, id: int) -> Vertex:
        """
        查询点。根据点id查询点信息。

        :param id: 点id，<b>不能小于0。</b>
        :return: 查询的点信息。
        :exception ParamException:          参数格式不正确，当点id小于0时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_vertex_by_pk(self, pk: str, type: str) -> Vertex:
        """
        查询点。根据点pk和type查询点。\n
        在一个确定的点类型下，根据点pk仅能查询到一个点。

        :param pk: 点pk，<b>不能为空。</b>
        :param type: 点类型，<b>不能为空。</b>
        :return: 查询的点信息。
        :exception ParamException:          参数格式不正确，当pk或type为空时将抛出异常。
        :exception TypeNotFoundException:   点类型在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_or_insert_vertex_by_pk(self, pk: str, type: str, property: Union[Dict[str, Any], None]) \
            -> Vertex:
        """
        查询或新增点。通过点pk和type查询或新增点。若点已经存在，仅查询并返回点信息，属性值不做修改。若点不存在，新增并返回点信息。

        :param pk:  点pk，<b>不能为空。</b>
        :param type:  点类型，<b>不能为空。</b>
        :param property: 点属性。<b>填None或{}时，表示添加的点没有属性值。</b>
        :return: 点的详细信息。
        :exception ParamException:            参数格式不正确，当pk或type为空、property输入的属性类型不支持时将抛出异常。
        :exception TypeNotFoundException:     点类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在点类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。

        Example
            >>> vertex = self.retrieve_or_insert_vertex_by_pk("111111", 'person', None)
            >>> print(vertex)
        """
        raise NotImplementedError

    def retrieve_vertexes_by_type(self, type: str) -> Iterator[Vertex]:
        """
        查询点类型下的所有点。迭代获取某个点类型的所有点信息。

        :param type: 点类型，<b>不能为空。</b>
        :return: 点信息迭代器。
        :exception ParamException:        参数格式不正确，当type为空时将抛出异常。
        :exception TypeNotFoundException: 点类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_vertexes(self, ids: List[int]) -> List[ResponseItem]:
        """
        批量查询点。通过点id查询点信息。如果不存在，则会返回异常。\n
        结果按传入顺序构成集合，集合中包含查询的点信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param ids: 点id列表，<b>不能为空。</b>
        :return: 批量操作结果集。包含查询的点信息和错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None、点id格式不正确时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        """
        批量查询点。通过点pk和type查询点信息。如果不存在，则会返回异常。\n
        结果按传入顺序构成集合，集合中包含查询的点信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 点信息列表，<b>不能为空。</b>
        :return: 查询点列表的结果信息，包含添加成功的点详细信息和添加失败的异常信息。
        :exception ParamException:    参数格式不正确，当点列表为空或者其中的id或pk和type为None时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def update_vertexes(self, items: List[VertexInfoById]) -> List[ResponseItem]:
        """
        批量更新点。通过点id更新点。如果已存在，则会比较属性值。 \n
        结果按传入顺序构成集合，集合中包含更新后的点信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含更新后的点信息和错误信息。
        :exception ParamException:    参数格式不正确，当list参数中某项为None、id值为空或property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_all_vertexes(self) -> Iterator[Vertex]:
        """
        查询所有点。迭代获取数据库中的所有点信息。

        :return: 点信息迭代器
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def get_vertex_count(self, type: str) -> int:
        """
        查询点个数。查询传入类型去查找点总数。

        :param type: 点类型，<b>不能为空。</b>
        :return: 点个数
        :exception ParamException:        参数格式不正确，当类型为空时将抛出异常。
        :exception TypeNotFoundException: 点类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def get_all_vertex_count(self) -> int:
        """
        查询点个数。查询图中点总数。

        :return: 点个数
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def get_degree(
            self, id: int, edge_type_filter: Union[Set[str], None], direction: Direction,
            vertex_condition: Union[VisitCondition, None], edge_condition: Union[VisitCondition, None],
            include_loop: bool
    ) -> EdgeDegreeInfo:
        """
        查询点的degree信息。

        :param id: 点id，<b>不能小于0。</b>
        :param edge_type_filter: 边类型的过滤条件。只会返回满足参数中边类型的边。填None不参与计算。建议类型过滤使用这个字段，而不是edgeCondition
        :param direction: 边方向，<b>不能为None。</b>
        :param vertex_condition: 点条件，填None不参与计算
        :param edge_condition: 边条件，填None不参与计算
        :param includeLoop:    True计算自环，False不计算自环
        :return: {EdgeDegreeInfo} 点的degree信息
        :exception ParamException:            参数格式不正确，当点id小于0、查询方向为None时将抛出异常。
        :exception VertexNotFoundException:   点在图中不存在时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 点/边条件过滤对应的属性类型在指定点/边类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def insert_vertex_by_pk(self, pk: str, type: str, property: Dict[str, Any] = None) -> Vertex:
        """
        新增点。通过点pk和type新增一个点，属性为可选项。

        :param pk:  点pk，<b>不能为空。</b>
        :param type: 点类型，<b>不能为空。</b>
        :param property: 点属性。<b>填None或{}时，表示添加的点没有属性值。</b>
        :return: 新增点的信息。
        :exception ParamException:            参数格式不正确，当pk或type为空、property输入的属性类型不支持时将抛出异常。
        :exception VertexFoundException:      点已经存在时将抛出异常。
        :exception TypeNotFoundException:     点类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在点类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def insert_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        """
        批量新增点。通过点pk和type新增点，属性为可选项。 \n
        结果按传入顺序构成集合，集合中包含新增后的点信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含新增后的点信息和错误信息。
        :exception ParamException:    参数格式不正确，当list为空,参数中某项为None、pk或type值为空或property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def delete_vertexes(self, ids: List[int]) -> List[str]:
        """
        批量删除点。通过点id删除点。如果点不存在或删除失败，则会返回异常结果集。 \n
        结果按传入顺序构成集合，集合中包含成功信息和错误信息。

        :param ids: 点id列表，<b>不能为空。</b>
        :return: 批量操作结果集。点删除成功时返回None，点删除失败时返回错误信息。
        :exception ParamException:    参数格式不正确，当点列表为空或者其中的id为None时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def delete_vertex(self, id: int) -> None:
        """
        删除点。根据点id删除点。

        :param id: 点id，<b>不能小于0。</b>
        :return:
        :exception ParamException:          参数格式不正确，当点id小于0时将抛出异常。
        :exception VertexNotFoundException: 点在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """
        raise NotImplementedError

    def delete_vertex_by_pk(self, pk: str, type: str) -> None:
        """
        删除点。通过点pk和type删除点。

        :param pk: 点pk，<b>不能为空。</b>
        :param type: 点类型，<b>不能为空。</b>
        :return:
        :exception ParamException:          参数格式不正确，当pk或type为空时将抛出异常。
        :exception TypeNotFoundException:   点类型在图中不存在时将抛出异常。
        :exception VertexNotFoundException: 点在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """
        raise NotImplementedError

    def upsert_vertex_by_pk(self, pk: str, type: str, property: Dict[str, Any], is_merge: bool) -> Vertex:
        """
        新增或更新点。通过点pk和type新增或更新点。如果已存在，则会比较属性值。

        :param pk: 点pk，<b>不能为空。</b>
        :param type: 点类型，<b>不能为空。</b>
        :param property: 点属性。
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 点的详细信息。
        :exception ParamException:            参数格式不正确，当pk或type为空、property为空、property输入的属性类型不支持时将抛出异常。
        :exception TypeNotFoundException:     点类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在点类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def update_vertex_by_pk(self, pk: str, type: str, property: Dict[str, Any], is_merge: bool) -> Vertex:
        """
        更新点。通过点pk和type新增或更新点。如果已存在，则会比较属性值。

        :param pk: 点pk，<b>不能为空。</b>
        :param type: 点类型，<b>不能为空。</b>
        :param property: 点属性。
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 点的详细信息。
        :exception ParamException:            参数格式不正确，当pk或type为空、property为空、property输入的属性类型不支持时将抛出异常。
        :exception TypeNotFoundException:     点类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在点类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def update_vertex(self, id: int, property: Dict[str, Any], is_merge:bool) -> Vertex:
        """
        更新点。通过点id更新点属性。

        :param id: 点id，<b>不能小于0。</b>
        :param property: 点属性。
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 更新后的点信息。
        :exception ParamException:            参数格式不正确，当点id小于0、property输入的属性类型不支持时将抛出异常。
        :exception VertexNotFoundException:   点在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在点类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError


    def delete_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[str]:
        """
        批量删除点。通过点pk和type删除点。如果不存在或删除失败，则会返回异常结果集。  \n
        结果按传入顺序构成集合，集合中包含成功信息和错误信息。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。点删除成功时返回None，点删除失败时返回错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None、pk和type不存在时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def upsert_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        """
        批量新增或更新点。通过点pk和type新增或更新点。如果已存在，则会比较属性值。 \n
        结果按传入顺序构成集合，集合中包含新增或更新后的点信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含新增或更新后的点信息和错误信息。
        :exception ParamException:    参数格式不正确，当参数为空,参数中某项为None、pk或type值为空或property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """

        raise NotImplementedError

    def update_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        """
        批量更新点。通过点pk和type更新点。如果已存在，则会比较属性值。 \n
        结果按传入顺序构成集合，集合中包含更新后的点信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含更新后的点信息和错误信息。
        :exception ParamException:    参数格式不正确，当参数为空,参数中某项为None、pk或type值为空或property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """

        raise NotImplementedError

    def retrieve_or_insert_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        """
        批量查询或新增点。通过点pk和type查询或新增点。若点已经存在，仅查询并返回点信息，属性值不做修改。若点不存在，新增并返回点信息。   \n
        结果按传入顺序构成集合，集合中包含查询或新增后的点信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含查询或新增后的点信息和错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None、pk或type为空、property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def search_vertexes_by_index(self, type_name: str, prop_name: str, data: Any, skip: int, limit: int) -> Iterator[int]:
        """
        通过索引，查找点数据, 返回点id
        :param type_name: 类型名
        :param prop_name: 属性名
        :param data: 所查找的值
        :param skip: 跳过条目
        :param limit: 限制返回数量
        :return:
        """
        raise NotImplementedError

    def search_vertex_property(self, vertex_type: str, predicates: List[SearchPredicate], orders: List[SearchOrder],
                               skip: int, limit: int) -> Iterator[Vertex]:
        """
        通过类型、属性查询点

        :param vertex_type: 点类型名
        :param predicates: 查询谓词，每个谓词包括：属性名、查询值
        :param orders: 属性排序
        :param skip: 跳过
        :param limit: 限制返回数量
        :return: Iterator[Vertex]
        """
        raise NotImplementedError
