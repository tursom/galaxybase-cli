# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 16:38
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from graphdbapi.compat import deprecated
from typing import Iterator, Dict, Any, Union, List, Set

from graphdbapi.interface.graph import GraphInterface
from graphdbapi.types import Edge
from graphdbapi.v1 import SearchPredicate, SearchOrder
from graphdbapi.v1.enum import Direction
from graphdbapi.v1.graph.query.condition import VisitCondition
from graphdbapi.v1.graph import EdgeInfoByVertexPk, EdgeInfoByVertexId, EdgeInfo, ResponseItem


class EdgeInterface(GraphInterface):
    def retrieve_edge(self, edge_id: str) -> Edge:
        """
        查询边。通过边id查询边。

        :param edge_id: 边id，<b>不能为空。</b>
        :return: 查询的边信息。
        :exception ParamException:        参数格式不正确，当边id为空或格式不正确时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_edges_by_type(self, type: str) -> Iterator[Edge]:
        """
        查询边类型下所有边。迭代获取某个类型的所有边信息。

        :param type: 边类型，<b>不能为空。</b>
        :return: 边信息迭代器。
        :exception ParamException:    参数格式不正确，当类型为空时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_all_edges(self) -> Iterator[Edge]:
        """
        查询所有边。迭代获取所有类型的所有边。

        :return: 边信息迭代器。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def get_edge_count(self, type: str) -> int:
        """
        查询边个数。查询当前类型边总数。

        :param type: 点类型，<b>不能为空。</b>
        :return: 边个数
        :exception ParamException:        参数格式不正确，当类型为空时将抛出异常。
        :exception TypeNotFoundException: 边类型在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常。
        """
        raise NotImplementedError

    def get_all_edge_count(self) -> int:
        """
        查询边个数。查询图中边总数。

        :return: 边个数
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def insert_edge_by_vertex_id(self, from_id: int, to_id: int, type: str, property: Union[Dict[str, Any], None]) -> Edge:
        """
        新增边。通过起始点id和终止点id新增一条边，属性为可选项。

        :param from_id: 起始点id，<b>不能小于0。</b>
        :param to_id: 终止点id，<b>不能小于0。</b>
        :param type: 边类型，<b>不能为空。</b>
        :param property: 边属性。<b>填None或{}时，表示新增的边没有属性值。</b>
        :return: 新增后的边信息。
        :exception ParamException:            参数格式不正确，当起始点id、终止点id小于0、type为空或property输入的属性类型不支持时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型时将抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def update_edge(self, edge_id: str, property: Dict[str, Any], is_merge:bool) -> Edge:
        """
        更新边。通过边id更新边。

        :param edge_id: 边id，<b>不能为空。</b>
        :param property: 边属性。
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 更新后的边信息。
        :exception ParamException:            参数格式不正确，当边id为空或格式不正确、property输入的属性类型不支持时将抛出异常。
        :exception EdgeNotFoundException:     边在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_or_insert_edge_by_vertex_id(self, from_id: int, to_id: int, type: str, property: Union[Dict[str, Any], None]) \
            -> Iterator[Edge]:
        """
        查询或新增边。通过起始点、终止点id和边类型查询或新增边。\n
        若两点之间此边类型的边存在，则查询并返回两点之间此类型所有边的迭代器。若不存在，则新增一条边并返回。

        :param from_id: 起始点id，<b>不能小于0。</b>
        :param to_id: 终止点id，<b>不能小于0。</b>
        :param type: 边类型，<b>不能为空。</b>
        :param property: 边属性。<b>填None或{}时，新增的边没有属性值。</b>
        :return: 查询或新增后的边信息迭代器。
        :exception ParamException:            参数格式不正确，当type为空、起始点id或终止点id小于0时将抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """

        raise NotImplementedError

    def delete_edge_by_vertex_pk(self, from_pk: str, from_type: str, to_pk: str, to_type: str, edge_types: Union[Set[str], None]) -> None:
        """
           删除边。通过起始点pk和终止点pk，删除两点之间的边。

        :param from_pk: 起始点pk，<b>不能为空。</b>
        :param from_type: 起始点类型，<b>不能为空。</b>
        :param to_pk: 终止点pk，<b>不能为空。</b>
        :param to_type: 终止点类型，<b>不能为空。</b>
        :param edge_types: 需要删除的边类型，<b>为None或空集合时所有类型全删。</b>
        :return:
        :exception ParamException:          参数格式不正确。
        :exception VertexNotFoundException: 起始点在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """

    def delete_edge_by_vertex_pk_with_condition(
            self, from_pk: str, from_type: str, to_pk: str, to_type: str,
            edge_condition: Union[VisitCondition, None],
            edge_types: Union[Set[str], None]) -> None:
        """
           删除边。通过起始点pk和终止点pk，删除两点之间的边。

        :param from_pk: 起始点pk，<b>不能为空。</b>
        :param from_type: 起始点类型，<b>不能为空。</b>
        :param to_pk: 终止点pk，<b>不能为空。</b>
        :param to_type: 终止点类型，<b>不能为空。</b>
        :param edge_condition:  边条件过滤，<b>为None不参与计算。</b>
        :param edge_types: 需要删除的边类型，<b>为None或空集合时所有类型全删。</b>
        :return:
        :exception ParamException:          参数格式不正确。
        :exception VertexNotFoundException: 起始点在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """

    @deprecated("This function will be removed soon")
    def delete_edge_by_vertex_id(self, from_id: int, to_id: int, edge_limit: int) -> None:
        """
        删除边。通过起始点id和终止点id，删除两点之间的边

        :param from_id: 起始点id，<b>不能小于0。</b>
        :param to_id: 终止点id，<b>不能小于0。</b>
        :param edge_limit: 删除边数，<=0代表全量，>0则删指定个数。
        :return:
        :exception ParamException:          参数格式不正确，当起始点id和终止点id小于0时将抛出异常。
        :exception VertexNotFoundException: 起始点在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """
        raise NotImplementedError

    def delete_edge_by_vertex_id_with_edge_type(self, from_id: int, to_id: int, edge_types: Union[Set[str], None]) -> None:
        """
        删除边。通过起始点id和终止点id，删除两点之间的边

        :param from_id: 起始点id，<b>不能小于0。</b>
        :param to_id: 终止点id，<b>不能小于0。</b>
        :param edge_types: 需要删除的边类型，<b>为None
        或空集合时所有类型全删。</b>
        :return:
        :exception ParamException:          参数格式不正确，当起始点id和终止点id小于0时将抛出异常。
        :exception VertexNotFoundException: 起始点在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """
        raise NotImplementedError

    def delete_edge_by_vertex_id_with_condition(
            self, from_id: int, to_id: int,
            edge_condition: Union[VisitCondition, None],
            edge_types: Union[Set[str], None]) -> None:
        """
        删除边。通过起始点id和终止点id，删除两点之间的边

        :param from_id: 起始点id，<b>不能小于0。</b>
        :param to_id: 终止点id，<b>不能小于0。</b>
        :param edge_condition:  边条件过滤，<b>为None不参与计算。</b>
        :param edge_types: 需要删除的边类型，<b>为None
        或空集合时所有类型全删。</b>
        :return:
        :exception ParamException:          参数格式不正确，当起始点id和终止点id小于0时将抛出异常。
        :exception VertexNotFoundException: 起始点在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """
        raise NotImplementedError


    def delete_edge(self, edge_id: str) -> None:
        """
        删除边。通过边id删除边。

        :param edge_id: 边id，<b>不能为空。</b>
        :return:
        :exception ParamException:        参数格式不正确，当边id格式不正确时将抛出异常。
        :exception EdgeNotFoundException: 边在图中不存在时将抛出异常。
        :exception DatabaseException:     数据库内部异常
        """
        raise NotImplementedError

    def delete_edges(self, items: List[str]) -> List[str]:
        """
        批量删除边。通过边id删除边。如果不存在或删除失败，则会返回异常结果集。 \n
        结果按传入顺序构成集合，集合中包含成功信息和错误信息。

        :param items: 边id集合，<b>不能为空。</b>
        :return: 批量操作结果集。边删除成功时返回None，边删除失败时返回错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None、边id格式不正确时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def insert_edges_by_vertex_pk(self, items: List[EdgeInfoByVertexPk]) -> List[ResponseItem]:
        """
        批量新增边。通过起始点pk和终止点pk来新增边。    \n
        找不到起始点和终止点时会通过create_from和create_to来决定是否新增无属性的起始点和终止点。   \n
        该方法与{Graph#insert_edges_by_vertex_id(List)} (List)} 不同的是，该方法list中每项是通过pk进行新增。 \n
        如果想通过点id新增边，请调用{Graph#insert_edges_by_vertex_id(List)}    \n
        结果按传入顺序构成集合，集合中包含新增后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含新增后的边信息和错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None，fromPk、fromType、toPk、toType或type值为空，property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_edges(self, items: List[str]) -> List[ResponseItem]:
        """
        批量查询边。通过边id查询边。如果不存在，则会返回异常。\n
        结果按传入顺序构成集合，集合中包含查询的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 边id集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含查询的边信息和错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None、边id格式不正确时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def insert_edge_by_vertex_pk(
            self, from_pk: str, from_type: str, create_from: bool,
            to_pk: str, to_type: str, create_to: bool,
            type: str, property: Union[Dict[str, Any], None]
    ) -> Edge:
        """
        新增边。通过起始点pk和终止点pk新增边。\n
        找不到起始点和终止点时会通过createFrom和createTo决定是否新增无属性的起始点和终止点。

        :param from_pk: 起始点pk，<b>不能为空。</b>
        :param from_type: 起始点类型，<b>不能为空。</b>
        :param create_from: 填True时，如果点不存在，则新增没有属性的起始点，填False，如果点不存在，则抛异常
        :param to_pk: 终止点pk，<b>不能为空。</b>
        :param to_type:  终止点类型，<b>不能为空。</b>
        :param create_to: 填True时，如果点不存在，则新增没有属性的终止点。填False，如果点不存在，则抛异常
        :param type:  边类型，<b>不能为空。</b>
        :param property: 边属性。<b>填None或{}时，表示新增的边没有属性值。</b>
        :return: 新增后的边信息。
       :exception ParamException:            参数格式不正确，当fromPk、fromType、toPk、toType或type值为空、property输入的属性类型不支持时将抛出异常。
       :exception TypeNotFoundException:     边类型不存在时抛出异常。
       :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型时抛出异常。
       :exception VertexNotFoundException:   当createFrom或createTo为False时起始点或终止点在图中不存在时将抛出异常。
       :exception PropertyNotFoundException: 属性名在边类型中没有定义时抛出异常。
       :exception ValueFormatException:      属性值类型错误时抛出异常。
       :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_or_insert_edge_by_vertex_pk(
            self, from_pk: str, from_type: str, create_from: bool,
            to_pk: str, to_type: str, create_to: bool,
            type: str, property: Union[Dict[str, Any], None]
    ) -> Iterator[Edge]:
        """
        查询或新增边。通过起始点pk和终止点pk查询或新增边。\n
        若两点之间此边类型的边存在，则查询并返回两点之间此类型所有边的迭代器。若不存在，则新增一条边并返回。

        :param from_pk: 起始点pk，<b>不能为空。</b>
        :param from_type: 起始点类型，<b>不能为空。</b>
        :param create_from: 填True时，如果点不存在，则添加没有属性的起始点，填False，如果点不存在，则抛异常
        :param to_pk:  终止点pk，<b>不能为空。</b>
        :param to_type: 终止点类型，<b>不能为空。</b>
        :param create_to: 填True时，如果点不存在，则添加没有属性的终止点，填False，如果点不存在，则抛异常
        :param type: 边类型，<b>不能为空。</b>
        :param property: 边属性。<b>填None或{}时，新增的边没有属性值。</b>
        :return: 查询或新增后的边信息迭代器。
        :exception ParamException:            参数格式不正确，当type为空、起始点或终止点类型为空、起始点Pk或终止点Pk小于0、property输入的属性类型不支持时将抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_or_insert_edges_by_vertex_id(self, items: List[EdgeInfoByVertexId]) -> List[ResponseItem]:
        """
        批量查询或新增边。通过起始点id和终止点id查询或新增边。若存在，仅查询并返回所有边信息，属性值不做修改。若不存在，则新增一条边并返回边信息。\n
        结果按传入顺序构成集合，集合中包含查询或新增后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return:  批量操作结果集。包含查询或新增后的边信息和错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空、以及集合中存在None、type为空、起始点id或终止点id小于0、property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_or_insert_edges_by_vertex_pk(self, items: List[EdgeInfoByVertexPk]) -> List[ResponseItem]:
        """
        批量查询或新增边。通过起始点pk和终止点pk查询或新增边。若存在，仅查询并返回所有边信息，属性值不做修改。若不存在，则新增一条边并返回边信息。\n
        结果按传入顺序构成集合，集合中包含查询或新增后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含查询或新增后的边信息和错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None、type为空、起始点或终止点类型为空、起始点pk和终止点pk为空、property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def insert_edges_by_vertex_id(self, items: List[EdgeInfoByVertexId]) -> List[ResponseItem]:
        """
        批量新增边。通过起始点id和终止点id新增边。 \n
        该方法与{Graph#insert_edges_by_vertex_pk(List)} 不同的是，该方法list中每项是通过点id进行新增。\n
        如果想通过pk新增边，请调用{Graph#insert_edges_by_vertex_pk(List)}\n
        结果按传入顺序构成集合，集合中包含新增后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含新增后的边信息和错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None、EdgeInfoById中起始点id或终止点id小于0、type为空或property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def upsert_edge_by_vertex_pk(
        self, from_pk: str, from_type: str, create_from: bool,
        to_pk: str, to_type: str, create_to: bool,
        type: str, property: Union[Dict[str, Any]], is_merge:bool
    ) -> Iterator[Edge]:
        """
        upsertEdgeByVertexPk\n
        新增或更新边。通过起始点pk和终止点pk来新增或修改边。\n
        找不到起始点和终止点时会通过create_from和create_to来决定是否新增无属性的起始点和终止点。\n
        如果起始点到终止点不存在边，则新增一条边。如果存在一条或多条边，则都会比较属性值。\n

        :param from_pk: 起始点pk，<b>不能为空。</b>
        :param from_type: 起始点类型，<b>不能为空。</b>
        :param create_from: 填True时，如果点不存在，则添加没有属性的起始点，填False，如果点不存在，则抛异常
        :param to_pk: 终止点pk，<b>不能为空。</b>
        :param to_type: 终止点类型，<b>不能为空。</b>
        :param create_to: 填True时，如果点不存在，则添加没有属性的终止点。填False，如果点不存在，则抛异常
        :param type: 边类型，<b>不能为空。</b>
        :param property:  边属性。
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 新增或更新后的边信息迭代器。
        :exception ParamException:            参数格式不正确，当from_pk、from_type、to_pk、to_type或type值为空、property输入的属性类型不支持时将抛出异常。
        :exception TypeNotFoundException:     边类型不存在时抛出异常。
        :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型时抛出异常。
        :exception VertexNotFoundException:   当create_from或create_to为False时起始点或终止点在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时抛出异常。
        :exception ValueFormatException:      属性值类型错误时抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def update_edge_by_vertex_pk(
        self, from_pk: str, from_type: str, to_pk: str, to_type: str,
        type: str, property: Union[Dict[str, Any]], is_merge:bool
    ) -> Iterator[Edge]:
        """
        updateEdgeByVertexPk\n
        更新边。通过起始点pk和终止点pk来修改边。\n

        :param from_pk: 起始点pk，<b>不能为空。</b>
        :param from_type: 起始点类型，<b>不能为空。</b>
        :param to_pk: 终止点pk，<b>不能为空。</b>
        :param to_type: 终止点类型，<b>不能为空。</b>
        :param type: 边类型，<b>不能为空。</b>
        :param property:  边属性。
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 更新后的边信息迭代器。
        :exception ParamException:            参数格式不正确，当from_pk、from_type、to_pk、to_type或type值为空、property输入的属性类型不支持时将抛出异常。
        :exception TypeNotFoundException:     边类型不存在时抛出异常。
        :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型时抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时抛出异常。
        :exception ValueFormatException:      属性值类型错误时抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def update_edge_by_vertex_pk_with_condition(
            self, from_pk: str, from_type: str, to_pk: str, to_type: str, type: str,
            edge_condition: Union[VisitCondition, None],
            property: Union[Dict[str, Any]], is_merge: bool
    ) -> Iterator[Edge]:
        """
        updateEdgeByVertexPk\n
        更新边。通过起始点pk和终止点pk来修改边。\n
        找不到起始点和终止点时报错。

        :param from_pk: 起始点pk，<b>不能为空。</b>
        :param from_type: 起始点类型，<b>不能为空。</b>
        :param to_pk: 终止点pk，<b>不能为空。</b>
        :param to_type: 终止点类型，<b>不能为空。</b>
        :param type: 边类型，<b>不能为空。</b>
        :param edge_condition:  边条件过滤，<b>为None不参与计算。</b>
        :param property:  边属性。
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 更新后的边信息迭代器。
        :exception ParamException:            参数格式不正确，当from_pk、from_type、to_pk、to_type或type值为空、property输入的属性类型不支持时将抛出异常。
        :exception TypeNotFoundException:     边类型不存在时抛出异常。
        :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型时抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时抛出异常。
        :exception ValueFormatException:      属性值类型错误时抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError


    def update_edges(self, items: List[EdgeInfo]) -> List[ResponseItem]:
        """
        upsertEdges\n
        批量更新边。通过边id更新边。 \n
        结果按传入顺序构成集合，集合中包含更新后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。

        :param items: 参数列表，<b>不能为空。</b>
        :return: 批量操作结果集。包含更新后的边信息和错误信息。
        :exception ParamException:    参数格式不正确。当参数集合为空，以及集合中存在None、边id格式不正确、property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def upsert_edges_by_vertex_pk(self, items: List[EdgeInfoByVertexPk]) -> List[ResponseItem]:
        """
        upsertEdgesByVertexPk \n
        批量新增或更新边。通过起始点pk和终止点pk新增或修改边。 \n
        找不到起始点和终止点时会通过create_from和create_to决定是否新增无属性的起始点和终止点。 \n
        如果起始点到终止点不存在边，则新增一条边。如果存在一条或多条边，则都会比较属性值。 \n
        结果按传入顺序构成集合，集合中包含新增或更新后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。\n

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含新增或更新后的边信息和错误信息。
        :exception ParamException:     参数格式不正确。当参数集合为空，以及集合中存在None，from_pk、from_type、to_pk、to_type或type值为空，property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def update_edges_by_vertex_pk(self, items: List[EdgeInfoByVertexPk]) -> List[ResponseItem]:
        """
        updateEdgesByVertexPk \n
        批量新增或更新边。通过起始点pk和终止点pk新增或修改边。 \n
        找不到起始点和终止点时会通过create_from和create_to决定是否新增无属性的起始点和终止点。 \n
        如果起始点到终止点不存在边，则新增一条边。如果存在一条或多条边，则都会比较属性值。 \n
        结果按传入顺序构成集合，集合中包含新增或更新后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。\n

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含新增或更新后的边信息和错误信息。
        :exception ParamException:     参数格式不正确。当参数集合为空，以及集合中存在None，from_pk、from_type、to_pk、to_type或type值为空，property输入的属性类型不支持时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def upsert_edge_by_vertex_id(self, from_id: int, to_id: int, type: str, property: Union[Dict[str, Any]], is_merge:bool)\
            -> Iterator[Edge]:
        """
        upsertEdgeByVertexId \n
        新增或更新边。通过起始点id和终止点id来新增或修改边。\n
        如果起始点到终止点不存在边，则新增一条边。如果存在一条或多条边，则都会比较属性值。\n

        :param from_id: 起始点id，<b>不能小于0。</b>
        :param to_id: 终止点id，<b>不能小于0。</b>
        :param type: 边类型，<b>不能为空。</b>
        :param property: 边属性。<b>不能为空。</b>
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 边详细信息迭代器
        :exception ParamException:            参数格式不正确，当fromId、toId小于0或type值为空时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型、property输入的属性类型不支持时将抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def update_edge_by_vertex_id(self, from_id: int, to_id: int, type: str, property: Union[Dict[str, Any]], is_merge:bool)\
            -> Iterator[Edge]:
        """
        updateEdgeByVertexId \n
        更新边。通过起始点id和终止点id来新增或修改边。\n
        如果存在一条或多条边，则都会比较属性值。\n

        :param from_id: 起始点id，<b>不能小于0。</b>
        :param to_id: 终止点id，<b>不能小于0。</b>
        :param type: 边类型，<b>不能为空。</b>
        :param property: 边属性。<b>不能为空。</b>
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 边详细信息迭代器
        :exception ParamException:            参数格式不正确，当fromId、toId小于0或type值为空时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型、property输入的属性类型不支持时将抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def update_edge_by_vertex_id_with_condition(
            self, from_id: int, to_id: int, type: str,
            edge_condition: Union[VisitCondition, None],
            property: Union[Dict[str, Any]], is_merge: bool
    ) -> Iterator[Edge]:
        """
        updateEdgeByVertexId \n
        更新边。通过起始点id和终止点id来新增或修改边。\n
        如果存在一条或多条边，则都会比较属性值。\n

        :param from_id: 起始点id，<b>不能小于0。</b>
        :param to_id: 终止点id，<b>不能小于0。</b>
        :param type: 边类型，<b>不能为空。</b>
        :param edge_condition: 边条件过滤，<b>为None不参与计算。</b>
        :param property: 边属性。<b>不能为空。</b>
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return: 边详细信息迭代器
        :exception ParamException:            参数格式不正确，当fromId、toId小于0或type值为空时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception TypeErrorException:        起始点和终止点的类型不是作为边类型的起始类型和终止类型、property输入的属性类型不支持时将抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在边类型中没有定义时将抛出异常。
        :exception ValueFormatException:      属性值类型错误时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def upsert_edges_by_vertex_id(self, items: List[EdgeInfoByVertexId]) -> List[ResponseItem]:
        """
        upsertEdgesByVertexId \n
        批量新增或更新边。通过起始点id和终止点id新增或修改边。 \n
        如果起始点到终止点不存在边，则新增一条边。如果存在一条或多条边，则都会比较属性值。 \n
        结果按传入顺序构成集合，集合中包含新增或更新后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。 \n

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含新增或更新后的边信息和错误信息。
        :exception ParamException:    参数格式不正确，当from_id、to_id小于0或type值为空、property输入的属性类型不支持时时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def update_edges_by_vertex_id(self, items: List[EdgeInfoByVertexId]) -> List[ResponseItem]:
        """
        updateEdgesByVertexId \n
        更新边。通过起始点id和终止点id修改边。 \n
        如果存在一条或多条边，则都会比较属性值。 \n
        结果按传入顺序构成集合，集合中包含更新后的边信息和错误信息。通过{ResponseItem#is_error()}方法判断操作是否失败。 \n

        :param items: 参数集合，<b>不能为空。</b>
        :return: 批量操作结果集。包含更新后的边信息和错误信息。
        :exception ParamException:    参数格式不正确，当from_id、to_id小于0或type值为空、property输入的属性类型不支持时时将抛出异常。
        :exception DatabaseException: 数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_edge_by_vertex_id(
            self, id: int, edge_type_filter: Union[Set[str], None], direction: Direction, limit_edge: int,
            vertex_condition: Union[VisitCondition, None], edge_condition: Union[VisitCondition, None], get_loop: bool
        ) -> Iterator[Edge]:
        """
        retrieveEdgeByVertexId \n
        查询邻居。通过起始点id查询。

        :param id: 点id，<b>不能小于0。</b>
        :param edge_type_filter: 边类型的过滤条件。只会返回满足参数中边类型的边。填None不参与计算。建议类型过滤使用这个字段，而不是edgeCondition。
        :param direction: 查询方向，<b>不能为None。</b>
        :param limit_edge: 边个数限制，<b>小于0表示不进行限制。</b>
        :param vertex_condition: 点条件，填None不参与计算
        :param edge_condition: 边条件，填None不参与计算
        :param get_loop: True计算自环，False不计算自环
        :return: 边信息迭代器。
        :exception ParamException:            参数格式不正确，当点id小于0、查询方向为None时将抛出异常。
        :exception VertexNotFoundException:   起始点在图中不存在时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 点/边条件过滤对应的属性类型在指定点/边类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_edge_by_src_dst_vertex_id(
            self, src_id: int, dst_id: int, edge_type_filter: Union[Set[str], None], direction: Direction,
            edge_condition: Union[VisitCondition, None] ) -> Iterator[Edge]:
        """
        retrieveEdgeByVertexId\n
        查询邻居。通过起始点id和终止点id查询。

        :param src_id: 起始点id，<b>不能小于0。</b>
        :param dst_id: 终止点id，<b>不能小于0。</b>
        :param edge_type_filter: 边类型的过滤条件。只会返回满足参数中边类型的边。填None不参与计算。
        :param direction: 方向，<b>不能为None。</b>
        :param edge_condition: 边条件，填None不参与计算
        :return: 边信息迭代器。
        :exception ParamException:            参数格式不正确，当起始点或终止点id小于0、查询方向为None时将抛出异常。
        :exception VertexNotFoundException:   起始点或终止点在图中不存在时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 边条件过滤对应的属性类型在指定边类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_edge_by_vertex_pk(
            self, pk: str, type: str, edge_type_filter: Union[Set[str], None], direction: Direction, limit_edge: int,
            vertex_condition: Union[VisitCondition, None], edge_condition: Union[VisitCondition, None], get_loop: bool
        ) -> Iterator[Edge]:
        """
        retrieveEdgeByVertexPk \n
        查询邻居。通过起始点pk和type查询。

        :param pk: 起始点pk，<b>不能为空。</b>
        :param type: 点类型，<b>不能为空。</b>
        :param edge_type_filter: 边类型的过滤条件 。只会返回满足参数中边类型的边。填None不参与计算。建议类型过滤使用这个字段，而不是edge_condition
        :param direction: 查询方向，<b>不能为None。</b>
        :param limit_edge: 边个数限制，<b>小于0表示不进行限制。</b>
        :param vertex_condition: 点条件，填None不参与计算
        :param edge_condition: 边条件，填None不参与计算
        :param get_loop: True计算自环，False不计算自环
        :return: 边信息迭代器。
        :exception ParamException:            参数格式不正确，当点pk和type为空、查询方向为None时将抛出异常。
        :exception VertexNotFoundException:   起始点在图中不存在时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 点/边条件过滤对应的属性类型在指定点/边类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def retrieve_edge_by_vertex_pks(
            self, pk: str, type:str, another_pk: str, another_type: str, edge_type_filter: Union[Set[str], None],
            direction: Direction, limit_edge: int, edge_condition: Union[VisitCondition, None]) -> Iterator[Edge]:
        """
            retrieveEdgeByVertexPk \n
            查询邻居。通过起始点pk和type查询。

            :param pk: 点pk，<b>不能为空。</b>
            :param type: 点类型，<b>不能为空。</b>
            :param another_pk: 点pk，<b>不能为空。</b>
            :param another_type: 点类型，<b>不能为空。</b>
            :param edge_type_filter: 边类型的过滤条件 。只会返回满足参数中边类型的边。填None不参与计算。建议类型过滤使用这个字段，而不是edge_condition
            :param direction: 查询方向，<b>不能为None。</b>
            :param limit_edge: 边个数限制，<b>小于0表示不进行限制。</b>
            :param edge_condition: 边条件，填None不参与计算
            :return: 边信息迭代器。
            :exception ParamException:            参数格式不正确，当点pk和type为空、查询方向为None时将抛出异常。
            :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def search_edges_by_index(self, type_name: str, prop_name: str, data: Any, skip: int, limit: int) -> Iterator[str]:
        """
        通过索引，查找边数据, 返回点id
        :param type_name: 类型名
        :param prop_name: 属性名
        :param data: 所查找的值
        :param skip: 跳过条目
        :param limit: 限制返回数量
        :return:
        """
        raise NotImplementedError

    def search_edge_property(self, edge_type: str, predicates: List[SearchPredicate], orders: List[SearchOrder],
                             skip: int, limit: int) -> Iterator[Edge]:
        """
        通过类型、属性查询边

        :param edge_type: 边类型名
        :param predicates: 查询谓词，每个谓词包括：属性名、查询值
        :param orders: 属性排序
        :param skip: 跳过
        :param limit: 限制返回数量
        :return:
        """
