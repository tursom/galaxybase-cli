# -*- coding    : utf-8 -*-
# @Time         : 2021/3/12 15:13
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from typing import Union, Any

from graphdbapi.interface.graph import GraphInterface


class PropertyValueInterface(GraphInterface):
    def put_property_value(self, is_vertex: bool, id: Union[str, int], property_name: str, value: Any, is_merge:bool) -> None:
        """
        设置某个点或边的某属性值。

        :param is_vertex: 点类型填True，边类型填False，<b>is_vertex需要跟id对应。</b>
        :param id: 点id或边id，<b>不能为空，如果是点id不能小于0，如果是边id格式需要符合长度等于32和16进制规范。</b>
        :param property_name: 属性名，<b>不能为空。</b>
        :param value: 属性值，<b>不能为空。</b>
        :param is_merge: 为True时集合属性追加，为False属性覆盖
        :return:
        :exception ParamException:            参数格式不正确，当点id或边id格式不正确、属性名为空或属性值为空时将抛出异常。
        :exception VertexNotFoundException:   点在图中不存在时将抛出异常。
        :exception EdgeNotFoundException:     边在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在对应类型中不存在时将抛出异常。
        :exception ValueFormatException:      value类型转换失败时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def remove_property_value(self, is_vertex: bool, id: Union[str, int], property_name: str) -> None:
        """
        删除属性值。

        :param is_vertex: 点/边类型填True，边类型填False，<b>is_vertex需要跟id对应。</b>
        :param id: 点/边id，<b>不能为空，如果是点id不能小于0，如果是边id格式需要符合长度等于32和16进制规范。</b>
        :param property_name: 属性名，<b>不能为空。</b>
        :return:
        :exception ParamException:            参数格式不正确，当点/边id格式不正确、属性名为空时将抛出异常。
        :exception VertexNotFoundException:   点在图中不存在时将抛出异常。
        :exception EdgeNotFoundException:     边在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 属性名在对应点/边中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常
        """
        raise NotImplementedError