# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 19:04
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
import json
from typing import Union, Set, Iterator, List

from graphdbapi.types import Edge
from graphdbapi.v1.enum import Direction
from graphdbapi.v1.graph.query.condition import VisitCondition
from graphdbapi.v1.graph.query.bfs import (
    QueryResult,
    BfsParam,
)
from graphdbapi.interface.graph import GraphInterface


class BfsInterface(GraphInterface):
    def shortest_path(self, start_id: int, end_id: int, path_edge_type: Union[Set[str], None], limit: int = 1) -> Iterator[Edge]:
        """
        最短路径,返回一条最短路径的所有边。

        :param start_id: 起始点id，<b>不能小于0。</b>
        :param end_id: 终止点id，<b>不能小于0。</b>
        :param path_edge_type: 路径包含的边类型，填None不进行过滤。
        :param limit:  长度限制
        :return: 边列表的迭代器
        :exception ParamException:          参数格式不正确，当起始点id、终止点id小于0时将抛出异常。
        :exception VertexNotFoundException: 起始点或终止点在图中不存在时将抛出异常。
        :exception TypeNotFoundException:   边类型在图中不存在时将抛出异常。
        :exception DatabaseException:       数据库内部异常。
        """
        raise NotImplementedError

    def bfs_by_param(self, bfs_param: BfsParam) -> QueryResult:
        """多度查询邻居，针对bfs参数进行的封装

        :param bfs_param: bfsMaster参数对象
        :return: bfs查询结果
        """
        raise NotImplementedError

    def bfs_master(
            self, start_id: int, depth: int, limit_neighbor: int, limit_edge: int, dir_list: List[Direction],
            vertex_condition_list: Union[List[VisitCondition], None], edge_condition_list: Union[List[VisitCondition], None],
            edge_type_filter_list: Union[List[Set[str]], None], hop: bool, only_count: bool,
            return_vertex: bool, return_edge: bool) -> QueryResult:
        """
        多度查询邻居。通过起始点id查询。

        :param start_id: 起始点id，<b>不能小于0。</b>
        :param depth: 深度，<b>范围必须为(0-10)。</b>
        :param limit_neighbor: 邻居点上限，填小于0 不参与计算（目前没实现）
        :param limit_edge: 邻居边上限，填小于0 不参与计算
        :param dir_list: 方向集合，需要size = 1 或者 size = depth，不可为None
        :param vertex_condition_list: 点查询条件集合，需要size = 1 或者 size = depth；填None不参与计算
        :param edge_condition_list: 边查询条件集合，需要size = 1 或者 size = depth；填None不参与计算
        :param edge_type_filter_list: 边类型过滤集合，需要size = 1 或者 size = depth；填None不参与计算 以上三个 List 都是和 depth 对应的，如果 size =
                               1，那么这个过滤条件会被复制，每一度都是这个过滤条件， 如果你只想给某一度添加过滤条件，那么应该在 list 的其他位置 add(None);
        :param hop: 是否 启用hop模式，(只返回最外层的点。)
        :param only_count: 是否只返回 count。True表示返回count。
        :param return_vertex: 是否返回结果点集。只有onlyCount为False时生效
        :param return_edge: 是否返回结果边集。只有onlyCount为False时生效
        :return: bfs查询结果
        :exception ParamException:            参数格式不正确，当点id小于0、深度不符合要求，方向集合、点/边条件集合或边类型过滤集合长度不符合要求时将抛出异常。
        :exception VertexNotFoundException:   起始点在图中不存在时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 点/边条件过滤对应的属性类型在指定点/边类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError

    def bfs_master_by_pk(
            self, pk: str, type: str, depth: int, limit_neighbor: int, limit_edge: int, dir_list: List[Direction],
            vertex_condition_list: Union[List[VisitCondition], None], edge_condition_list: Union[List[VisitCondition], None],
            edge_type_filter_list: Union[List[Set[str]], None], hop: bool, only_count: bool,
            return_vertex: bool, return_edge: bool
    ) -> QueryResult:
        """
        多度查询邻居。通过起始点pk查询

        :param pk: 点pk，<b>不能为空。</b>
        :param type: 点类型，<b>不能为空。</b>
        :param depth: 深度，<b>范围必须为(0-10)。</b>
        :param limit_neighbor: 邻居点上限，填小于0 不参与计算（目前没实现）
        :param limit_edge: 邻居边上限，填小于0 不参与计算
        :param dir_list: 方向集合，需要size = 1 或者 size = depth，不可为None
        :param vertex_condition_list: 点查询条件集合，需要size = 1 或者 size = depth；填None不参与计算
        :param edge_condition_list:  边查询条件集合，需要size = 1 或者 size = depth；填None不参与计算
        :param edge_type_filter_list: 边类型过滤集合，需要size = 1 或者 size = depth；填None不参与计算 以上三个 List 都是和 depth 对应的，如果 size =
                                      1，那么这个过滤条件会被复制，每一度都是这个过滤条件， 如果你只想给某一度添加过滤条件，那么应该在 list 的其他位置 add(None);
        :param hop: 是否 启用hop模式，(只返回最外层的点。)
        :param only_count: 是否只返回 count。True表示返回count。
        :param return_vertex: 是否返回结果点集。只有onlyCount为False时生效
        :param return_edge: 是否返回结果边集。只有onlyCount为False时生效
        :return: bfs查询结果
        :exception ParamException:            参数格式不正确，当点pk为空、点类型为空、深度不符合要求，方向集合、点/边条件集合或边类型过滤集合长度不符合要求时将抛出异常。
        :exception VertexNotFoundException:   起始点在图中不存在时将抛出异常。
        :exception TypeNotFoundException:     边类型在图中不存在时将抛出异常。
        :exception PropertyNotFoundException: 点/边条件过滤对应的属性类型在指定点/边类型中不存在时将抛出异常。
        :exception DatabaseException:         数据库内部异常。
        """
        raise NotImplementedError
