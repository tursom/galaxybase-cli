from typing import Any
from graphdbapi import BoltStatementResult


class GraphGroupInterface:
    def execute_procedure(self, procedure_name: str, *input_params: Any) -> BoltStatementResult:
        """
        通过bolt执行procedure方法

        :param procedure_name: procedure方法名。
        :param input_params: 入参（需按照procedure方法的参数顺序）。
        :return: 执行结果迭代器。
        """
        raise NotImplementedError

    def stop_procedure(self, procedure_id: int) ->None:
        """
        停止正在执行的procedure方法

        :param procedure_id: 在执行的procedure标识
        :return:
        """
        raise NotImplementedError
