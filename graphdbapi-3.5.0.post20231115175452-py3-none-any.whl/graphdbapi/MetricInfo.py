
class MetricInfo:
    # 节点id
    __id = ""
    
    # 启动时间
    __nodeStartTime = -1
    
    # 节点地址
    __addresses = set()
    
    # 节点主机名
    __hostName = set()

    # heap Init
    __heapInit = -1
    
    # heap Used
    __heapUsed = -1

    
    # heap Committed
    __heapCommitted = -1
    
     # heap Max
    __heapMax = -1

    
     # heap Total
    __heapTotal = -1

    
     # lastUpdateTime
    __lastUpdateTime = -1
    
     # thread count
    __threadCnt = -1
    
     # daemon thread count
    __daemonThreadCnt = -1

     # peak thread count
    __peakThreadCnt = -1

     # started thread count
    __startedThreadCnt = -1

    # graph info
    __graphMetrics = list()

    def __init__(self, **kwargs):
        for key in kwargs:
            self.__setattr__("__"+key, kwargs[key])

    def get_id(self):
        return self.__id

    def get_node_start_time(self):
        return self.__nodeStartTime

    def get_addresses(self):
        return self.__addresses

    def get_host_name(self):
        return self.__hostName
    
    def get_heap_init(self):
        return self.__heapInit

    def get_heap_used(self):
        return self.__heapUsed

    def get_heap_committed(self):
        return self.__heapCommitted

    def get_heap_max(self):
        return self.__heapMax

    def get_heap_total(self):
        return self.__heapTotal
    
    def get_last_update_time(self):
        return self.__lastUpdateTime

    def get_thread_cnt(self):
        return self.__threadCnt
    
    def get_daemon_thread_cnt(self):
        return self.__daemonThreadCnt

    def get_peak_thread_cnt(self):
        return self.__peakThreadCnt

    def get_started_thread_cnt(self):
        return self.__startedThreadCnt

    def get_graph_metrics(self):
        return self.__graphMetrics
    

