#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020/3/31 16:57
# @Author : jimmy

from os import cpu_count
from sys import platform, version_info
from enum import Enum
from graphdbapi.meta import version

class Language(Enum):
    # 中文
    CN = "CN"
    # 英文
    EN = "EN"

# Auth
TRUST_ON_FIRST_USE = 0  # Deprecated
TRUST_SIGNED_CERTIFICATES = 1  # Deprecated
TRUST_ALL_CERTIFICATES = 2
TRUST_CUSTOM_CA_SIGNED_CERTIFICATES = 3
TRUST_SYSTEM_CA_SIGNED_CERTIFICATES = 4
TRUST_DEFAULT = TRUST_ALL_CERTIFICATES

# Connection Pool Management
INFINITE = -1
DEFAULT_MAX_CONNECTION_LIFETIME = 3600  # 1h
DEFAULT_MAX_CONNECTION_POOL_SIZE = 100
DEFAULT_CONNECTION_TIMEOUT = 30.0  # 30s
DEFAULT_READ_IDLE_DETECTION_TIME = 0  # 0s dont
DEFAULT_THREAD_COUNT = cpu_count() or 1

# Connection Settings
DEFAULT_CONNECTION_ACQUISITION_TIMEOUT = 60  # 1m

# Routing settings
DEFAULT_MAX_RETRY_TIME = 30.0  # 30s
ROUTING_FRESH_TIME = 5.0  # 5s

# 异常语言
DEFAULT_LANGUAGE = None

LOAD_BALANCING_STRATEGY_LEAST_CONNECTED = 0
LOAD_BALANCING_STRATEGY_ROUND_ROBIN = 1
DEFAULT_LOAD_BALANCING_STRATEGY = LOAD_BALANCING_STRATEGY_LEAST_CONNECTED

# Client name
DEFAULT_USER_AGENT = "graphdbapi-python/{} Python/{}.{}.{}-{}-{} ({})".format(
    *((version,) + tuple(version_info) + (platform,)))

default_config = {
    "auth": None,  # provide your own authentication token such as {"username", "password"}
    "encrypted": None,  # default to have encryption enabled if ssl is available on your platform
    "trust": TRUST_DEFAULT,
    "der_encoded_server_certificate": None,

    "user_agent": DEFAULT_USER_AGENT,

    # Connection pool management
    "max_connection_lifetime": DEFAULT_MAX_CONNECTION_LIFETIME,
    "max_connection_pool_size": DEFAULT_MAX_CONNECTION_POOL_SIZE,
    "connection_acquisition_timeout": DEFAULT_CONNECTION_ACQUISITION_TIMEOUT,
    "read_idle_detection_time": DEFAULT_READ_IDLE_DETECTION_TIME,
    "thread_count": DEFAULT_THREAD_COUNT,

    # Connection settings:
    "connection_timeout": DEFAULT_CONNECTION_TIMEOUT,
    "keep_alive": True,

    # Routing settings:
    "max_retry_time": DEFAULT_MAX_RETRY_TIME,
    "load_balancing_strategy": DEFAULT_LOAD_BALANCING_STRATEGY,
    "routing_table_flush_delay": ROUTING_FRESH_TIME,
    "language": DEFAULT_LANGUAGE
}
