# -*- coding    : utf-8 -*-
# @Time         : 2021/3/9 16:12
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
import json
from typing import Dict, Any, Union, List
from decimal import Decimal
from graphdbapi.v1.utils.Assert import Assert
from bolt.message import Param, TipsText
from bolt.types import VariousMap
from bolt.exceptions import ParamException
from graphdbapi.v1.graph import VertexInfoByPk, VertexInfoById, EdgeInfoByVertexPk, EdgeInfoByVertexId, EdgeInfo
from graphdbapi.v1.enum import PropertyType
from graphdbapi.types.spatial import Point


class PropDumps(json.JSONEncoder):
    def __init__(self, *args, allow_null=True, prop_name="", **kwargs):
        self.allow_null = allow_null
        self.prop_name = prop_name
        super(PropDumps, self).__init__(*args, **kwargs)

    def encode(self, o):
        if isinstance(o, (set, tuple, list)):
            res = []
            for _ in o:
                res.append(ValueUtil.get_property(self.prop_name, _, self.allow_null))
            return res
        elif isinstance(o, dict):
            if isinstance(o, VariousMap):
                res = VariousMap()
            else:
                res = {}
            for _ in o:
                res[ValueUtil.get_property(self.prop_name, _, self.allow_null)] = \
                    ValueUtil.get_property(self.prop_name, o[_], self.allow_null)
            return res
        else:
            return ValueUtil.get_property(self.prop_name, o, self.allow_null)


class ValueUtil:
    @staticmethod
    def _get_param_name(param_name: Union[str, Param]):
        if isinstance(param_name, Param):
            param_name = param_name.name
        return param_name

    @staticmethod
    def get_map_value_property(property_map: Union[Dict[str, Any], None], allow_null: bool, param_name: Union[Param, str])\
            -> Dict[str, Any]:
        if isinstance(param_name, Param):
            param_name = param_name.name

        if not property_map:
            if allow_null:
                return {}
            raise ParamException(TipsText.NOT_EMPTY_FORMAT, param_name)

        as_values = {}
        for prop_name in property_map:
            as_values[prop_name] = ValueUtil.get_property(prop_name, property_map[prop_name], allow_null)

        return as_values

    @staticmethod
    def get_property(prop_name: Union[str, Param], value: Any, allow_null: bool):
        prop_name = ValueUtil._get_param_name(param_name=prop_name)
        if value is None:
            if allow_null:
                return None
            raise ParamException(TipsText.NOT_PROP_VALUE_FORMAT, prop_name)
        if isinstance(value, str):
            return value
        if isinstance(value, bytes) or isinstance(value, bytearray):
            return int.from_bytes(value, "big", signed=True)
        if isinstance(value, Decimal):
            return value.to_eng_string()
        if isinstance(value, Point):
            return value
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            return value
        if isinstance(value, bool):
            return value
        if isinstance(value, VariousMap):
            return json.dumps(value, cls=PropDumps, ensure_ascii=False, prop_name=prop_name, allow_null=allow_null)
        if isinstance(value, (list, set, tuple)):
            return json.dumps(value, cls=PropDumps, ensure_ascii=False, prop_name=prop_name, allow_null=allow_null)
        raise ParamException(TipsText.PROP_TYPE_ERROR_FORMAT, prop_name, value.__class__.__name__)

    @staticmethod
    def vertex_info_by_pk(pk: str, type: str, property: Union[Dict[str, Any], None], allow_null: bool, allow_empty=False, is_merge=True):
        if property is None:
            property = {}

        Assert.not_empty_allowed(pk, Param.pk)
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}

        parameters[Param.pk.get_index_str()] = pk
        parameters[Param.type.get_index_str()] = type
        parameters[Param.isMerge.get_index_str()] = is_merge
        parameters[Param.property.get_index_str()] = ValueUtil.get_map_value_property(property, allow_null, Param.property)

        return parameters

    @staticmethod
    def vertex_info_by_id(id: int, property: Union[Dict[str, Any], None], allow_null: bool, is_merge: bool = True):
        if property is None:
            property = {}

        Assert.positive_allowed(id, Param.id)

        parameters = {}

        parameters[Param.id.get_index_str()] = id
        parameters[Param.isMerge.get_index_str()] = is_merge
        parameters[Param.property.get_index_str()] = ValueUtil.get_map_value_property(property, allow_null, Param.property)

        return parameters

    @staticmethod
    def vertex_info_by_pks(items: List[VertexInfoByPk], allow_null: bool, param_name: Param) -> Dict[str, List[Dict[str, Any]]]:
        # 对 VertexInfoByPk 列表进行转换，转换成支持传输的结构。
        # 对列表参数检查
        parameters = {}
        parameter = []

        for info in items:
            parameter.append(
                ValueUtil.vertex_info_by_pk(
                    info.get_pk(), info.get_type(), info.get_property(), allow_null,
                    allow_empty=True, is_merge=info.get_is_merge()
                )
            )

        parameters[Param.list.get_index_str()] = parameter

        return parameters

    @staticmethod
    def vertex_info_by_ids(items: List[VertexInfoById], allow_null: bool, param_name: Param) \
            -> Dict[str, List[Dict[str, Any]]]:
        parameters = {}
        parameter = []

        for info in items:
            parameter.append(ValueUtil.vertex_info_by_id(info.get_id(), info.get_property(), allow_null, is_merge=info.get_is_merge()))

        parameters[Param.list.get_index_str()] = parameter

        return parameters

    @staticmethod
    def edge_info_by_id(from_id: int, to_id: int, type: str, property: Union[Dict[str, Any], None], allow_null: bool, is_merge=True):
        Assert.positive_allowed(from_id, Param.fromId)
        Assert.positive_allowed(to_id, Param.toId)
        Assert.not_empty_allowed(type, Param.type)

        parameter = {}
        parameter[Param.fromId.get_index_str()] = from_id
        parameter[Param.toId.get_index_str()] = to_id
        parameter[Param.type.get_index_str()] = type
        parameter[Param.isMerge.get_index_str()] = is_merge
        parameter[Param.property.get_index_str()] = ValueUtil.get_map_value_property(property, allow_null, Param.property)

        return parameter

    @staticmethod
    def edge_info_by_ids(items: List[EdgeInfoByVertexId], allow_null: bool, param_name: Union[Param, str]):
        parameters = {}
        parameter = []

        for info in items:
            parameter.append(ValueUtil.edge_info_by_id(info.get_from_id(), info.get_to_id(),
                                info.get_type(), info.get_property(), allow_null, is_merge=info.get_is_merge()))

        parameters[Param.list.get_index_str()] = parameter

        return parameters

    @staticmethod
    def edge_info_by_pks(items: List[EdgeInfoByVertexPk], allow_null: bool, param_name: Union[Param, str]):
        parameters = {}
        parameter = []

        for info in items:
            parameter.append(ValueUtil.edge_info_by_pk(
                info.get_from_pk(), info.get_from_type(), info.is_create_from(),
                info.get_to_pk(), info.get_to_type(), info.is_create_to(),
                info.get_type(), info.get_property(), allow_null, is_merge=info.get_is_merge()
            ))
        parameters[Param.list.get_index_str()] = parameter
        return parameters

    @staticmethod
    def edge_info_by_pk(
            from_pk: str, from_type:str, create_from: bool,
            to_pk: str, to_type: str, create_to: bool,
            type: str, property: Dict[str, Any], allow_null: bool, is_merge=True
    ):
        Assert.not_empty_allowed(type, Param.edgeType)
        Assert.not_empty_allowed(from_pk, Param.fromPk)
        Assert.not_empty_allowed(from_type, Param.fromType)
        Assert.not_empty_allowed(to_pk, Param.toPk)
        Assert.not_empty_allowed(to_type, Param.toType)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.fromPk.get_index_str()] = from_pk
        parameters[Param.fromType.get_index_str()] = from_type
        parameters[Param.toPk.get_index_str()] = to_pk
        parameters[Param.toType.get_index_str()] = to_type
        parameters[Param.createFrom.get_index_str()] = create_from
        parameters[Param.createTo.get_index_str()] = create_to
        parameters[Param.isMerge.get_index_str()] = is_merge
        parameters[Param.property.get_index_str()] = ValueUtil.get_map_value_property(property, allow_null, Param.property)

        return parameters

    @staticmethod
    def edge_accurate(
        type: str, from_pk: str, from_type: str,
        to_pk: str, to_type: str,
        property_name: Union[str, None], property_value: Any
    ):
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(from_pk, Param.fromPk)
        Assert.not_empty_allowed(from_type, Param.fromType)
        Assert.not_empty_allowed(to_pk, Param.toPk)
        Assert.not_empty_allowed(to_type, Param.toType)

        if property_name:
            Assert.not_null_allowed(property_value, Param.propertyValue)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.fromPk.get_index_str()] = from_pk
        parameters[Param.fromType.get_index_str()] = from_type
        parameters[Param.toPk.get_index_str()] = to_pk
        parameters[Param.toType.get_index_str()] = to_type

        if property_name:
            parameters[Param.propertyName.get_index_str()] = property_name
            parameters[Param.propertyValue.get_index_str()] = ValueUtil.get_property(Param.propertyValue, property_value, False)

        return parameters

    @staticmethod
    def edge_info_by_edge_ids(items: List[EdgeInfo], allow_null: bool, param_name: Union[Param, str]):
        parameters = {}
        parameter = []

        for info in items:
            Assert.edge_id_allowed(info.get_edge_id(), Param.edgeId)

            map = {}
            map[Param.edgeId.get_index_str()] = info.get_edge_id()
            map[Param.isMerge.get_index_str()] = info.get_is_merge()
            map[Param.property.get_index_str()] = ValueUtil.get_map_value_property(info.get_property(), allow_null, Param.property)
            parameter.append(map)
        parameters[Param.list.get_index_str()] = parameter

        return parameters

    @staticmethod
    def class_map_to_string(class_map: Union[Dict[str, PropertyType], None], param_name: Union[Param, str]):
        v = {}
        if class_map is not None:
            param_name = ValueUtil._get_param_name(param_name=param_name)
            for key in class_map:
                if not key:
                    raise ParamException(TipsText.NOT_PROP_NAME_FORMAT, param_name)
                v[key] = ValueUtil.property_type_to_map_value(class_map[key])
        return v

    @staticmethod
    def property_type_to_map_value(prop_type: PropertyType):
        v = {}
        if prop_type is not None:
            v[Param.dataType.get_index_str()] = prop_type.name
            if PropertyType.is_collection(prop_type):
                v[Param.firstSign.get_index_str()] = prop_type.firstSign.name
            elif PropertyType.is_map(prop_type):
                v[Param.firstSign.get_index_str()] = prop_type.firstSign.name
                v[Param.secondSign.get_index_str()] = prop_type.secondSign.name
        return v

    @staticmethod
    def combine_repeat_allowed(allow_repeat: bool, combine_key, class_map: Union[Dict[str, PropertyType], None]):
        if not combine_key:
            return

        if allow_repeat:
            raise ParamException(TipsText.RELEVANCE_PARAM_FORMAT,
                                 Param.allowRepeat.name, allow_repeat, Param.combineKey.name, combine_key)

        if combine_key not in (class_map or {}):
            raise ParamException(TipsText.INCLUDE_PARAM_FORMAT, Param.classMap.name, Param.combineKey.name)