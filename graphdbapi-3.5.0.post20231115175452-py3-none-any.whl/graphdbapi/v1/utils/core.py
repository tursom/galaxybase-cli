# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 17:27
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
import json
from enum import Enum


class Serializable:
    @staticmethod
    def __property_dict__(obj):
        __dict__ = {}
        for key in filter(lambda item: "__" in item and not item.endswith("__"), obj.__dict__):
            __dict__[Serializable.__parse_dict_key(key)] = obj.__dict__[key]

        return __dict__

    @staticmethod
    def __parse_dict_key(key):
        return "".join(
            [item.title() if index else item for index, item in enumerate(key.split("__", maxsplit=1)[-1].split("_"))])

    @staticmethod
    def __encode_json__(obj):
        return json.dumps(Serializable.__property_dict__(obj), cls=NpEncoder, ensure_ascii=False)


class MyJSONEncoder(json.JSONEncoder):
    def default(self, o):
        if not isinstance(o, (list, tuple, dict, str, int, float)) or o is None:
            attrs = dir(o)
            result = {attr: getattr(o, attr) for attr in attrs
                      if not attr.startswith('__') and not callable(getattr(o, attr))}
            return result
        return super(MyJSONEncoder, self).default(o)


# json转换
class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if hasattr(obj, "Serializable"):
            return obj.Serializable.__property_dict__(obj)
        elif isinstance(obj, Enum):
            return obj.name
        elif isinstance(obj, set):
            return list(obj)
        else:
            return super(NpEncoder, self).default(obj)


def release(result):
    for _ in result:
        pass
