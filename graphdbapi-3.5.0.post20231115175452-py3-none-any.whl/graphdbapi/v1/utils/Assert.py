# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 15:28
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
import re

from typing import Union, List, Dict, Any, Callable

from bolt.message import Param
from bolt.message.exceptions import ParamException
from graphdbapi.v1.enum import PropertyType

from bolt.message.TipsText import TipsText


class Assert:
    MAX_DEPTH = 10
    param_assert = {}

    @classmethod
    def register(cls, param: str, ast: Callable, param_key: Union[Param, str]):
        cls.param_assert[param] = {"ast": ast, "param": param_key}

    @classmethod
    def auto_check(cls, func):
        def ast(*args, **kwargs):
            varnames = func.__code__.co_varnames
            for i in range(func.__code__.co_argcount):
                param_name = varnames[i]
                if param_name in cls.param_assert:
                    Assert.param_assert[param_name]["ast"](
                        kwargs[param_name] if param_name in kwargs else args[i],
                        Assert.param_assert[param_name]["param"]
                    )
            return func(*args, **kwargs)
        return ast

    @staticmethod
    def get_param_name(param_name: Union[str, Param]) -> str:
        """
        提取参数名

        :param param_name:
        :return:
        """
        if isinstance(param_name, Param):
            param_name = param_name.name
        return param_name

    @staticmethod
    def positive_allowed(param: int, param_name: Union[str, Param]):
        """
        大于等于0的正整数通过

        :param param:
        :param param_name:
        :return:
        """
        param_name = Assert.get_param_name(param_name)

        if param < 0:
            raise ParamException(TipsText.POSITIVE_FORMAT, param_name)

    @staticmethod
    def deep_allowed(param: int, param_name: Union[str, Param]):
        """
        指定度数范围通过

        :param param:
        :param param_name:
        :return:
        """
        param_name = Assert.get_param_name(param_name)

        if param <= 0:
            raise ParamException(TipsText.DEPTH_ERROR_FORMAT, param_name, 0)

    @staticmethod
    def depth_list_allowed(param: List, depth: int, param_name: Union[str, Param], allow_null=False, allow_empty=False):
        """
        度数列表应等于1或者等于度数

        :param param:
        :param depth:
        :param param_name:
        :return:
        """

        param_name = Assert.get_param_name(param_name)

        if not param and not allow_null:
            raise ParamException(TipsText.NOT_EMPTY_FORMAT, param_name)

        if not param:
            return

        if param.__len__() != 1 and param.__len__() != depth:
            raise ParamException(TipsText.DEPTH_LIST_ERROR_FORMAT, param_name)

    @staticmethod
    def combine_repeat_allowed(allow_repeat: bool, combine_key: str, class_map: Dict[str, PropertyType]):
        """
         对基于属性去重的值进行判断，
         allowRepeat为True，combineKey必须为null
         allowRepeat为False，combineKey必须在classMap的key中

        :param allow_repeat:
        :param combine_key:
        :param class_map:
        :return:
        """
        if allow_repeat and combine_key:
            raise ParamException(TipsText.RELEVANCE_PARAM_FORMAT, Param.allowRepeat.name, allow_repeat,
                                 Param.combineKey.name, combine_key)

        if not allow_repeat and combine_key not in class_map:
            raise ParamException(TipsText.INCLUDE_PARAM_FORMAT, Param.classMap.name, Param.combineKey.name)

    @staticmethod
    def not_empty_allowed(param: str, param_name: Union[str, Param]):
        """
        非空通过

        :param param:
        :param param_name:
        :return:
        """
        param_name = Assert.get_param_name(param_name)

        if not param:
            raise ParamException(TipsText.NOT_EMPTY_FORMAT, param_name)

    @staticmethod
    def edge_id_allowed(param: str, param_name: Union[str, Param]):
        """
        边id通过

        :param param:
        :param param_name:
        :return:
        """
        Assert.not_empty_allowed(param, param_name)

        if not re.match("^[A-Fa-f0-9]{40,}$", param):
            raise ParamException(TipsText.FORMAT_ERROR, param_name)

    @staticmethod
    def not_null_allowed(param: Any, param_name: Union[str, Param]):
        """
        非None通过

        :param param:
        :param param_name:
        :return:
        """
        param_name = Assert.get_param_name(param_name)
        if param is None:
            raise ParamException(TipsText.NOT_EMPTY_FORMAT, param_name)

    @staticmethod
    def id_allowed(id: Union[str, int], is_vertex: bool, param_name: Union[str, Param]):
        """
        判断是否是id，可能是点id或者边id
        :param id:
        :param is_vertex:
        :param param_name:
        :return:
        """
        param_name = Assert.get_param_name(param_name)

        if is_vertex:
            if not isinstance(id, int):
                raise ParamException(TipsText.TYPE_ERROR_FORMAT, param_name)
            Assert.positive_allowed(id, param_name)
        else:
            if not isinstance(id, str):
                raise ParamException(TipsText.TYPE_ERROR_FORMAT, param_name)

            Assert.edge_id_allowed(id, param_name)

    @staticmethod
    def not_equals_allowed(o1: Any, o2: Any, param1_name: Union[str, Param], param2_name: Union[str, Param]):
        """
        不相等时通过

        :param o1:
        :param o2:
        :param param1_name:
        :param param2_name:
        :return:
        """
        param1_name = Assert.get_param_name(param1_name)
        param2_name = Assert.get_param_name(param2_name)

        if o1 == o2:
            raise ParamException(TipsText.NOT_EQUALS_FORMAT, param1_name, param2_name)


# OpenCypher
Assert.register("cypher", Assert.not_empty_allowed, Param.cypher)
Assert.register("task_id", Assert.positive_allowed, Param.taskId)
# Vertex
Assert.register("pk", Assert.not_empty_allowed, Param.pk)
Assert.register("type", Assert.not_empty_allowed, Param.type)
Assert.register("vertex_type", Assert.not_empty_allowed, Param.type)
Assert.register("type_name", Assert.not_empty_allowed, Param.typeName)
Assert.register("prop_name", Assert.not_empty_allowed, Param.propertyName)
Assert.register("property_value", Assert.not_null_allowed, Param.propertyValue)
