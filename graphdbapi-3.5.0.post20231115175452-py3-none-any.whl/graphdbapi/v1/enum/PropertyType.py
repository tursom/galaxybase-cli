# -*- coding    : utf-8 -*-
# @Time         : 2021/3/3 18:45
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from enum import Enum
from typing import Dict

from bolt.message.exceptions.ParamException import ParamException
from bolt.message.TipsText import TipsText


class PrimitiveDataType(Enum):
    BYTE = 0
    INT = 1
    UINT = 2
    LONG = 3
    FLOAT = 4
    DOUBLE = 5
    BIGDECIMAL = 6
    CHAR = 7
    STRING = 8
    BOOLEAN = 9
    DATETIME = 10
    GEOGRAPHICPOINT = 11
    CARTESIANPOINT = 12
    LIST = 13
    SET = 14
    MAP = 15


class PropertyType:
    BYTE = None
    INT = None
    UINT = None
    LONG = None
    FLOAT = None
    DOUBLE = None
    BIGDECIMAL = None
    CHAR = None
    STRING = None
    BOOLEAN = None
    DATETIME = None
    GEOGRAPHICPOINT = None
    CARTESIANPOINT = None

    def __init__(self, primitiveDataType):
        self.primitiveDataType = primitiveDataType
        self.firstSign = None
        self.secondSign = None

    def get_first_sign(self):
        return self.firstSign

    def get_second_sign(self):
        return self.secondSign

    def get_primitive_data_type(self):
        return self.primitiveDataType

    @property
    def name(self):
        return self.get_primitive_data_type().name

    @staticmethod
    def is_set(propertyType):
        if hasattr(propertyType, "get_primitive_data_type"):
            propertyType = propertyType.get_primitive_data_type()
        if propertyType == PrimitiveDataType.SET:
            return True
        return False

    @staticmethod
    def is_list(propertyType):
        if hasattr(propertyType, "get_primitive_data_type"):
            propertyType = propertyType.get_primitive_data_type()
        if propertyType == PrimitiveDataType.LIST:
            return True
        return False

    @staticmethod
    def is_map(propertyType):
        if hasattr(propertyType, "get_primitive_data_type"):
            propertyType = propertyType.get_primitive_data_type()
        if propertyType == PrimitiveDataType.MAP:
            return True
        return False

    @staticmethod
    def is_geographic_point(propertyType):
        if hasattr(propertyType, "get_primitive_data_type"):
            propertyType = propertyType.get_primitive_data_type()
        if propertyType == PrimitiveDataType.GEOGRAPHICPOINT:
            return True
        return False

    @staticmethod
    def is_cartesian_point(propertyType):
        if hasattr(propertyType, "get_primitive_data_type"):
            propertyType = propertyType.get_primitive_data_type()
        if propertyType == PrimitiveDataType.CARTESIANPOINT:
            return True
        return False

    @staticmethod
    def is_point(propertyType):
        if PropertyType.is_geographic_point(propertyType) or PropertyType.is_cartesian_point(propertyType):
            return True
        return False

    @staticmethod
    def is_collection(propertyType):
        if PropertyType.is_set(propertyType) or PropertyType.is_list(propertyType):
            return True
        return False

    @staticmethod
    def build_list(firstSign: PrimitiveDataType):
        if hasattr(firstSign, "get_primitive_data_type"):
            firstSign = firstSign.get_primitive_data_type()
        PropertyType.validate_build_collection(firstSign)
        self = PropertyType(PrimitiveDataType.LIST)
        self.firstSign = firstSign
        return self

    @staticmethod
    def build_set(firstSign: PrimitiveDataType):
        if hasattr(firstSign, "get_primitive_data_type"):
            firstSign = firstSign.get_primitive_data_type()
        PropertyType.validate_build_collection(firstSign)
        self = PropertyType(PrimitiveDataType.SET)
        self.firstSign = firstSign
        return self

    @staticmethod
    def build_map(keyPrimitiveDataType: PrimitiveDataType, valuePrimitiveDataType: PrimitiveDataType):
        if hasattr(keyPrimitiveDataType, "get_primitive_data_type"):
            keyPrimitiveDataType = keyPrimitiveDataType.get_primitive_data_type()
        if hasattr(valuePrimitiveDataType, "get_primitive_data_type"):
            valuePrimitiveDataType = valuePrimitiveDataType.get_primitive_data_type()

        PropertyType.validate_build_map(keyPrimitiveDataType, valuePrimitiveDataType)

        self = PropertyType(PrimitiveDataType.MAP)
        self.firstSign = keyPrimitiveDataType
        self.secondSign = valuePrimitiveDataType
        return self

    def __eq__(self, other):
        if not isinstance(other, PropertyType):
            return False
        if PropertyType.is_collection(self) and PropertyType.is_collection(other):
            return self.get_primitive_data_type() == other.get_primitive_data_type() and \
                   self.get_first_sign() == other.get_first_sign()

        return self.get_primitive_data_type() == other.get_primitive_data_type()

    @staticmethod
    def build_by_prop_key(record: Dict[str, str]):
        if record["primitiveDataType"] == "LIST":
            obj = PropertyType.build_list(PrimitiveDataType.__members__[record["firstSign"]])
        elif record["primitiveDataType"] == "SET":
            obj = PropertyType.build_set(PrimitiveDataType.__members__[record["firstSign"]])
        elif record["primitiveDataType"] == "MAP":
            obj = PropertyType.build_map(
                PrimitiveDataType.__members__[record["firstSign"]], PrimitiveDataType.__members__[record["secondSign"]])
        else:
            obj = PropertyType(PrimitiveDataType.__members__[record["primitiveDataType"]])
        return obj

    @staticmethod
    def validate_build_collection(primitiveDataType):
        if primitiveDataType == None:
            raise ParamException(TipsText.NOT_EMPTY_FORMAT, "primitiveDataType")
        if not isinstance(primitiveDataType, PrimitiveDataType):
            raise ParamException(TipsText.PROPERTY_TYPE_FORMAT, "primitiveDataType")

        if PropertyType.is_collection(primitiveDataType) or \
                PropertyType.is_map(primitiveDataType) or \
                PropertyType.is_point(primitiveDataType):
            raise ParamException(TipsText.PROPERTY_TYPE_COLLECTION_FORMAT, "primitiveDataType")

    @staticmethod
    def validate_build_map(keyPrimitiveDataType: PrimitiveDataType, valuePrimitiveDataType: PrimitiveDataType):
        def validate(pdt, sign):
            if pdt == None:
                raise ParamException(TipsText.NOT_EMPTY_FORMAT, sign)
            if not isinstance(pdt, PrimitiveDataType):
                raise ParamException(TipsText.PROPERTY_TYPE_FORMAT, sign)

            if PropertyType.is_collection(pdt) or \
                    PropertyType.is_map(pdt) or \
                    PropertyType.is_point(pdt):
                raise ParamException(TipsText.PROPERTY_TYPE_COLLECTION_FORMAT, sign)

        validate(keyPrimitiveDataType, "keyPrimitiveDataType")
        validate(valuePrimitiveDataType, "valuePrimitiveDataType")

    def __str__(self):
        if self.firstSign:
            return "%s[%s]" % (self.primitiveDataType.name, self.firstSign.name)
        elif self.secondSign:
            return "%s[%s, %s]" % (self.primitiveDataType.name, self.firstSign.namem, self.secondSign.name)
        else:
            return self.primitiveDataType.name


PropertyType.BYTE = PropertyType(PrimitiveDataType.BYTE)
PropertyType.INT = PropertyType(PrimitiveDataType.INT)
PropertyType.UINT = PropertyType(PrimitiveDataType.UINT)
PropertyType.LONG = PropertyType(PrimitiveDataType.LONG)

PropertyType.FLOAT = PropertyType(PrimitiveDataType.FLOAT)
PropertyType.DOUBLE = PropertyType(PrimitiveDataType.DOUBLE)
PropertyType.BIGDECIMAL = PropertyType(PrimitiveDataType.BIGDECIMAL)

PropertyType.CHAR = PropertyType(PrimitiveDataType.CHAR)
PropertyType.STRING = PropertyType(PrimitiveDataType.STRING)

PropertyType.BOOLEAN = PropertyType(PrimitiveDataType.BOOLEAN)
PropertyType.DATETIME = PropertyType(PrimitiveDataType.DATETIME)

PropertyType.GEOGRAPHICPOINT = PropertyType(PrimitiveDataType.GEOGRAPHICPOINT)
PropertyType.CARTESIANPOINT = PropertyType(PrimitiveDataType.CARTESIANPOINT)