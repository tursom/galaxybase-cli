# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 14:55
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from enum import Enum


class QueryMethod(Enum):
    # 只有字符串类型可以使用;
    # data 与 value 相同
    EqualString = 0

    # 只有数值类型可以使用;
    # data = value
    EqualNumber = 1

    # 只有字符串类型可以使用;
    # data 与 value 不相同
    NotEqualString = 2

    # 只有数值类型可以使用;
    # data != value
    NotEqualNumber = 3

    # 只有数值类型可以使用;
    # data 大于 value
    More = 4

    # 只有数值类型可以使用;
    # data 大于等于 value
    MoreOrEqual = 5

    # 只有数值类型可以使用;
    # data 小于 value
    Less = 6

    # 只有数值类型可以使用;
    # data 小于等于 value
    LessOrEqual = 7

    # 只有数值类型可以使用;
    # min 小于 data 小于 max
    MoreAndLess = 8

    # 只有数值类型可以使用;
    # min 小于 data 小于等于 max
    MoreAndLessEqual = 9

    # 只有数值类型可以使用;
    # min 小于等于 data 小于 max
    MoreEqualAndLess = 10

    # 只有数值类型可以使用;
    # min 小于等于 data 小于等于 max
    MoreEqualAndLessEqual = 11

    # 只有字符串类型可以使用;
    # data.length 大于 value
    LengthMore = 12

    # 只有字符串类型可以使用;
    # data.length 大于等于 value
    LengthMoreOrEqual = 13

    # 只有字符串类型可以使用;
    # data.length 小于 value
    LengthLess = 14

    # 只有字符串类型可以使用;
    # data.length 小于等于 value
    LengthLessOrEqual = 15

    # 只有字符串类型可以使用;
    # min 小于 data.length 小于 max
    LengthMoreAndLess = 16

    # 只有字符串类型可以使用;
    # min 小于 data.length 小于等于 max
    LengthMoreAndLessEqual = 17

    # 只有字符串类型可以使用;
    # min 小于等于 data.length 小于 max
    LengthMoreEqualAndLess = 18

    # 只有字符串类型可以使用;
    # min 小于等于 data.length 小于等于 max
    LengthMoreEqualAndLessEqual = 19

    # 只有字符串类型可以使用;
    # 是否以当前的值为起始
    StartsWith = 20

    # 只有字符串类型可以使用;
    # 不允许以当前值为起始
    NotStartWith = 21

    # 只有字符串类型可以使用;
    # 是否以当前的值为终止
    EndWith = 22

    # 只有字符串类型可以使用;
    # 不允许以当前值为终止
    NotEndWith = 23

    # 只有字符串类型可以使用;
    # 是否包含当前的值
    Contains = 24

    # 只有字符串类型可以使用;
    # 不允许包含当前值
    NotContains = 25

    # 只有集合类型可以使用;
    # data.size 大于 value
    SizeMore = 26

    # 只有集合类型可以使用;
    # data.size 大于等于 value
    SizeMoreOrEqual = 27

    # 只有集合类型可以使用;
    # data.size 小于 value
    SizeLess = 28

    # 只有集合类型可以使用;
    # data.size 小于等于 value
    SizeLessOrEqual = 29

    # 只有集合类型可以使用;
    # min 小于 data.size 小于 max
    SizeMoreAndLess = 30

    # 只有集合类型可以使用;
    # min 小于 data.size 小于等于 max
    SizeMoreAndLessEqual = 31

    # 只有集合类型可以使用;
    # min 小于等于 data.size 小于 max
    SizeMoreEqualAndLess = 32

    # 只有集合类型可以使用;
    # min 小于等于 data.size 小于等于 max
    SizeMoreEqualAndLessEqual = 33

    # 只集合类型可以使用;
    # 是否包含当前的值
    Has = 34