from enum import Enum


class Isolation(Enum):
    """
    事务隔离级别
    """
    # 读提交
    READ_COMMITTED = 0

    # 重复读
    REPEATABLE_READ = 1
