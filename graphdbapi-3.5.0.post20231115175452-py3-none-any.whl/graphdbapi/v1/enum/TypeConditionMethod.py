# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 15:57
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from enum import Enum


class TypeConditionMethod(Enum):
    """
    类型过滤符号，是{VisitConditionByType}的依赖类
    """
    # 在设定的集合中存在，则为true，否则为false
    InSet = 0

    # 在设定的集合中不存在，则为true，否则为false
    NotSet = 1