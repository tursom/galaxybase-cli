from enum import Enum


class SearchType(Enum):
    # 需要字符型值

    # 包含
    CONTAINS = "CONTAINS"
    # 前缀
    PREFIX = "PREFIX"
    # 后缀
    SUFFIX = "SUFFIX"

    # 需要number型值

    # 小于等于
    LESS_THAN = "LESS_THAN"
    # 大于等于
    GREATER_THAN = "GREATER_THAN"
    # 范围
    RANGE_NUMBER = "RANGE_NUMBER"

    # object值都可

    # 等于
    EQUAL = "EQUAL"
