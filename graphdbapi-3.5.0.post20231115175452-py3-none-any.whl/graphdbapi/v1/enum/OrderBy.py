from enum import Enum


class OrderBy(Enum):
    # 升序
    ASC = "ASC"
    # 降序
    DESC = "DESC"
