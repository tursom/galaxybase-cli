# -*- coding    : utf-8 -*-
# @Time         : 2021/3/2 10:21
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from enum import Enum


class Direction(Enum):
    # 出边
    OUT = 0
    # 入边
    IN = 1
    # 无向
    BOTH = 2