# -*- coding    : utf-8 -*-
# @Time         : 2021/3/1 14:39
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from enum import Enum

class CypherTaskStatus(Enum):
    # 任务等待执行
    PENDING = 0

    # 任务执行中
    EXECUTING = 1

    # 任务执行成功
    SUCCESS = 2

    # 任务执行失败
    FAIL = 3
