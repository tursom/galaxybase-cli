# -*- coding    : utf-8 -*-
# @Time         : 2021/3/9 18:39
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
# 批量添加点的基础信息封装
from typing import Dict, Any, Union


class VertexInfoById:
    # 点id
    __id = -1
    # 点属性
    __property = None
    __is_merge = True

    @staticmethod
    def init_vertex_info_by_id(id: int, property: Union[Dict[str, Any], None], is_merge:bool):
        self = VertexInfoById()
        self.__id = id
        self.__is_merge = is_merge
        self.__property = property if property else {}
        return self

    def get_id(self) -> int:
        return self.__id

    def get_property(self) -> Dict[str, Any]:
        return self.__property

    def get_is_merge(self) -> bool:
        return self.__is_merge
