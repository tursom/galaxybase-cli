# -*- coding    : utf-8 -*-
# @Time         : 2021/3/9 16:54
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from typing import Union, List
from graphdbapi.types import Vertex, Edge


class ResponseItem:
    """
    返回消息内容
    """
    __error = False
    __message = ""
    __data = None

    @staticmethod
    def success(data: Union[Vertex, Edge, List[Edge], None]):
        self = ResponseItem()
        self.__data = data
        return self

    @staticmethod
    def error(message: str):
        self = ResponseItem()
        self.__error = True
        self.__message = message
        return self

    def is_error(self) -> bool:
        return self.__error

    def message(self) -> str:
        return self.__message

    def data(self) -> Union[Vertex, Edge]:
        return self.__data