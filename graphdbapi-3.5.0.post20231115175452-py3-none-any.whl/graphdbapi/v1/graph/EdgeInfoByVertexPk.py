# -*- coding    : utf-8 -*-
# @Time         : 2021/3/3 14:31
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from typing import Dict, Any, Union


class EdgeInfoByVertexPk:
    """
    批量添加边的基础信息封装
    """
    # 起始点主键值。由于通过边类型能确定起始类型和终止类型，因此这里需要填点类型
    __from_pk = ""
    __to_pk = ""
    __from_type = ""
    __to_type = ""
    __create_from = False
    __create_to = False
    __type = ""
    __property = None
    __is_merge = True

    @staticmethod
    def init_edge_info_by_vertex_pk(from_pk: str, from_type: str, to_pk: str, to_type: str,
                                            type: str, property: Union[Dict[str, Any], None], is_merge=True):
        """
        根据点主键创建边。如果起始点或终止点不存在，则会抛异常

        :param is_merge:
        :param from_pk: 起始点主键值。由于通过边类型能确定起始类型和终止类型，因此这里需要填点类型
        :param from_type: 起始点类型
        :param to_pk: 终止点主键值。由于通过边类型能确定起始类型和终止类型，因此这里需要填点类型
        :param to_type: 终止点类型
        :param type: 边类型
        :param property: 边属性
        :return:
        """
        self = EdgeInfoByVertexPk()
        self.__from_pk = from_pk
        self.__from_type = from_type
        self.__to_pk = to_pk
        self.__to_type = to_type
        self.__type = type
        self.__property = property or {}
        self.__is_merge = is_merge
        return self

    @staticmethod
    def init_edge_info_by_vertex_pk_with_create(
        from_pk: str, from_type: str, create_from: bool,
        to_pk: str, to_type: str, create_to: bool, type: str,
    property: Union[Dict[str, Any], None], is_merge=True):
        """
        根据点主键创建边。

        :param from_pk: 起始点主键值。由于通过边类型能确定起始类型和终止类型，因此这里需要填点类型
        :param from_type: 起始点类型
        :param create_from: 如果起始点不存在，true是需要创建一个无属性点。false是返回异常
        :param to_pk: 终止点主键值。由于通过边类型能确定起始类型和终止类型，因此这里需要填点类型
        :param to_type: 终止点类型
        :param createTo: 如果终止点不存在，true是需要创建一个无属性点。false是返回异常
        :param type: 边类型
        :param property: 边属性
        :return:
        """
        self = EdgeInfoByVertexPk()
        self.__from_pk = from_pk
        self.__from_type = from_type
        self.__create_from = create_from
        self.__to_pk = to_pk
        self.__to_type = to_type
        self.__create_to = create_to
        self.__type = type
        self.__property = property or {}
        self.__is_merge = is_merge
        return self

    def get_from_type(self) -> str:
        return self.__from_type

    def get_to_type(self) -> str:
        return self.__to_type

    def get_type(self) -> str:
        return self.__type

    def get_property(self) -> dict:
        return self.__property

    def get_from_pk(self) -> str:
        return self.__from_pk

    def get_to_pk(self) -> str:
        return self.__to_pk

    def is_create_from(self) -> bool:
        return self.__create_from

    def is_create_to(self) -> bool:
        return self.__create_to

    def get_is_merge(self) -> bool:
        return self.__is_merge
