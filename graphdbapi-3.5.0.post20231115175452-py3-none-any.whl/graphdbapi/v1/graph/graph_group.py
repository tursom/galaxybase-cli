from typing import Tuple, Any, Set

from bolt.message import Param, GraphMethod, TempText
from graphdbapi.v1.utils.Assert import Assert
from graphdbapi import Driver, BoltStatementResult
from graphdbapi.interface import GraphGroupInterface


class GraphGroup(GraphGroupInterface):
    """
    图组
    """

    def __init__(self, driver: Driver, *graph_names: str):
        self.__driver = driver
        self.__graph_names = set(graph_names)
        self.__graph_indexes = self.__verify_graph()

    @property
    def graph_names(self) -> Set[str]:
        return self.__graph_names

    def execute_procedure(self, procedure_name: str, *input_params: Any) -> BoltStatementResult:
        Assert.not_empty_allowed(procedure_name, "procedureName")

        parameters = {}
        parameters[Param.methodName.get_index_str()] = procedure_name
        parameters[Param.property.get_index_str()] = list(input_params)
        self.__driver.session()
        command = "%s->%s" % (self.__graph_indexes, GraphMethod.executeProcedure_g.get_index())
        return self.__driver.session().run(command, parameters=parameters)

    def stop_procedure(self, procedure_id: int) -> None:
        Assert.positive_allowed(procedure_id, Param.taskId)

        parameters = {}
        parameters[Param.taskId.get_index_str()] = procedure_id
        with self.__driver.session() as session:
            command = "%s->%s" % (self.__graph_indexes, GraphMethod.stopProcedure.get_index())
            session.run(command, parameter=parameters).consume()

    def __verify_graph(self) -> str:
        indexes = []
        for graph_name in self.__graph_names:
            index = self.__get_graph_index(graph_name)
            indexes.append(str(index))
        return ",".join(indexes)

    def __get_graph_index(self, graph_name: str)->int:
        Assert.not_empty_allowed(graph_name, Param.graphName)
        with self.__driver.session() as session:
            result = session.run("%s%s" % (TempText.VOID.value, GraphMethod.getGraph.get_index()), {"graphName": graph_name})
            return result.values()[0][0]
