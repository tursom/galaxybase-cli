# -*- coding    : utf-8 -*-
# @Time         : 2020/12/28 11:02
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :

class Edge:
    def __init__(self, relationship):
        self.relationship = relationship

    # 获取边id
    def get_id(self):
        return self.relationship.id

    # 获取边类型
    def get_type(self):
        return self.relationship.type

    # 获取起始点id
    def get_from_vertex_id(self):
        return self.relationship.start_node.id

    # 获取终止点id
    def get_to_vertex_id(self):
        return self.relationship.end_node.id
