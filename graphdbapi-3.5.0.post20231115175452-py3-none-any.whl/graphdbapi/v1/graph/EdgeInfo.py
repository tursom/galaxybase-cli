# -*- coding    : utf-8 -*-
# @Time         : 2021/3/3 16:14
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from typing import Dict, Any, Optional


class EdgeInfo:
    __edge_id = ""
    __property = None
    __is_merge = True

    @staticmethod
    def init_edge_info(edge_id: str, property: Optional[Dict[str, Any]] = None, is_merge=True):
        self = EdgeInfo()
        self.__edge_id = edge_id
        self.__property = property or {}
        self.__is_merge = is_merge
        return self

    def get_edge_id(self) -> str:
        return self.__edge_id

    def get_property(self) -> Dict[str, Any]:
        return self.__property

    def set_edge_id(self, edge_id: str):
        self.__edge_id = edge_id

    def set_property(self, property: Dict[str, Any]):
        self.__property = property

    def get_is_merge(self) -> bool:
        return self.__is_merge
