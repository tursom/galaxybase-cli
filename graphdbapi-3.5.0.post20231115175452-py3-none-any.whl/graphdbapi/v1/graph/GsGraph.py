# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 14:33
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :


from typing import List, Dict, Any, Union
from copy import deepcopy


from bolt.message.GraphMethod import GraphMethod
from bolt.message.Param import Param
from graphdbapi.v1.utils.Assert import Assert

from graphdbapi import BoltStatementResult, Session
from graphdbapi.compat import deprecated
from graphdbapi.v1.enum import Isolation
from graphdbapi.impl.vertex import VertexImpl
from graphdbapi.impl.cypher import CypherImpl
from graphdbapi.impl.edge import EdgeImpl
from graphdbapi.impl.bfs import BfsImpl
from graphdbapi.impl.propertyValue import PropertyValueImpl
from graphdbapi.impl.graphSchema import GraphSchemaImpl


class GsGraph(VertexImpl, CypherImpl, EdgeImpl, BfsImpl, PropertyValueImpl):
    __HEAD_CYPHER = "RETURN 1"

    def __init__(self, index, name, driver, strategy=None):
        super(GsGraph, self).__init__(index, name, driver, strategy)
        self.__schema = GraphSchemaImpl(index, name, driver, strategy)

    def delete_graph(self) -> None:
        result = self.run(GraphMethod.deleteGraph, {})
        self._check_results(result)

    def begin_transaction(self, isolation: Union[Isolation] = None):
        """
        开始一个新的事务
        :return:
        """
        try:
            session = self.session()
            session.auto_close = False
            parameters = {Param.txId.get_index_str(): -1, Param.isolation.get_index_str(): None}
            if isolation is not None:
                parameters[Param.isolation.get_index_str()] = isolation.name
            command = "%s->%s" % (self.index, GraphMethod.txStart.get_index())
            results = session.run(command, parameters)

            tx = results.records().__next__()[0]
            return GraphTransaction(tx, self, None, session)
        except Exception:
            raise Exception("Failed to start transaction, The last transaction has not been closed!")

    def clear_graph(self) -> None:
        result = self.run(GraphMethod.clearGraph, {})
        self._check_results(result)

    def is_graph_name_used(self, graph_name) -> bool:
        Assert.not_empty_allowed(graph_name, Param.graphName)

        parameters = {}
        parameters[Param.graphName.get_index_str()] = graph_name
        result = self.run(GraphMethod.isGraphNameUsed, parameters)
        return result.records().__next__()[0]

    def execute_procedure(self, procedure_name: str, *input_params: Any) -> BoltStatementResult:
        Assert.not_empty_allowed(procedure_name, "procedureName")

        parameters = {}
        parameters[Param.methodName.get_index_str()] = procedure_name
        parameters[Param.property.get_index_str()] = list(input_params)
        return self.run(GraphMethod.executeProcedure, parameters)

    def schema(self):
        return self.__schema

    def is_enable(self):
        return False if self.driver.closed() else self.driver.is_open()

    def send_message_operator(self, method: GraphMethod, parameters: Dict[str, List[Any]]) -> List[Any]:
        exceptions = []
        result = self.run(method, parameters)

        for record in result:
            if isinstance(record[0], str):
                exceptions.append(record[0])
            else:
                exceptions.append(None)
        return exceptions


class GraphTransaction(GsGraph):
    TX_ID_KEY = "~~txId"
    __closed = False

    def __init__(self, tx_id, graph, _, session: Session):
        super(GraphTransaction, self).__init__(graph.index, graph.name, graph.driver, None)
        self.__session = session
        self.__txId = tx_id
        self.__graph = graph

    def __del__(self):
        try:
            self.close()
        except:
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def session(self) -> Session:
        return self.__session

    @deprecated("use tx.tx_id instead")
    def get_txId(self):
        return self.__txId

    @property
    def tx_id(self):
        return self.__txId

    def success(self):
        self.run(GraphMethod.txSuccess, {}).consume()

    def failure(self):
        self.run(GraphMethod.txFailure, {}).consume()

    def close(self):
        if not self.__closed:
            try:
                self.run(GraphMethod.txClose, {}).consume()
            finally:
                self.__closed = True
                self.session().close()

    def is_open(self):
        return not self.__closed

    def run_with_no_retry(self, method: GraphMethod, parameter: Dict) -> BoltStatementResult:
        if self.is_open() and isinstance(parameter, dict):
            parameter = deepcopy(parameter)
            parameter[self.TX_ID_KEY] = self.__txId

        return super(GraphTransaction, self).run_with_no_retry(method, parameter)
