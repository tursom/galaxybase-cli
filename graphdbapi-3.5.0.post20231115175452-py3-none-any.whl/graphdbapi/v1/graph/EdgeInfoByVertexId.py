# -*- coding    : utf-8 -*-
# @Time         : 2021/3/3 14:31
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from typing import Dict, Any, Union


class EdgeInfoByVertexId:
    # 边的起始点
    __from_id = -1
    # 边的终止点
    __to_id = -1
    # 边的类型
    __type = ""
    # 边的属性集合
    __property = None
    __is_merge = True

    @staticmethod
    def init_edge_info_by_vertex_id(from_id: int, to_id: int, type: str, property: Union[Dict[str, Any], None], is_merge=True):
        self = EdgeInfoByVertexId()
        self.__from_id = from_id
        self.__to_id = to_id
        self.__type = type
        self.__property = property or {}
        self.__is_merge = is_merge
        return self

    def get_from_id(self) -> int:
        return self.__from_id

    def get_to_id(self) -> int:
        return self.__to_id

    def get_type(self) -> str:
        return self.__type

    def get_property(self) -> dict:
        return self.__property

    def get_is_merge(self) -> bool:
        return self.__is_merge
