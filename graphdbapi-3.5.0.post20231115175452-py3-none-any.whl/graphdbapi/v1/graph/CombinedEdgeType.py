# -*- coding    : utf-8 -*-
# @Time         : 2021/3/12 16:19
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :


class CombinedEdgeType:
    """
    边信息
    """
    # 起始点类型
    __from_type = ""
    # 终止点类型
    __to_type = ""

    @staticmethod
    def init_combined_edge_type(from_type: str, to_type: str):
        self = CombinedEdgeType()
        self.__from_type = from_type
        self.__to_type = to_type
        return self

    def get_from_type(self):
        return self.__from_type

    def get_to_type(self):
        return self.__to_type
