# -*- coding    : utf-8 -*-
# @Time         : 2021/3/5 14:08
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from __future__ import annotations


__all__ = [
    "QueryResult",
    "BfsParam",
    "BfsParamBuilder",
]

import typing as t

from bolt.exceptions import ClientException

from .QueryResult import QueryResult
from ..condition import VisitCondition
from ....enum import Direction


class BfsParam:
    """
    start_id: 起始点id，不能小于0

    depth: 深度，范围必须为(0-10)。

    邻居点上限，填小于0 不参与计算。

    limit_edge: 邻居边上限，填小于0 不参与计算。

    dir_list: 方向集合，需要 size = 1 或者 size = depth，不可为 :class:`None` ；

    vertex_condition_list: 点查询条件集合，需要 size = 1 或者 size = depth；填 :class:`None` 不参与计算；

    edge_condition_list: 边查询条件集合，需要size = 1 或者 size = depth；填 :class:`None` 不参与计算；

    edge_type_filter_list: 边类型过滤集合，需要size = 1 或者 size = depth；填null不参与计算 以上三个 List 都是和 depth 对应的，如果 size = 1，那么这个过滤条件会被复制，每一度都是这个过滤条件， 如果你只想给某一度添加过滤条件，那么应该在 list 的其他位置 add(null)。

    hop: 是否 启用hop模式。只返回最外层的点。

    only_count: 是否只返回 count。True表示返回count。

    return_vertex: 是否返回结果点集。只有only_count为False时生效。

    return_edge: 是否返回结果边集。只有only_count为False时生效。
    """

    @classmethod
    def init_by_pk(
            cls, pk:str, Type: str, depth: int, limit_neighbor: int, limit_edge: int,
            dir_list: t.List[Direction],
            vertex_condition_list: t.Optional[t.List[t.Optional[VisitCondition]]],
            edge_condition_list: t.Optional[t.List[t.Optional[VisitCondition]]],
            edge_type_filter_list: t.Optional[t.List[t.Set[str]]],
            hop: bool, only_count: bool,
            return_vertex: bool, return_edge: bool
    ) -> BfsParam:
        self = cls()
        self._start_id = -1
        self._pk = pk
        self._Type = Type
        self._depth = depth
        self._limit_neighbor = limit_neighbor
        self._limit_edge = limit_edge
        self._dir_list = dir_list
        self._vertex_condition_list = vertex_condition_list
        self._edge_condition_list = edge_condition_list
        self._edge_type_filter_list = edge_type_filter_list
        self._hop = hop
        self._only_count = only_count
        self._return_vertex = return_vertex
        self._return_edge = return_edge
        return self

    @classmethod
    def init_by_id(
            cls, start_id: int, depth: int, limit_neighbor: int, limit_edge: int,
            dir_list: t.List[Direction],
            vertex_condition_list: t.Optional[t.List[t.Optional[VisitCondition]]],
            edge_condition_list: t.Optional[t.List[t.Optional[VisitCondition]]],
            edge_type_filter_list: t.Optional[t.List[t.Set[str]]],
            hop: bool, only_count: bool,
            return_vertex: bool, return_edge: bool
    ) -> BfsParam:
        self = cls()
        self._start_id = start_id
        self._pk = ""
        self._Type = ""
        self._depth = depth
        self._limit_neighbor = limit_neighbor
        self._limit_edge = limit_edge
        self._dir_list = dir_list
        self._vertex_condition_list = vertex_condition_list
        self._edge_condition_list = edge_condition_list
        self._edge_type_filter_list = edge_type_filter_list
        self._hop = hop
        self._only_count = only_count
        self._return_vertex = return_vertex
        self._return_edge = return_edge
        return self

    @property
    def start_id(self) -> int:
        return self._start_id

    @property
    def pk(self) -> str:
        return self._pk

    @property
    def Type(self) -> str:
        return self._Type

    @property
    def depth(self) -> int:
        return self._depth

    @property
    def limit_neighbor(self) -> int:
        return self._limit_neighbor

    @property
    def limit_edge(self) -> int:
        return self._limit_edge

    @property
    def dir_list(self) -> t.List[Direction]:
        return self._dir_list

    @property
    def vertex_condition_list(self) -> t.Optional[t.List[t.Optional[VisitCondition]]]:
        return self._vertex_condition_list

    @property
    def edge_condition_list(self) -> t.Optional[t.List[t.Optional[VisitCondition]]]:
        return self._edge_condition_list

    @property
    def edge_type_filter_list(self) -> t.Optional[t.List[t.Set[str]]]:
        return self._edge_type_filter_list

    @property
    def hop(self) -> bool:
        return self._hop

    @property
    def only_count(self) -> bool:
        return self._only_count

    @property
    def return_vertex(self) -> bool:
        return self._return_vertex

    @property
    def return_edge(self) -> bool:
        return self._return_edge

    def __str__(self) -> str:
        if self.start_id != -1:
            start = "start_id={_start_id}".format_map(self.__dict__)
        else:
            start = "pk={_pk}, Type={_Type}".format_map(self.__dict__)

        return "BfsParam{" + \
               start + ", depth={_depth}, " \
               "limit_neighbor={_limit_neighbor}, limit_edge={_limit_edge}, dir_list={_dir_list}, "  \
               "vertex_condition_list={_vertex_condition_list}, edge_condition_list={_edge_condition_list}, " \
               "edge_type_filter_list={_edge_type_filter_list}, " \
               "hop={_hop}, only_count={_only_count}, " \
               "return_vertex={_return_vertex}, return_edge={_return_edge}".format_map(self.__dict__) + \
               '}'


class BfsParamBuilder:
    """
    DEMO:
        BfsParamBuilder.init_by_pk("10086", "user", 2).set_hop(True).set_only_count(True).builder()
    """
    def _create(self, depth):
        self.depth = depth
        self.dir_list: t.Optional[t.List[t.Optional[Direction]]] = [None] * depth
        self.vertex_condition_list: t.Optional[t.List[t.Optional[VisitCondition]]] = [None] * depth
        self.edge_condition_list: t.Optional[t.List[t.Optional[VisitCondition]]] = [None] * depth
        self.edge_type_filter_list: t.Optional[t.List[t.Optional[t.Set[str]]]] = [None] * depth

        self.limit_neighbor: int = -1
        self.limit_edge: int = -1

        self.hop: bool = False
        self.only_count: bool = False
        self.return_vertex: bool = False
        self.return_edge: bool = False

    @classmethod
    def init_by_id(cls, start_id: int, depth: int) -> BfsParamBuilder:
        """通过id初始化构造器

        :param start_id: 点id
        :param depth: 深度
        :return: self
        """
        self = cls()
        self.pk = ""
        self.t = ""
        self.start_id = start_id
        self._create(depth)
        return self

    @classmethod
    def init_by_pk(cls, pk: str, Type: str,depth: int) -> BfsParamBuilder:
        """通过pk初始化构造器

        :param pk: 点pk
        :param Type: 点类型
        :param depth: 深度
        :return: self
        """
        self = cls()
        self.pk = pk
        self.Type = Type
        self.start_id = -1
        self._create(depth)
        return self

    def _update_list(self, _list: t.List, val):
        for _ in range(self.depth):
            _list[_] = val

    def _set_list_value(self, current_depth, _list: t.List, val):
        if current_depth > self.depth or current_depth <= 0:
            raise ClientException("current_depth should bigger than 0 and less than depth[%s]" % current_depth)
        _list[current_depth - 1] = val

    def set_limit_neighbor(self, limit_neighbor: int) -> BfsParamBuilder:
        """

        :param limit_neighbor: 邻居点上限，-1为不限制。默认值：-1
        :return: self
        """
        self.limit_neighbor = limit_neighbor
        return self

    def set_limit_edge(self, limit_edge: int) -> BfsParamBuilder:
        """

        :param limit_edge: 邻居边上限，-1为不限制。默认值：-1
        :return: self
        """
        self.limit_edge = limit_edge
        return self

    def set_hop(self, hop: bool) -> BfsParamBuilder:
        """

        :param hop: 是否启用hop模式。默认值：false
        :return: self
        """
        self.hop = hop
        return self

    def set_only_count(self, only_count: bool) -> BfsParamBuilder:
        """

        :param only_count: true表示只返回count。默认值：false
        :return: self
        """
        self.only_count = only_count
        return self

    def set_return_vertex(self, return_vertex: bool) -> BfsParamBuilder:
        """

        :param return_vertex: 是否返回结果点集。只有onlyCount为false时生效。默认值：false
        :return: self
        """
        self.return_vertex = return_vertex
        return self

    def set_return_edge(self, return_edge: bool) -> BfsParamBuilder:
        """

        :param return_edge: 是否返回结果边集。只有onlyCount为false时生效。默认值：false
        :return:
        """
        self.return_edge = return_edge
        return self

    def set_direction(self, direction: Direction, specified_depth=-1) -> BfsParamBuilder:
        """

        :param direction: 边方向
        :param specified_depth: 为-1时为所有扩展都设置此条件。否则只应用于指定度数
        :return:
        """
        if specified_depth == -1:
            self._update_list(self.dir_list, direction)
        else:
            self._set_list_value(specified_depth, self.dir_list, direction)
        return self

    def set_vertex_condition(self, pv: VisitCondition, specified_depth=-1) -> BfsParamBuilder:
        """

        :param pv: 点过滤条件。默认无条件。
        :param specified_depth: 为-1时为所有扩展都设置此条件。否则只应用于指定度数
        :return: self
        """
        if specified_depth == -1:
            self._update_list(self.vertex_condition_list, pv)
        else:
            self._set_list_value(specified_depth, self.vertex_condition_list, pv)
        return self

    def set_edge_condition(self, pe: VisitCondition, specified_depth=-1) -> BfsParamBuilder:
        """

        :param pv: 边过滤条件。默认无条件。
        :param specified_depth: 为-1时为所有扩展都设置此条件。否则只应用于指定度数
        :return: self
        """
        if specified_depth == -1:
            self._update_list(self.edge_condition_list, pe)
        else:
            self._set_list_value(specified_depth, self.edge_condition_list, pe)
        return self

    def set_edge_type_filter(self, edge_type: t.Set[str], specified_depth=-1) -> BfsParamBuilder:
        """

        :param edge_type: 边类型过滤条件。默认无条件。
        :param specified_depth: 为-1时为所有扩展都设置此条件。否则只应用于指定度数
        :return:
        """
        if specified_depth == -1:
            self._update_list(self.edge_type_filter_list, edge_type)
        else:
            self._set_list_value(specified_depth, self.edge_type_filter_list, edge_type)
        return self

    def builder(self) -> BfsParam:
        """构建BfsParam

        :return:
        """
        if self.start_id != -1:
            return BfsParam.init_by_id(
                self.start_id, self.depth, self.limit_neighbor, self.limit_edge,
                self.dir_list,
                self.vertex_condition_list,
                self.edge_condition_list,
                self.edge_type_filter_list,
                self.hop, self.only_count,
                self.return_vertex, self.return_edge
            )
        return BfsParam.init_by_pk(
            self.pk, self.Type, self.depth, self.limit_neighbor, self.limit_edge,
            self.dir_list,
            self.vertex_condition_list,
            self.edge_condition_list,
            self.edge_type_filter_list,
            self.hop, self.only_count,
            self.return_vertex, self.return_edge
        )