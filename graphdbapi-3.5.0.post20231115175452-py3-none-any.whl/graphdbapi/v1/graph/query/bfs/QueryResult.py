# -*- coding    : utf-8 -*-
# @Time         : 2021/3/5 14:08
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from typing import Dict, List

from graphdbapi.v1.graph.query.ResponseElementInfo import ResponseElementInfo


class QueryResult:
    """
    bfs（广度优先搜索）结果集
    """
    # 点的总个数
    __vertex_count = -1
    # 边的总个数
    __edge_count = -1
    # Dict[点id, 对应的点信息]
    __vertex_set = dict() # Dict[int, ResponseElementInfo]
    # 对应的边信息集合
    __edge_set = dict() # Dict[str, ResponseElementInfo]
    # 超级节点的id集合
    __super_node_set = list() # List[int]

    @staticmethod
    def init_query_result_by_count(vertex_count: int, edge_count: int):
        self = QueryResult()
        self.__vertex_count = vertex_count
        self.__edge_count = edge_count
        return self

    @staticmethod
    def init_query_result_by_detail(
            vertex_set: Dict[int, ResponseElementInfo], edge_set: [str, ResponseElementInfo],
            super_node_set: List[int]
    ):
        self = QueryResult()
        self.__vertex_set = vertex_set
        self.__edge_set = edge_set
        self.__vertex_count = vertex_set.__len__() if vertex_set else 0
        self.__edge_count = edge_set.__len__() if edge_set else 0
        self.__super_node_set = super_node_set
        return self

    def get_vertex_set(self):
        return self.__vertex_set

    def get_edge_set(self) -> Dict[str, ResponseElementInfo]:
        return self.__edge_set

    def get_super_node_set(self):
        return self.__super_node_set

    def get_vertex_count(self):
        return self.__vertex_count

    def get_edge_count(self):
        return self.__edge_count

    def set_vertex_count(self, vertex_count):
        self.__vertex_count = vertex_count

    def set_edge_count(self, edge_count):
        self.__edge_count = edge_count

