# -*- coding    : utf-8 -*-
# @Time         : 2021/3/5 16:51
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from typing import Dict


class EdgeDegreeInfo:
    """
    边的度数信息汇总
    """
    # 边的总度数值
    __degree = 0
    # Dict映射。key是边类型，value是对应类型的总degree数量
    #
    __degree_info = dict()

    @staticmethod
    def init_edge_degree_info(degree: int, degreeInfo: Dict[str, int]):
        self = EdgeDegreeInfo()
        self.__degree = degree
        self.__degree_info = degreeInfo
        return self

    def get_degree_info(self) -> Dict[str, int]:
        return self.__degree_info

    def get_degree(self) -> int:
        return self.__degree

    def __str__(self) -> str:
        return "EdgeDegreeInfo [degree=%s, degree_info=%s]" % (self.__degree, self.__degree_info)