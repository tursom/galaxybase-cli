# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 14:54
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from graphdbapi.v1.enum.PropertyType import PropertyType
from graphdbapi.v1.enum.QueryMethod import QueryMethod
from graphdbapi.v1.graph.query.condition.VisitCondition import Serializable


class PropertyFilterInfo:
    """
    具体的属性过滤，是{PropertyFilter}的依赖类
    """
    Serializable = Serializable
    __property_name = ""
    __method = None
    __value = None
    __value2 = None
    __property_type = ""

    @staticmethod
    def init_property_filter_info(property_name: str, method: QueryMethod, value, value2=None):
        """
        给是范围比较的符号{ QueryMethod}使用

        :param property_name: 属性名
        :param method:
        :param value: 比较范围的最小值
        :param value2: 比较范围的最大值
        :return:
        """
        self = PropertyFilterInfo()
        self.__property_name = property_name
        self.__method = method
        self.__value = value
        self.__value2 = value2
        return self

    def get_method(self) -> QueryMethod:
        """
        获取比较方法

        :return:
        """
        return self.__method

    def get_value(self):
        """
        获取条件比较值；对于区间比较，返回的时valueMin

        :return: 第一个比较值
        """
        return self.__value

    def get_value2(self):
        """
        获取另一个条件比较值；对于区间比较，返回valueMax

        :return: 第二个比较值
        """
        return self.__value2

    def get_property_type(self):
        """
        获取比较值的类型

        :return: 比较值的类型
        """
        return self.__property_type

    def get_property_name(self):
        """
        获取propertyName

        :return: 获取propertyName
        """
        return self.__property_name

