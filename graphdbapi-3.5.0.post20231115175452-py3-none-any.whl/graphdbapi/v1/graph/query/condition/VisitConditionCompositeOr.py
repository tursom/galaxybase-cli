# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 16:30
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from graphdbapi.v1.graph.query.condition.VisitCondition import VisitCondition


class VisitConditionCompositeOr(VisitCondition):
    """
    多条件组合类，可以组合{ VisitConditionByProperty} 和  { VisitConditionByType} \n
    多个条件之间通过OR组合
    """
    serial_version_UID = 1
    __children_or = None

    @staticmethod
    def init_visit_condition_composite_or(*values: VisitCondition):
        self = VisitConditionCompositeOr()
        self.__children_or = values
        return self

    def get_children(self):
        return self.__children_or