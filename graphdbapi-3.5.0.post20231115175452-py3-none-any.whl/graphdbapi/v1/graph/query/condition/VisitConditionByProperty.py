# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 16:06
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from typing import Dict

from graphdbapi.v1.graph.query.condition.PropertyFilter import PropertyFilter
from graphdbapi.v1.graph.query.condition.VisitCondition import VisitCondition


class VisitConditionByProperty(VisitCondition):
    """
    对属性添加条件过滤
    """
    serial_version_UID = 1
    __condition_filter_map = None
    __is_vertex = False

    @staticmethod
    def init_visit_condition_by_property(condition_filter_map: Dict[str, PropertyFilter], is_vertex: bool):
        self = VisitConditionByProperty()
        self.__condition_filter_map = condition_filter_map
        self.__is_vertex = is_vertex
        return self

    def get_conditionFilterMap(self) -> Dict[str, PropertyFilter]:
        return self.__condition_filter_map

    def is_vertex(self) -> bool:
        return self.__is_vertex
