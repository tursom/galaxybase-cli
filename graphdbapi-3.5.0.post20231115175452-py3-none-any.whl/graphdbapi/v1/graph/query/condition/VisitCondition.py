# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 16:33
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from graphdbapi.v1.utils.core import Serializable


class VisitCondition:
    Serializable = Serializable
