# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 16:21
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :

from typing import Set
from graphdbapi.v1.enum.TypeConditionMethod import TypeConditionMethod
from graphdbapi.v1.graph.query.condition.VisitCondition import VisitCondition


class VisitConditionByType(VisitCondition):
    """
    对类型添加过滤
    """
    serial_version_UID = 1
    __type_condition_method = None
    # 类型集合
    __type_name_set = list()
    # 对点类型还是边类型过滤，true是对点类型，false是对边类型
    __is_vertex = False

    @staticmethod
    def init_visit_condition_by_type(type_set: Set[str], type_condition_method: TypeConditionMethod, is_vertex: bool):
        """

        :param type_set: 类型集合
        :param type_condition_method: {TypeConditionMethod} 对typeSet中的类型添加条件
        :param is_vertex: 该条件中的类型是点类型还是边类型，true是点类型，false是边类型
        :return:
        """
        self = VisitConditionByType()
        self.__type_name_set = type_set
        self.__type_condition_method = type_condition_method
        self.__is_vertex = is_vertex
        return self

    def get_type_condition_method(self):
        return self.__type_condition_method

    def get_type_name_set(self):
        return self.__type_name_set

    def is_vertex(self):
        return self.__is_vertex