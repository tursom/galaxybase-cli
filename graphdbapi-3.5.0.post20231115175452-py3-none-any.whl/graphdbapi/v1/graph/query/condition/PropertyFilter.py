# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 14:52
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from graphdbapi.v1.graph.query.condition.PropertyFilterInfo import PropertyFilterInfo
from graphdbapi.v1.enum.QueryMethod import QueryMethod
from graphdbapi.v1.graph.query.condition.VisitCondition import Serializable


class PropertyFilter:
    """
    属性过滤集合，是{ VisitConditionByProperty}的依赖类
    """
    Serializable = Serializable
    __condition = list()

    @staticmethod
    def init_Property_filter():
        self = PropertyFilter()
        self.__condition = list()
        return self

    def add_filter_by_property_filter_info(self, property_filter_info: PropertyFilterInfo):
        self.__condition.append(property_filter_info)

    def add_filter_by_params(self, property_name: str, method: QueryMethod, value, value2=None):
        self.__condition.append(PropertyFilterInfo.init_property_filter_info(property_name, method, value, value2))

    def get_condition(self):
        return self.__condition

