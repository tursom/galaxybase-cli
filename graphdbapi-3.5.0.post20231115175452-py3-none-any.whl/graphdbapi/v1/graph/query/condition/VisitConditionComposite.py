# -*- coding    : utf-8 -*-
# @Time         : 2021/3/4 16:26
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from graphdbapi.v1.graph.query.condition.VisitCondition import VisitCondition


class VisitConditionComposite(VisitCondition):
    """
    多条件组合类，可以组合{ VisitConditionByProperty} 和  {VisitConditionByType}\n
    多个条件之间通过AND组合
    """
    serial_version_UID = 1
    __children = None

    @staticmethod
    def init_visit_condition_composite(*values: VisitCondition):
        """
        VisitCondition
        :param values:
        :return:
        """
        self = VisitConditionComposite()
        self.__children = values
        return self

    def get_children(self):
        return self.__children