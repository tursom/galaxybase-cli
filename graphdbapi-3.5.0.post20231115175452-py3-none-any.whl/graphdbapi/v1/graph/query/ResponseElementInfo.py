# -*- coding    : utf-8 -*-
# @Time         : 2021/3/5 14:15
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from typing import Dict, Any


class ResponseElementInfo:
    """
    bfs（广度优先搜索）结果集中，点和边的基础信息
    """
    # 元素id
    __element_id = -1
    # 点id对应的主键
    __pk = ""
    # id对应的类型名
    __type = ""
    # 边id对应的起始点
    __from_id = ""
    # 边id对应的终止点
    __to_id = ""
    # 边是否有向，true为有向边，false为无向边
    __direct = False
    # 边属性集合
    __edge_property_map = dict()

    def get_element_id(self) -> str:
        return self.__element_id

    def get_pk(self) -> str:
        return self.__pk

    def get_type(self) -> str:
        return self.__type

    def get_from_id(self) -> int:
        return self.__from_id

    def get_to_id(self) -> int:
        return self.__to_id

    def get_direct(self) -> bool:
        return self.__direct

    def get_edge_property_map(self) -> Dict[str, Any]:
        return self.__edge_property_map

    def set_element_id(self, element_id: str) -> None:
        self.__element_id = element_id

    def set_pk(self, pk: str) -> None:
        self.__pk = pk

    def set_type(self, type: str) -> None:
        self.__type = type

    def set_from_id(self, from_id: int) -> None:
        self.__from_id = from_id

    def set_to_id(self, to_id: int) -> None:
        self.__to_id = to_id

    def set_direct(self, direct: bool) -> None:
        self.__direct = direct

    def set_edge_property_map(self, edge_property_map: Dict[str, Any]) -> None:
        self.__edge_property_map = edge_property_map