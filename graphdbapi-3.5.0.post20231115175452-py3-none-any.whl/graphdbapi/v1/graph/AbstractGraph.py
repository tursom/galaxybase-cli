# -*- coding    : utf-8 -*-
# @Time         : 2021/3/9 9:57
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
import abc
from itertools import chain
from typing import Dict
from contextlib import ExitStack
from bolt.routing import AutoPartitionLoadBalancingStrategy

from graphdbapi.compat import deprecated
from graphdbapi import BoltStatementResult
from graphdbapi import Driver
from graphdbapi import Session
from bolt.message.GraphMethod import GraphMethod


class AbstractGraph(metaclass=abc.ABCMeta):
    __index = -1
    __name = ""
    __driver = None
    __tx = None
    __strategy = None

    def __init__(self, index, name, driver: Driver, strategy=None):
        self.__index = index
        self.__name = name
        self.__driver = driver
        self.__strategy = self.init_strategy(strategy)

    def init_strategy(self, strategy):
        if isinstance(strategy, AutoPartitionLoadBalancingStrategy):
            strategy.set_graph_index(self.index)
        return strategy

    @property
    def driver(self):
        return self.__driver

    @property
    def name(self):
        return self.__name

    @property
    def index(self):
        return self.__index

    def schema(self):
        raise NotImplementedError

    def get_ip(self):
        return self.__driver.get_ip()

    def session(self) -> Session:
        return self.__driver.session()

    def run(self, method: GraphMethod, parameter: Dict) -> BoltStatementResult:
        return self.run_with_no_retry(method, parameter)

    @deprecated("This function will be removed soon")
    def close(self):
        self.__driver.close()

    @staticmethod
    def _check_results(results):
        try:
            results.records().__next__()
        except StopIteration:
            pass

    def _release(self, results):
        for _ in results:
            pass

    def _only_first_record(self, results):
        with ExitStack() as stack:
            stack.callback(self._release, results)
            for record in results:
                if record[0] is None: continue
                return record

    def _results_iter(self, results):
        try:
            record = results.records().__next__()
            results = map(lambda _: _, chain([record], results))
        except StopIteration:
            return iter([])
        return results

    def run_with_no_retry(self, method: GraphMethod, parameter: Dict) -> BoltStatementResult:
        session = self.session()
        command = "%s->%s" % (self.__index, method.get_index())
        return session.run(command, parameters=parameter, strategy=self.__strategy)
