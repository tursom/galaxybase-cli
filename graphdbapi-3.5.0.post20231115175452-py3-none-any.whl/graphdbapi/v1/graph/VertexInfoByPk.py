# -*- coding    : utf-8 -*-
# @Time         : 2021/3/9 17:18
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from typing import Union, Dict, Any


class VertexInfoByPk:
    """
    批量添加点的参数信息封装
    """
    __pk = ""
    __type = ""
    __property = {}
    __is_merge = True

    @staticmethod
    def init_vertex_info_by_pk(pk: str, type: str, is_merge=True):
        self = VertexInfoByPk()
        self.__pk = pk
        self.__type = type
        self.__property = {}
        self.__is_merge = is_merge
        return self

    @staticmethod
    def init_vertex_info_by_pk_and_property(pk: str, type: str, property: Union[None, Dict[str, Any]], is_merge=True):
        self = VertexInfoByPk()
        self.__pk = pk
        self.__type = type
        self.__property = property if property else {}
        self.__is_merge = is_merge
        return self

    def get_pk(self) -> str:
        """
        返回点pk

        :return: 点pk
        """
        return self.__pk

    def get_type(self) -> str:
        """
        返回点类型

        :return: 点类型
        """
        return self.__type

    def get_property(self) -> Union[None, Dict[str, Any]]:
        """
        返回点属性

        :return:
        """
        return self.__property

    def get_is_merge(self) -> bool:
        return self.__is_merge