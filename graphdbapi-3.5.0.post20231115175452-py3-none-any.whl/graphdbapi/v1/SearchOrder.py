from graphdbapi.v1.enum import OrderBy
from graphdbapi.v1.utils.core import Serializable


class SearchOrder:
    Serializable = Serializable

    """
    查询结果的排序
    """
    def __init__(self, prop: str, order_by: OrderBy):
        """

        :param prop: 需要排序的属性
        :param order_by: 升序、降序类型
        """
        self.__property = prop
        self.__order = order_by

    @property
    def prop(self):
        return self.__property

    @property
    def order_by(self):
        return self.__order
