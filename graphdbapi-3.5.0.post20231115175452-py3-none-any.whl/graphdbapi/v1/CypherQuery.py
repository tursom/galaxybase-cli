# -*- coding    : utf-8 -*-
# @Time         : 2021/2/26 19:23
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :

class CypherQuery:
    def __init__(self, task_id: int, cypher: str, graph_name: str, user_name: str, start_time: int):
        self.__task_id = task_id
        self.__cypher = cypher
        self.__graph_name = graph_name
        self.__user_name = user_name
        self.__start_time = start_time

    def get_task_id(self) -> int:
        return self.__task_id

    def get_cypher(self) -> str:
        return self.__cypher

    def get_graph_name(self) -> str:
        return self.__graph_name

    def get_user_name(self) -> str:
        return self.__user_name

    def get_start_time(self) -> int:
        return self.__start_time