from typing import Any, Union

from graphdbapi.v1.enum import SearchType
from graphdbapi.v1.utils.core import Serializable


class SearchPredicate:
    """
    查询判断，包含属性名、比较类型、比较类型所需值
    """
    __type = None
    __property = ""
    __value1 = None
    __value2 = None
    __inclusive_equal1 = False
    __inclusive_equal2 = False

    Serializable = Serializable

    @property
    def prop(self):
        return self.__property

    @property
    def search_type(self):
        return self.__type

    @property
    def value1(self):
        return self.__value1

    @property
    def value2(self):
        return self.__value2

    @property
    def inclusive_equal1(self):
        return self.__inclusive_equal1

    @property
    def inclusive_equal2(self):
        return self.__inclusive_equal2

    @classmethod
    def _init_by_val(cls, search_type: SearchType, prop: str, value1: Any, eq1: bool = False):
        self = cls()
        self.__type = search_type
        self.__property = prop
        self.__value1 = value1
        self.__inclusive_equal1 = eq1
        return self

    @classmethod
    def _init_by_vals(cls, search_type: SearchType, prop: str, val1: Any, val2: Any, eq1: bool, eq2: bool):
        self = cls()
        self.__type = search_type
        self.__property = prop
        self.__value1 = val1
        self.__value2 = val2
        self.__inclusive_equal1 = eq1
        self.__inclusive_equal2 = eq2
        return self

    @classmethod
    def init_contains_predicate(cls, prop: str, val: str):
        """
        谓词 包含

        :param prop: 属性名
        :param val: 包含的值
        :return: self
        """
        return cls._init_by_val(SearchType.CONTAINS, prop, val)

    @classmethod
    def init_prefix_predicate(cls, prop: str, val: str):
        """
        谓词 前缀

        :param prop: 属性名
        :param val: 前缀的值
        :return: self
        """
        return cls._init_by_val(SearchType.PREFIX, prop, val)

    @classmethod
    def init_suffix_predicate(cls, prop: str, val: str):
        """
        谓词 后缀

        :param prop: 属性名
        :param val: 后缀的值
        :return: self
        """
        return cls._init_by_val(SearchType.SUFFIX, prop, val)

    @classmethod
    def init_less_than_predicate(cls, prop: str, val: Union[int, float], eq1: bool):
        """
        谓词 小于或小于等于

        :param prop: 属性名
        :param val: 比较的值
        :param eq1: 是否包含等于
        :return: self
        """
        return cls._init_by_val(SearchType.LESS_THAN, prop, val, eq1)

    @classmethod
    def init_greater_than_predicate(cls, prop: str, val: Union[int, float], eq1: bool):
        """
        谓词 大于或大于等于

        :param prop: 属性名
        :param val: 比较的值
        :param eq1: 是否包含等于
        :return: self
        """
        return cls._init_by_val(SearchType.GREATER_THAN, prop, val, eq1)

    @classmethod
    def init_range_number_predicate(cls, prop: str, val1: Union[int, float], val2: Union[int, float], eq1: bool,
                                    eq2: bool):
        """
        谓词 范围

        :param prop: 属性名
        :param val1: 与目的比较的值(范围最小值)
        :param val2: 与目的比较的值(范围最大值)
        :param eq1: 是否包含等于范围最小值
        :param eq2: 是否包含范围最大值
        :return: self
        """
        return cls._init_by_vals(SearchType.RANGE_NUMBER, prop, val1, val2, eq1, eq2)

    @classmethod
    def init_equal_predicate(cls, prop: str, val: Any):
        """
        谓词 等于

        :param prop: 属性名
        :param val: 与目的比较的值
        :return: self
        """
        return cls._init_by_val(SearchType.EQUAL, prop, val)