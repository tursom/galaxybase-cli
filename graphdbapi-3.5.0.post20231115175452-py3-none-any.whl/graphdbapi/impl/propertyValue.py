# -*- coding    : utf-8 -*-
# @Time         : 2021/3/12 15:16
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from typing import Union, Any

from bolt.message import Param, GraphMethod
from graphdbapi.interface.propertyValue import PropertyValueInterface
from graphdbapi.v1.utils.Assert import Assert
from graphdbapi.v1.utils.ValueUtil import ValueUtil


class PropertyValueImpl(PropertyValueInterface):
    def put_property_value(self, is_vertex: bool, id: Union[str, int], property_name: str, value: Any, is_merge:bool) -> None:
        Assert.id_allowed(id, is_vertex, Param.id)
        Assert.not_empty_allowed(property_name, Param.propertyName)

        parameter = dict()
        parameter[Param.isVertex.get_index_str()] = is_vertex
        parameter[Param.id.get_index_str()] = id
        parameter[Param.propertyName.get_index_str()] = property_name
        parameter[Param.value.get_index_str()] = ValueUtil.get_property(Param.value, value, False)
        parameter[Param.isMerge.get_index_str()] = is_merge

        results = self.run(GraphMethod.putPropertyValue, parameter=parameter)

        self._check_results(results)

    def remove_property_value(self, is_vertex: bool, id: Union[str, int], property_name: str) -> None:
        Assert.id_allowed(id, is_vertex, Param.id)
        Assert.not_empty_allowed(property_name, Param.propertyName)

        parameter = dict()
        parameter[Param.isVertex.get_index_str()] = is_vertex
        parameter[Param.id.get_index_str()] = id
        parameter[Param.propertyName.get_index_str()] = property_name
        results = self.run(GraphMethod.removePropertyValue, parameter=parameter)

        self._check_results(results)