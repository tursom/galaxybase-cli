# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 19:05
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

import json

from typing import List, Set, Union, Dict, Any, Iterator

from graphdbapi.v1.utils.Assert import Assert
from bolt.message import Param, GraphMethod
from graphdbapi import Node, Relationship
from graphdbapi.interface.bfs import BfsInterface
from graphdbapi.v1.utils.core import NpEncoder
from graphdbapi.v1.enum import Direction
from graphdbapi.v1.graph.query.condition import VisitCondition
from graphdbapi.types import Edge
from graphdbapi.v1.graph.query import ResponseElementInfo
from graphdbapi.v1.graph.query.bfs import (
    QueryResult,
    BfsParam,
)


class BfsImpl(BfsInterface):
    def shortest_path(self, start_id: int, end_id: int, path_edge_type: Union[Set[str], None], limit: int = 1) -> Iterator[Edge]:
        Assert.positive_allowed(start_id, Param.startId)
        Assert.positive_allowed(end_id, Param.endId)
        Assert.deep_allowed(limit, Param.limitDepth)
        parameters = {}
        parameters[Param.startId.get_index_str()] = start_id
        parameters[Param.endId.get_index_str()] = end_id
        parameters[Param.limitDepth.get_index_str()] = limit
        if path_edge_type is None:
            path_edge_type = []
        else:
            path_edge_type = list(path_edge_type)
        parameters[Param.pathEdgeType.get_index_str()] = path_edge_type

        result = self.run(GraphMethod.shortestPath, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def bfs_by_param(self, bfs_param: BfsParam) -> QueryResult:
        if bfs_param.start_id != -1:
            return self.bfs_master(
                bfs_param.start_id, bfs_param.depth,
                bfs_param.limit_neighbor, bfs_param.limit_edge,
                bfs_param.dir_list,
                bfs_param.vertex_condition_list, bfs_param.edge_condition_list, bfs_param.edge_type_filter_list,
                bfs_param.hop, bfs_param.only_count, bfs_param.return_vertex, bfs_param.return_edge
            )
        return self.bfs_master_by_pk(
            bfs_param.pk, bfs_param.Type, bfs_param.depth,
            bfs_param.limit_neighbor, bfs_param.limit_edge,
            bfs_param.dir_list,
            bfs_param.vertex_condition_list, bfs_param.edge_condition_list, bfs_param.edge_type_filter_list,
            bfs_param.hop, bfs_param.only_count, bfs_param.return_vertex, bfs_param.return_edge
        )

    def bfs_master(
            self, start_id: int, depth: int, limit_neighbor: int, limit_edge: int, dir_list: List[Direction],
            vertex_condition_list: Union[List[VisitCondition], None],
            edge_condition_list: Union[List[VisitCondition], None],
            edge_type_filter_list: Union[List[Set[str]], None], hop: bool, only_count: bool,
            return_vertex: bool, return_edge: bool
    ) -> QueryResult:
        Assert.positive_allowed(start_id, Param.startId)

        parameters = {}
        parameters[Param.startId.get_index_str()] = start_id
        parameters = self.__bfs(
            parameters, depth, limit_neighbor, limit_edge, dir_list,
            vertex_condition_list, edge_condition_list, edge_type_filter_list,
            hop, only_count, return_vertex, return_edge
        )

        result = self.run(GraphMethod.bfsMaster, parameters)
        return self.__bfs_master_result_hander(only_count, result)

    def bfs_master_by_pk(
            self, pk: str, type: str, depth: int, limit_neighbor: int, limit_edge: int, dir_list: List[Direction],
            vertex_condition_list: Union[List[VisitCondition], None],
            edge_condition_list: Union[List[VisitCondition], None],
            edge_type_filter_list: Union[List[Set[str]], None], hop: bool, only_count: bool,
            return_vertex: bool, return_edge: bool
    ) -> QueryResult:
        Assert.not_empty_allowed(pk, Param.pk)
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.pk.get_index_str()] = pk
        parameters[Param.type.get_index_str()] = type
        parameters = self.__bfs(
            parameters, depth, limit_neighbor, limit_edge, dir_list,
            vertex_condition_list, edge_condition_list, edge_type_filter_list,
            hop, only_count, return_vertex, return_edge
        )

        results = self.run(GraphMethod.bfsMaster, parameters)
        return self.__bfs_master_result_hander(only_count, results)

    @staticmethod
    def __bfs(
            parameters: Dict[str, Any], depth: int, limit_neighbor: int, limit_edge: int, dir_list: List[Direction],
            vertex_condition_list: Union[List[VisitCondition], None],
            edge_condition_list: Union[List[VisitCondition], None],
            edge_type_filter_list: Union[List[Set[str]], None], hop: bool, only_count: bool,
            return_vertex: bool, return_edge: bool
    ) -> Dict[Any, Any]:
        Assert.deep_allowed(depth, Param.depth)
        Assert.depth_list_allowed(dir_list, depth, Param.dirList)
        Assert.depth_list_allowed(vertex_condition_list, depth, Param.vertexConditionList, allow_null=True,
                                  allow_empty=True)
        Assert.depth_list_allowed(edge_condition_list, depth, Param.edgeConditionList, allow_null=True,
                                  allow_empty=True)
        Assert.depth_list_allowed(edge_condition_list, depth, Param.edgeTypeFilterList, allow_null=True,
                                  allow_empty=True)

        parameters[Param.depth.get_index_str()] = depth
        parameters[Param.dirList.get_index_str()] = json.dumps(dir_list, cls=NpEncoder, ensure_ascii=False)
        parameters[Param.limitNeighbor.get_index_str()] = limit_neighbor
        parameters[Param.limitEdge.get_index_str()] = limit_edge
        parameters[Param.hop.get_index_str()] = hop
        parameters[Param.onlyCount.get_index_str()] = only_count
        parameters[Param.returnVertex.get_index_str()] = return_vertex
        parameters[Param.returnEdge.get_index_str()] = return_edge

        parameters[Param.edgeConditionList.get_index_str()] = json.dumps(edge_condition_list, cls=NpEncoder,
                                                                         ensure_ascii=False)
        parameters[Param.vertexConditionList.get_index_str()] = json.dumps(vertex_condition_list, cls=NpEncoder,
                                                                           ensure_ascii=False)
        parameters[Param.edgeTypeFilterList.get_index_str()] = json.dumps(edge_type_filter_list, cls=NpEncoder,
                                                                          ensure_ascii=False)

        return parameters

    @staticmethod
    def __bfs_master_result_hander(only_count, results) -> QueryResult:
        _result = {}
        record = results.records().__next__()[0]
        if isinstance(record,  int):
            _result["superNodeSet"] = []
            _result["vertexSet"] = {}
            _result["edgeSet"] = {}
            _result["vertexCount"] = record
            _result["edgeCount"] = results.records().__next__()[0]
            for i in (_[0] for _ in results):
                if isinstance(i, Node):
                    _result["vertexSet"][i.id] = {"elementId":i.id, "pk":i.get("pk"), "type":i.label}
                elif isinstance(i, Relationship):
                    _result["edgeSet"][i.id] = {
                        "elementId": i.id, "type": i.type, "fromId": i.start,
                        "toId":i.end, "edgePropertyMap": dict(i.items())
                    }
                else:
                    _result["superNodeSet"].append(i)

        else:
            _result["vertexCount"] = record["vertexCount"]
            _result["edgeCount"] = record["edgeCount"]

            if not only_count:
                _result["vertexSet"] = json.loads(record["vertexSet"])
                _result["edgeSet"] = json.loads(record["edgeSet"])
                _result["superNodeSet"] = json.loads(record["superNodeSet"])

        vertex_set = dict()
        edge_set = dict()

        for key in _result["vertexSet"]:
            vertex = _result["vertexSet"][key]
            info = ResponseElementInfo()
            info.set_element_id(vertex["elementId"])
            info.set_type(vertex["type"])
            info.set_pk(vertex["pk"])
            vertex_set[int(info.get_element_id())] = info

        for key in _result["edgeSet"]:
            edge = _result["edgeSet"][key]
            info = ResponseElementInfo()
            info.set_element_id(edge["elementId"])
            info.set_from_id(edge["fromId"])
            info.set_to_id(edge["toId"])
            info.set_type(edge["type"])
            info.set_edge_property_map(edge["edgePropertyMap"])
            edge_set[info.get_element_id()] = info

        query_result = QueryResult.init_query_result_by_detail(vertex_set, edge_set, _result["superNodeSet"])
        query_result.set_vertex_count(_result["vertexCount"])
        query_result.set_edge_count(_result["edgeCount"])
        for _ in results: pass
        return query_result