# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 16:21
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from __future__ import annotations

import json

from typing import Dict, Any, Optional, NoReturn
from copy import deepcopy

from graphdbapi import BoltStatementResult
from graphdbapi.v1.utils.Assert import Assert
from bolt.message import Param, GraphMethod

from graphdbapi.v1 import CypherQuery
from graphdbapi.interface.cypher import CypherInterface


class CypherImpl(CypherInterface):
    def execute_query(self, cypher: str, timeout: Optional[int] = None, def_limit: Optional[int] = None) -> BoltStatementResult:
        Assert.not_empty_allowed(cypher, Param.cypher)

        parameters = dict()
        parameters[Param.cypher.get_index_str()] = cypher
        if timeout is not None:
            Assert.positive_allowed(timeout, Param.timeout)
            parameters[Param.timeout.get_index_str()] = timeout
        if def_limit is not None:
            parameters[Param.defLimit.get_index_str()] = def_limit

        return self.run(GraphMethod.cypher, parameter=parameters)

    def execute_cypher(self, cypher: str, parameters: Optional[Dict[str, Any]] = None) -> BoltStatementResult:
        Assert.not_empty_allowed(cypher, Param.cypher)
        parameters = deepcopy(parameters or dict())

        parameters[Param.cypher.get_index_str()] = cypher
        return self.run(GraphMethod.cypher, parameter=parameters)

    def get_cypher_metrics(self) -> Dict[int, CypherQuery]:
        records = {}
        parameters = dict()
        results = self.run(GraphMethod.getCypherMetrics, parameter=parameters)
        for item in results:
            values = json.loads(item.value())
            for key in values:
                taskId = values[key].get("taskId")
                records[taskId] = CypherQuery(
                    taskId, values[key].get("cypher"),
                    values[key].get("graphName"), values[key].get("userName"),
                    values[key].get("startTime"),
                )
        return records

    def stop_cypher(self, task_id: int) -> NoReturn:
        Assert.positive_allowed(task_id, Param.taskId)

        parameter = dict()
        parameter[Param.taskId.get_index_str()] = task_id

        self._check_results(self.run(GraphMethod.stopCypher, parameter))
