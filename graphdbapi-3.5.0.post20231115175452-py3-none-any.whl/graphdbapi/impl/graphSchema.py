# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 19:25
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
import json
from typing import Union, Dict, List, Set, Optional

from bolt.message import Param, GraphMethod
from graphdbapi.v1.utils.Assert import Assert
from graphdbapi.v1.utils.ValueUtil import ValueUtil
from graphdbapi.v1.graph import CombinedEdgeType

from graphdbapi.interface.graphSchema import GraphSchemaInterface
from graphdbapi.v1.enum import PropertyType
from bolt.exceptions import TypeNotFoundException


class GraphSchemaImpl(GraphSchemaInterface):
    def __init__(self, index, name, driver, strategy):
        super(GraphSchemaImpl, self).__init__(index, name, driver, strategy)

    def create_vertex_type(self, type: str, pk_name: str, class_map: Union[Dict[str, PropertyType], None]) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(pk_name, Param.pkName)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.pkName.get_index_str()] = pk_name
        parameters[Param.classMap.get_index_str()] = ValueUtil.class_map_to_string(class_map, Param.classMap)

        result = self.run(GraphMethod.createVertexType, parameters)

        self._check_results(result)

    def drop_vertex_type(self, type: str) -> None:
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        result = self.run(GraphMethod.dropVertexType, parameters)

        self._check_results(result)

    def create_edge_type(
            self, type: str, combine_edge_types: Union[List[CombinedEdgeType], CombinedEdgeType],
            direct: bool, allow_repeat: bool, combine_key: Union[str, None], class_map: Union[Dict[str, PropertyType], None]
    ) -> None:
        Assert.not_empty_allowed(type, Param.type)
        if not isinstance(combine_edge_types, list):
            combine_edge_types = [combine_edge_types]
        ValueUtil.combine_repeat_allowed(allow_repeat, combine_key, class_map)

        com_edge_types = []
        for info in combine_edge_types:
            Assert.not_empty_allowed(info.get_from_type(), Param.fromType)
            Assert.not_empty_allowed(info.get_to_type(), Param.toType)
            com_edge_types.append({
                Param.fromType.get_index_str(): info.get_from_type(),
                Param.toType.get_index_str(): info.get_to_type()
            })

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.combinedEdgeTypes.get_index_str()] = com_edge_types
        parameters[Param.direct.get_index_str()] = direct
        parameters[Param.allowRepeat.get_index_str()] = allow_repeat
        parameters[Param.combineKey.get_index_str()] = combine_key
        parameters[Param.classMap.get_index_str()] = ValueUtil.class_map_to_string(class_map, Param.classMap)

        result = self.run(GraphMethod.createEdgeType, parameters)

        self._check_results(result)

    def get_vertex_types(self) -> Set[str]:
        result = self.run(GraphMethod.getVertexTypes, {})

        return set(map(lambda record: record[0], result.records()))

    def drop_edge_type(self, type: str) -> None:
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        result = self.run(GraphMethod.dropEdgeType, parameters)

        self._check_results(result)

    def drop_combined_edge_type(self, type: str, from_type: str, to_type: str) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(from_type, Param.fromType)
        Assert.not_empty_allowed(to_type, Param.toType)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.fromType.get_index_str()] = from_type
        parameters[Param.toType.get_index_str()] = to_type

        result = self.run(GraphMethod.dropCombinedEdgeType, parameters)

        self._check_results(result)

    def get_edge_types(self) -> Set[str]:
        result = self.run(GraphMethod.getEdgeTypes, {})

        return set(map(lambda record: record[0], result.records()))

    def create_property(self, type: str, is_vertex: bool, property_name: str, is_index: bool, property_type: PropertyType) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(property_name, Param.propertyName)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.isVertex.get_index_str()] = is_vertex
        parameters[Param.propertyName.get_index_str()] = property_name
        parameters[Param.isIndex.get_index_str()] = is_index
        parameters[Param.propertyType.get_index_str()] = ValueUtil.property_type_to_map_value(property_type)

        result = self.run(GraphMethod.createProperty, parameters)

        self._check_results(result)

    def drop_property(self, type: str, is_vertex: bool, property_name: str) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(property_name, Param.propertyName)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.isVertex.get_index_str()] = is_vertex
        parameters[Param.propertyName.get_index_str()] = property_name

        result = self.run(GraphMethod.dropProperty, parameters)

        self._check_results(result)

    def get_property_keys(self, type: str, is_vertex: bool) -> Dict[str, PropertyType]:
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.isVertex.get_index_str()] = is_vertex

        result = self.run(GraphMethod.getPropertyKeys, parameters)

        property_keys = {}
        records = json.loads(result.value()[0])
        for key in records:
            property_keys[key] = PropertyType.build_by_prop_key(records[key])
        return property_keys

    def get_property_pk(self, type: str) -> str:
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = type

        results = self.run(GraphMethod.getPropertyPk, parameters)
        record = self._only_first_record(results)
        if record:
            return record.value()
        raise TypeNotFoundException.instance(True, type)

    def edit_direct(self, type: str, direct: bool) -> None:
        """

        :param type:
        :param direct:
        :return:
        """
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.direct.get_index_str()] = direct

        result = self.run(GraphMethod.editDirect, parameters)

        self._check_results(result)

    def get_edge_direct(self, type: str) -> bool:
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = type

        results = self.run(GraphMethod.getEdgeDirect, parameters)
        record = self._only_first_record(results)
        if record:
            return record.value()
        raise TypeNotFoundException.instance(False, type)

    def create_combined_edge_type(self, type: str, from_type: str, to_type: str) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(from_type, Param.fromType)
        Assert.not_empty_allowed(to_type, Param.toType)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.fromType.get_index_str()] = from_type
        parameters[Param.toType.get_index_str()] = to_type
        result = self.run(GraphMethod.createCombinedEdgeType, parameters)

        self._check_results(result)

    def get_combined_edge_type(self, type: str) -> List[CombinedEdgeType]:
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = type

        result = self.run(GraphMethod.getCombinedEdgeType, parameters)

        edge_types = []
        for record in result:
            edge_types.append(CombinedEdgeType.init_combined_edge_type(record[0][0], record[0][1]))

        return edge_types

    def rename_type_name(self, type: str, is_vertex: bool, new_type: str) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(new_type, Param.newType)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.isVertex.get_index_str()] = is_vertex
        parameters[Param.newType.get_index_str()] = new_type

        result = self.run(GraphMethod.renameTypeName, parameters)

        self._check_results(result)

    def rename_property_name(self, type: str, is_vertex: bool, old_prop_name: str, new_prop_name: str) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(old_prop_name, Param.oldPropName)
        Assert.not_empty_allowed(new_prop_name, Param.newPropName)
        Assert.not_equals_allowed(old_prop_name, new_prop_name, Param.oldPropName, Param.newPropName)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.isVertex.get_index_str()] = is_vertex
        parameters[Param.oldPropName.get_index_str()] = old_prop_name
        parameters[Param.newPropName.get_index_str()] = new_prop_name

        result = self.run(GraphMethod.renamePropertyName, parameters)

        self._check_results(result)

    def create_prop_index(self, type: str, is_vertex: bool, property: str) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(property, Param.property)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.isVertex.get_index_str()] = is_vertex
        parameters[Param.property.get_index_str()] = property

        result = self.run(GraphMethod.createPropIndex, parameters)

        self._check_results(result)

    def drop_prop_index(self, type: str, is_vertex: bool, property: str) -> None:
        Assert.not_empty_allowed(type, Param.type)
        Assert.not_empty_allowed(property, Param.property)

        parameters = {}
        parameters[Param.type.get_index_str()] = type
        parameters[Param.isVertex.get_index_str()] = is_vertex
        parameters[Param.property.get_index_str()] = property

        result = self.run(GraphMethod.dropPropIndex, parameters)

        self._check_results(result)

    def edit_property_desc(self, type: str, is_vertex: bool, prop_name: str, desc: str) -> None:
        Assert.not_empty_allowed(prop_name, Param.propertyName)
        Assert.not_empty_allowed(type, Param.type)

        self._check_results(self.run(GraphMethod.editPropDesc, parameter={
            Param.propertyName.get_index_str(): prop_name,
            Param.type.get_index_str(): type,
            Param.desc.get_index_str(): desc,
            Param.isVertex.get_index_str(): is_vertex
        }))

    def get_property_desc(self, type: str, is_vertex: bool, prop_name: str) -> Optional[str]:
        Assert.not_empty_allowed(prop_name, Param.propertyName)
        Assert.not_empty_allowed(type, Param.type)

        record = self._only_first_record(self.run(GraphMethod.getPropDesc, parameter={
            Param.propertyName.get_index_str(): prop_name,
            Param.type.get_index_str(): type,
            Param.isVertex.get_index_str(): is_vertex
        }))
        return record[0] if record else None

    def edit_graph_desc(self, desc: str) -> None:
        self._check_results(self.run(GraphMethod.editGraphDesc, parameter={
            Param.desc.get_index_str(): desc,
        }))

    def get_graph_desc(self) -> Optional[str]:
        record = self._only_first_record(self.run(GraphMethod.getGraphDesc, parameter={}))
        return record[0] if record else None

    def edit_type_desc(self, type: str, is_vertex: bool, desc: str) -> None:
        Assert.not_empty_allowed(type, Param.type)
        self._check_results(self.run(GraphMethod.editTypeDesc, parameter={
            Param.type.get_index_str(): type,
            Param.desc.get_index_str(): desc,
            Param.isVertex.get_index_str(): is_vertex
        }))

    def get_type_desc(self, type: str, is_vertex: bool) -> Optional[str]:
        Assert.not_empty_allowed(type, Param.type)

        record = self._only_first_record(self.run(GraphMethod.getTypeDesc, parameter={
            Param.type.get_index_str(): type,
            Param.isVertex.get_index_str(): is_vertex
        }))
        return record[0] if record else None
