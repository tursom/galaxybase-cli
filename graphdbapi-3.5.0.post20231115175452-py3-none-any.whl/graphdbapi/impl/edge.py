# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 16:50
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
import json
from graphdbapi.compat import deprecated
from typing import Set, Union, Iterator, Dict, Any, List

import graphdbapi.types
from graphdbapi.v1.utils.core import NpEncoder
from graphdbapi.v1.utils.Assert import Assert
from bolt.message import Param, GraphMethod
from bolt.exceptions import TypeNotFoundException
from graphdbapi.v1.utils.ValueUtil import ValueUtil
from graphdbapi.v1.graph import EdgeInfoByVertexPk, EdgeInfoByVertexId, EdgeInfo, ResponseItem

from graphdbapi.interface.edge import EdgeInterface
from graphdbapi.types import Edge
from graphdbapi.v1.enum import Direction
from graphdbapi.v1 import SearchPredicate, SearchOrder
from graphdbapi.v1.graph.query.condition import VisitCondition


class EdgeImpl(EdgeInterface):
    def retrieve_edge(self, edge_id: str) -> Edge:
        Assert.edge_id_allowed(edge_id, Param.edgeId)

        parameter = dict()
        parameter[Param.id.get_index_str()] = edge_id

        results = self.run(GraphMethod.retrieveEdge, parameter=parameter)

        record = self._only_first_record(results)
        if record:
            return Edge(record[0], self)

    def retrieve_edges_by_type(self, type: str) -> Iterator[Edge]:
        Assert.not_empty_allowed(type, Param.type)

        parameter = dict()
        parameter[Param.type.get_index_str()] = type
        result = self.run(GraphMethod.retrieveEdgesByType, parameter=parameter)

        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def retrieve_all_edges(self) -> Iterator[Edge]:
        result = self.run(GraphMethod.retrieveAllEdges, parameter={})
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def get_edge_count(self, type: str) -> int:
        Assert.not_empty_allowed(type, Param.type)

        parameter = dict()

        parameter[Param.type.get_index_str()] = type
        results = self.run(GraphMethod.getEdgeCount, parameter=parameter)

        record = self._only_first_record(results)
        if record:
            return record[0]

        raise TypeNotFoundException.instance(False, type)

    def get_all_edge_count(self) -> int:
        results = self.run(GraphMethod.getAllEdgeCount, parameter={})
        record = self._only_first_record(results)
        if record:
            return record[0]

        return 0

    def insert_edge_by_vertex_id(self, from_id: int, to_id: int, type: str, property: Union[Dict[str, Any], None]) -> Edge:
        parameters = ValueUtil.edge_info_by_id(from_id, to_id, type, property, True, is_merge=True)

        results = self.run(GraphMethod.insertEdgeByVertexId, parameters)

        record = self._only_first_record(results)
        if record:
            return Edge(record[0], self)

    def update_edge(self, edge_id: str, property: Dict[str, Any], is_merge:bool) -> Edge:
        Assert.edge_id_allowed(edge_id, Param.edgeId)

        parameters = {}
        parameters[Param.edgeId.get_index_str()] = edge_id
        parameters[Param.isMerge.get_index_str()] = is_merge
        parameters[Param.property.get_index_str()] = ValueUtil.get_map_value_property(property, True, Param.property)

        results = self.run(GraphMethod.updateEdge, parameters)

        record = self._only_first_record(results)
        if record:
            return Edge(record[0], self)

    def retrieve_or_insert_edge_by_vertex_id(self, from_id: int, to_id: int, type: str,
                                             property: Union[Dict[str, Any], None]) \
            -> Iterator[Edge]:
        parameters = ValueUtil.edge_info_by_id(from_id, to_id, type, property, True, is_merge=True)
        result = self.run(GraphMethod.retrieveOrInsertEdgeByVertexId, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def delete_edge_by_vertex_pk(self, from_pk: str, from_type: str, to_pk: str, to_type: str,
                                 edge_types: Union[Set[str], None]) -> None:
        self.delete_edge_by_vertex_pk_with_condition(from_pk, from_type, to_pk, to_type, None, edge_types)

    def delete_edge_by_vertex_pk_with_condition(
            self, from_pk: str, from_type: str, to_pk: str, to_type: str,
            edge_condition: Union[VisitCondition, None],
            edge_types: Union[Set[str], None]) -> None:
        Assert.not_empty_allowed(from_pk, Param.fromPk)
        Assert.not_empty_allowed(from_type, Param.fromType)
        Assert.not_empty_allowed(to_pk, Param.toPk)
        Assert.not_empty_allowed(to_type, Param.toType)

        parameters = dict()
        parameters[Param.fromPk.get_index_str()] = from_pk
        parameters[Param.fromType.get_index_str()] = from_type
        parameters[Param.toPk.get_index_str()] = to_pk
        parameters[Param.toType.get_index_str()] = to_type

        if edge_condition is None:
            parameters[Param.edgeCondition.get_index_str()] = ""
        else:
            parameters[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.__encode_json__(edge_condition)

        if edge_types is None:
            parameters[Param.edgeTypes.get_index_str()] = []
        else:
            parameters[Param.edgeTypes.get_index_str()] = list(edge_types)

        result = self.run(GraphMethod.deleteEdgesBySrcDstPk, parameters)
        self._check_results(result)

    @deprecated("This function will be removed soon")
    def delete_edge_by_vertex_id(self, from_id: int, to_id: int, edge_limit: int) -> None:
        Assert.positive_allowed(from_id, Param.fromId)
        Assert.positive_allowed(to_id, Param.toId)

        edge_limit = -1 if edge_limit <= 0 else edge_limit

        parameters = {}
        parameters[Param.fromId.get_index_str()] = from_id
        parameters[Param.toId.get_index_str()] = to_id
        parameters[Param.edgeLimit.get_index_str()] = edge_limit

        result = self.run(GraphMethod.deleteEdgeByVertexId, parameters)
        self._check_results(result)

    def delete_edge_by_vertex_id_with_edge_type(self, from_id: int, to_id: int, edge_types: Union[Set[str], None]) -> None:
        self.delete_edge_by_vertex_id_with_condition(from_id, to_id, None, edge_types)

    def delete_edge_by_vertex_id_with_condition(
            self, from_id: int, to_id: int,
            edge_condition: Union[VisitCondition, None],
            edge_types: Union[Set[str], None]) -> None:
        Assert.positive_allowed(from_id, Param.fromId)
        Assert.positive_allowed(to_id, Param.toId)

        parameters = {}
        parameters[Param.fromId.get_index_str()] = from_id
        parameters[Param.toId.get_index_str()] = to_id
        if edge_condition is None:
            parameters[Param.edgeCondition.get_index_str()] = ""
        else:
            parameters[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.__encode_json__(edge_condition)

        if edge_types is None:
            parameters[Param.edgeTypes.get_index_str()] = []
        else:
            parameters[Param.edgeTypes.get_index_str()] = list(edge_types)

        result = self.run(GraphMethod.deleteEdgesBySrcDstId, parameters)
        self._check_results(result)

    def delete_edge(self, edge_id: str) -> None:
        Assert.edge_id_allowed(edge_id, Param.edgeId)

        parameters = {}
        parameters[Param.edgeId.get_index_str()] = edge_id

        result = self.run(GraphMethod.deleteEdge, parameters)

        self._check_results(result)

    def delete_edges(self, items: List[str]) -> List[str]:
        for item in items:
            Assert.edge_id_allowed(item, Param.edgeId)

        parameters = {}
        parameters[Param.list.get_index_str()] = items

        return self.send_message_operator(GraphMethod.deleteEdges, parameters)

    def insert_edges_by_vertex_pk(self, items: List[EdgeInfoByVertexPk]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_pks(items, True, Param.list)
        return self.send_edge_operate(GraphMethod.insertEdgesByVertexPk, parameters)

    def retrieve_edges(self, items: List[str]) -> List[ResponseItem]:
        for item in items:
            Assert.edge_id_allowed(item, Param.edgeId)
        parameters = {}
        parameters[Param.list.get_index_str()] = items

        return self.send_edge_operate(GraphMethod.retrieveEdges, parameters)

    def insert_edge_by_vertex_pk(
            self, from_pk: str, from_type: str, create_from: bool,
            to_pk: str, to_type: str, create_to: bool,
            type: str, property: Union[Dict[str, Any], None]
    ) -> Edge:
        parameters = ValueUtil.edge_info_by_pk(from_pk, from_type, create_from, to_pk, to_type, create_to,type,
                                                    property, True, is_merge=True)
        results = self.run(GraphMethod.insertEdgeByVertexPk, parameter=parameters)

        record = self._only_first_record(results)
        if record:
            return Edge(record[0], self)

    def retrieve_or_insert_edge_by_vertex_pk(
            self, from_pk: str, from_type: str, create_from: bool,
            to_pk: str, to_type: str, create_to: bool,
            type: str, property: Union[Dict[str, Any], None]
    ) -> Iterator[Edge]:
        parameters = ValueUtil.edge_info_by_pk(
            from_pk, from_type, create_from,
            to_pk, to_type, create_to,
            type, property, True, is_merge=True
        )
        result = self.run(GraphMethod.retrieveOrInsertEdgeByVertexPk, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def retrieve_or_insert_edges_by_vertex_id(self, items: List[EdgeInfoByVertexId]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_ids(items, True, Param.list)
        return self.send_edges_operate(GraphMethod.retrieveOrInsertEdgesByVertexId, parameters)

    def retrieve_or_insert_edges_by_vertex_pk(self, items: List[EdgeInfoByVertexPk]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_pks(items, True, Param.list)
        return self.send_edges_operate(GraphMethod.retrieveOrInsertEdgesByVertexPk, parameters)

    def insert_edges_by_vertex_id(self, items: List[EdgeInfoByVertexId]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_ids(items, True, Param.list)
        return self.send_edge_operate(GraphMethod.insertEdgesByVertexId, parameters)

    def upsert_edge_by_vertex_pk(
        self, from_pk: str, from_type: str, create_from: bool,
        to_pk: str, to_type: str, create_to: bool,
        type: str, property: Union[Dict[str, Any]], is_merge:bool
    ) -> Iterator[Edge]:
        parameters = ValueUtil.edge_info_by_pk(from_pk, from_type, create_from, to_pk, to_type, create_to, type,
                                                    property, True, is_merge=is_merge)
        result = self.run(GraphMethod.upsertEdgeByVertexPk, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def update_edge_by_vertex_pk(
        self, from_pk: str, from_type: str, to_pk: str, to_type: str,
        type: str, property: Union[Dict[str, Any]], is_merge:bool
    ) -> Iterator[Edge]:
        return self.update_edge_by_vertex_pk_with_condition(
            from_pk, from_type, to_pk, to_type, type, None, property, is_merge)

    def update_edge_by_vertex_pk_with_condition(
            self, from_pk: str, from_type: str, to_pk: str, to_type: str, type: str,
            edge_condition: Union[VisitCondition, None],
            property: Union[Dict[str, Any]], is_merge: bool
    ) -> Iterator[Edge]:
        parameters = ValueUtil.edge_info_by_pk(from_pk, from_type, False, to_pk, to_type, False, type,property, True, is_merge=is_merge)
        if edge_condition is None:
            parameters[Param.edgeCondition.get_index_str()] = ""
        else:
            parameters[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.__encode_json__(edge_condition)
        result = self.run(GraphMethod.updateEdgeByVertexPk, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def update_edges(self, items: List[EdgeInfo]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_edge_ids(items, True, Param.list)
        return self.send_edge_operate(GraphMethod.updateEdges, parameters)

    def upsert_edges_by_vertex_pk(self, items: List[EdgeInfoByVertexPk]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_pks(items, True, Param.list)
        return self.send_edges_operate(GraphMethod.upsertEdgesByVertexPk, parameters)

    def update_edges_by_vertex_pk(self, items: List[EdgeInfoByVertexPk]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_pks(items, True, Param.list)
        return self.send_edges_operate(GraphMethod.updateEdgesByVertexPk, parameters)

    def upsert_edge_by_vertex_id(self, from_id: int, to_id: int, type: str, property: Union[Dict[str, Any]], is_merge:bool) \
            -> Iterator[Edge]:
        parameters = ValueUtil.edge_info_by_id(from_id, to_id, type, property, True, is_merge=is_merge)
        result = self.run(GraphMethod.upsertEdgeByVertexId, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def update_edge_by_vertex_id(self, from_id: int, to_id: int, type: str, property: Union[Dict[str, Any]], is_merge:bool) \
            -> Iterator[Edge]:
        return self.update_edge_by_vertex_id_with_condition(from_id, to_id, type, None, property, is_merge)

    def update_edge_by_vertex_id_with_condition(
            self, from_id: int, to_id: int, type: str,
            edge_condition: Union[VisitCondition, None],
            property: Union[Dict[str, Any]], is_merge:bool
    ) -> Iterator[Edge]:
        parameters = ValueUtil.edge_info_by_id(from_id, to_id, type, property, True, is_merge=is_merge)
        if edge_condition is None:
            parameters[Param.edgeCondition.get_index_str()] = ""
        else:
            parameters[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.__encode_json__(edge_condition)
        result = self.run(GraphMethod.updateEdgeByVertexId, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def upsert_edges_by_vertex_id(self, items: List[EdgeInfoByVertexId]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_ids(items, True, Param.list)
        return self.send_edges_operate(GraphMethod.upsertEdgesByVertexId, parameters)

    def update_edges_by_vertex_id(self, items: List[EdgeInfoByVertexId]) -> List[ResponseItem]:
        parameters = ValueUtil.edge_info_by_ids(items, True, Param.list)
        return self.send_edges_operate(GraphMethod.updateEdgesByVertexId, parameters)

    def retrieve_edge_by_vertex_id(
            self, id: int, edge_type_filter: Union[Set[str], None], direction: Direction, limit_edge: int,
            vertex_condition: Union[VisitCondition, None], edge_condition: Union[VisitCondition, None], get_loop: bool
    ) -> Iterator[Edge]:
        Assert.positive_allowed(id, Param.id)

        parameters = {}
        parameters[Param.id.get_index_str()] = id
        if edge_type_filter is None:
            parameters[Param.edgeTypeFilter.get_index_str()] = []
        else:
            parameters[Param.edgeTypeFilter.get_index_str()] = list(edge_type_filter)
        parameters[Param.direction.get_index_str()] = direction.name
        parameters[Param.limitEdge.get_index_str()] = limit_edge
        if vertex_condition is None:
            parameters[Param.vertexCondition.get_index_str()] = ""
        else:
            parameters[Param.vertexCondition.get_index_str()] = vertex_condition.Serializable.__encode_json__(vertex_condition)
        if edge_condition is None:
            parameters[Param.edgeCondition.get_index_str()] = ""
        else:
            parameters[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.__encode_json__(edge_condition)
        parameters[Param.getLoop.get_index_str()] = get_loop

        result = self.run(GraphMethod.retrieveEdgeByVertexId, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def retrieve_edge_by_src_dst_vertex_id(
            self, src_id: int, dst_id: int, edge_type_filter: Union[Set[str], None], direction: Direction,
            edge_condition: Union[VisitCondition, None]) -> Iterator[Edge]:
        Assert.positive_allowed(src_id, Param.srcId)
        Assert.positive_allowed(dst_id, Param.dstId)

        parameters = {}
        parameters[Param.srcId.get_index_str()] = src_id
        parameters[Param.dstId.get_index_str()] = dst_id
        if edge_type_filter is None:
            parameters[Param.edgeTypeFilter.get_index_str()] = []
        else:
            parameters[Param.edgeTypeFilter.get_index_str()] = list(edge_type_filter)
        parameters[Param.direction.get_index_str()] = direction.name
        if edge_condition is None:
            parameters[Param.edgeCondition.get_index_str()] = ""
        else:
            parameters[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.\
                __encode_json__(edge_condition)
        parameters[Param.getLoop.get_index_str()] = True

        result = self.run(GraphMethod.retrieveEdgeBySrcDst, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def retrieve_edge_by_vertex_pk(
            self, pk: str, type: str, edge_type_filter: Union[Set[str], None], direction: Direction, limit_edge: int,
            vertex_condition: Union[VisitCondition, None], edge_condition: Union[VisitCondition, None], get_loop: bool
        ) -> Iterator[Edge]:
        Assert.not_empty_allowed(pk, Param.pk)
        Assert.not_empty_allowed(type, Param.type)

        parameters = {}
        parameters[Param.pk.get_index_str()] = pk
        parameters[Param.type.get_index_str()] = type
        if edge_type_filter is None:
            parameters[Param.edgeTypeFilter.get_index_str()] = []
        else:
            parameters[Param.edgeTypeFilter.get_index_str()] = list(edge_type_filter)
        parameters[Param.direction.get_index_str()] = direction.name
        parameters[Param.limitEdge.get_index_str()] = limit_edge
        if vertex_condition is None:
            parameters[Param.vertexCondition.get_index_str()] = ""
        else:
            parameters[Param.vertexCondition.get_index_str()] = vertex_condition.Serializable.__encode_json__(
                vertex_condition)
        if edge_condition is None:
            parameters[Param.edgeCondition.get_index_str()] = ""
        else:
            parameters[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.__encode_json__(
                edge_condition)
        parameters[Param.getLoop.get_index_str()] = get_loop

        result = self.run(GraphMethod.retrieveEdgeByVertexPk, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def retrieve_edge_by_vertex_pks(
            self, pk: str, type: str, another_pk: str, another_type: str, edge_type_filter: Union[Set[str], None],
            direction: Direction, limit_edge: int, edge_condition: Union[VisitCondition, None]) -> Iterator[Edge]:
        Assert.not_empty_allowed(pk, Param.fromPk)
        Assert.not_empty_allowed(type, Param.fromType)
        Assert.not_empty_allowed(another_pk, Param.toPk)
        Assert.not_empty_allowed(another_type, Param.toType)

        parameters = {}
        parameters[Param.fromPk.get_index_str()] = pk
        parameters[Param.fromType.get_index_str()] = type
        parameters[Param.toPk.get_index_str()] = another_pk
        parameters[Param.toType.get_index_str()] = another_type
        if edge_type_filter is None:
            parameters[Param.edgeTypeFilter.get_index_str()] = []
        else:
            parameters[Param.edgeTypeFilter.get_index_str()] = list(edge_type_filter)
        parameters[Param.direction.get_index_str()] = direction.name
        parameters[Param.limitEdge.get_index_str()] = limit_edge
        if edge_condition is None:
            parameters[Param.edgeCondition.get_index_str()] = ""
        else:
            parameters[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.__encode_json__(
                edge_condition)

        result = self.run(GraphMethod.retrieveEdgesBySrcDstPk, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def send_edge_operate(self, method: GraphMethod, parameters: Dict[str, Any]) -> List[ResponseItem]:
        result = self.run(method, parameters)
        response_items = []
        for record in result:
            if isinstance(record[0], str):
                response_items.append(ResponseItem.error(record[0]))
            elif isinstance(record[0], graphdbapi.types.Relationship):
                response_items.append(ResponseItem.success(Edge(record[0], self)))
            else:
                response_items.append(ResponseItem.success(None))
        return response_items

    def search_edges_by_index(self, type_name: str, prop_name: str, data: Any, skip: int, limit: int) -> Iterator[str]:
        Assert.not_empty_allowed(type_name,  Param.typeName)
        Assert.not_empty_allowed(prop_name,  Param.propertyName)
        Assert.not_null_allowed(data,  Param.propertyValue)

        parameters = {}
        parameters[Param.type.get_index_str()] = type_name
        parameters[Param.propertyName.get_index_str()] = prop_name
        parameters[Param.propertyValue.get_index_str()] = data
        parameters[Param.limit.get_index_str()] = limit
        parameters[Param.skip.get_index_str()] = skip

        result = self.run(GraphMethod.searchEdgesByIndex, parameters)

        return map(lambda record: record[0], self._results_iter(result))

    def search_edge_property(self, edge_type: str,
                             predicates: Union[None, List[SearchPredicate]],
                             orders: Union[None, List[SearchOrder]], skip: int, limit: int) -> Iterator[Edge]:
        Assert.not_empty_allowed(edge_type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = edge_type
        parameters[Param.limit.get_index_str()] = limit
        parameters[Param.skip.get_index_str()] = skip
        parameters[Param.searchPredicate.get_index_str()] = \
            None if predicates is None else json.dumps(predicates, cls=NpEncoder, ensure_ascii=False)
        parameters[Param.searchOrder.get_index_str()] = \
            None if orders is None else json.dumps(orders, cls=NpEncoder, ensure_ascii=False)

        result = self.run(GraphMethod.searchEdgeProperty, parameters)
        return map(lambda record: Edge(record[0], self), self._results_iter(result))

    def send_edges_operate(self, method: GraphMethod, parameters: Dict[str, Any]) -> List[ResponseItem]:
        result = self.run(method, parameters)
        response_items = []

        for record in result:
            if isinstance(record[0], str):
                response_items.append(ResponseItem.error(record[0]))
            else:
                edges = []
                for item in record[0]:
                    if item is None:
                        edges.append(None)
                    else:
                        edges.append(Edge(item, self))
                response_items.append(ResponseItem.success(edges))

        return response_items
