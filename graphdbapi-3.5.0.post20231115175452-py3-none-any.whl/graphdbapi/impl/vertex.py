# -*- coding    : utf-8 -*-
# @Time         : 2021/2/22 15:12
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
import json

from typing import Union, Set, Dict, Any, Iterator, List

import graphdbapi.types
from bolt.message import Param, GraphMethod
from graphdbapi.types import Vertex
from graphdbapi.interface.vertex import VertexInterface
from graphdbapi.v1.utils.core import NpEncoder
from graphdbapi.v1.utils.Assert import Assert
from graphdbapi.v1.utils.ValueUtil import ValueUtil
from graphdbapi.v1.enum import Direction
from graphdbapi.v1 import SearchPredicate, SearchOrder
from graphdbapi.v1.graph import ResponseItem, VertexInfoByPk, VertexInfoById
from graphdbapi.v1.graph.query.condition import VisitCondition
from graphdbapi.v1.graph.query import EdgeDegreeInfo

from bolt.exceptions import PkNotFoundException,TypeNotFoundException,VertexFoundException


class VertexImpl(VertexInterface):
    def get_vertex_id_by_pk(self, pk: str) -> Set[int]:
        Assert.not_empty_allowed(pk, Param.pk)

        ids = set()
        parameters = dict()

        parameters[Param.pk.get_index_str()] = pk
        parameters[Param.type.get_index_str()] = ""

        results = self.run(GraphMethod.getVertexIdByPk, parameter=parameters)

        for record in results:
            ids.add(record[0])

        return ids

    def get_vertex_id_by_pk_and_type(self, pk: str, type: str) -> int:
        Assert.not_empty_allowed(pk, Param.pk)
        Assert.not_empty_allowed(type, Param.type)

        parameters = dict()

        parameters[Param.pk.get_index_str()] = pk
        parameters[Param.type.get_index_str()] = type

        results = self.run(GraphMethod.getVertexIdByPk, parameter=parameters)

        record = self._only_first_record(results)
        if record:
            return record[0]

    def retrieve_vertex(self, id: int) -> Vertex:
        Assert.positive_allowed(id, Param.id)

        parameters = dict()
        parameters[Param.id.get_index_str()] = id

        results = self.run(GraphMethod.retrieveVertex, parameter=parameters)
        record = self._only_first_record(results)
        if record:
            return Vertex(record[0], self)

    def retrieve_vertex_by_pk(self, pk: str, type: str) -> Vertex:
        Assert.not_empty_allowed(pk, Param.pk)
        Assert.not_empty_allowed(type, Param.type)

        parameters = dict()
        parameters[Param.pk.get_index_str()] = pk
        parameters[Param.type.get_index_str()] = type

        results = self.run(GraphMethod.retrieveVertexByPk, parameter=parameters)
        record = self._only_first_record(results)
        if record:
            return Vertex(record[0], self)

    def retrieve_or_insert_vertex_by_pk(self, pk: str, type: str, property: Union[Dict[str, Any], None]) -> Vertex:
        parameters = ValueUtil.vertex_info_by_pk(pk, type, property, True, is_merge=True)
        results = self.run(GraphMethod.retrieveOrInsertVertexByPk, parameter=parameters)

        record = self._only_first_record(results)
        if record:
            return Vertex(record[0], self)

    def retrieve_vertexes_by_type(self, type: str) -> Iterator[Vertex]:
        Assert.not_empty_allowed(type, Param.type)

        parameter = dict()
        parameter[Param.type.get_index_str()] = type

        result = self.run(GraphMethod.retrieveVertexesByType, parameter=parameter)

        return map(lambda record: Vertex(record[0], self), self._results_iter(result))

    def retrieve_vertexes(self, ids: List[int]) -> List[ResponseItem]:
        for item in ids:
            Assert.positive_allowed(item, Param.id)

        parameters = dict()

        parameters[Param.list.get_index_str()] = ids

        return self.send_vertexes_operate(GraphMethod.retrieveVertexes, parameters)

    def retrieve_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        parameters = ValueUtil.vertex_info_by_pks(items, True, Param.list)
        return self.send_vertexes_operate(GraphMethod.retrieveVertexesByPk, parameters)

    def update_vertexes(self, items: List[VertexInfoById]) -> List[ResponseItem]:
        parameters = ValueUtil.vertex_info_by_ids(items, True, Param.list)

        return self.send_vertexes_operate(GraphMethod.updateVertexes, parameters)


    def retrieve_all_vertexes(self) -> Iterator[Vertex]:
        result = self.run(GraphMethod.retrieveAllVertexes, parameter={})

        return map(lambda record: Vertex(record[0], self), self._results_iter(result))

    def get_vertex_count(self, type: str) -> int:
        Assert.not_empty_allowed(type, Param.type)

        parameter = dict()
        parameter[Param.type.get_index_str()] = type
        results = self.run(GraphMethod.getVertexCount, parameter=parameter)
        record = self._only_first_record(results)
        if record:
            return record[0]
        raise TypeNotFoundException.instance(True, type)

    def get_all_vertex_count(self) -> int:
        results = self.run(GraphMethod.getAllVertexCount, parameter={})
        record = self._only_first_record(results)
        if record:
            return record[0]
        return 0

    def get_degree(self, id: int, edge_type_filter: Union[Set[str], None], direction: Direction,
                   vertex_condition: Union[VisitCondition, None], edge_condition: Union[VisitCondition, None],
                   include_loop: bool) -> EdgeDegreeInfo:
        Assert.positive_allowed(id, Param.id)

        parameter = dict()

        parameter[Param.id.get_index_str()] = id
        parameter[Param.direction.get_index_str()] = direction.name
        parameter[Param.getLoop.get_index_str()] = include_loop
        parameter[Param.edgeTypeFilter.get_index_str()] = edge_type_filter
        if vertex_condition is None:
            parameter[Param.vertexCondition.get_index_str()] = ""
        else:
            parameter[Param.vertexCondition.get_index_str()] = vertex_condition.Serializable.__encode_json__(vertex_condition)
        if edge_condition is None:
            parameter[Param.edgeCondition.get_index_str()] = ""
        else:
            parameter[Param.edgeCondition.get_index_str()] = edge_condition.Serializable.__encode_json__(edge_condition)

        results = self.run(GraphMethod.getDegree, parameter=parameter)

        record = self._only_first_record(results)
        if record:
            degree = json.loads(record[0])
            return EdgeDegreeInfo.init_edge_degree_info(**degree)

    def insert_vertex_by_pk(self, pk: str, type: str, property: Dict[str, Any] = None) -> Vertex:
        Assert.not_empty_allowed(pk, Param.pk)
        Assert.not_empty_allowed(type, Param.type)

        if not property:
            property = {}

        parameters = dict()
        parameters[Param.pk.get_index_str()] = pk
        parameters[Param.type.get_index_str()] = type
        parameters[Param.property.get_index_str()] = ValueUtil.get_map_value_property(property, True, Param.property)

        results = self.run(GraphMethod.insertVertexByPk, parameter=parameters)

        record = self._only_first_record(results)
        if record:
            return Vertex(record[0], self)

        raise VertexFoundException.instance(pk=pk, type=type)

    def insert_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        parameters = ValueUtil.vertex_info_by_pks(items, True, Param.list)

        return self.send_vertexes_operate(GraphMethod.insertVertexesByPk, parameters)

    def delete_vertexes(self, ids: List[int]) -> List[str]:
        for _ in ids:
            Assert.positive_allowed(_, Param.id)

        parameters = dict()

        parameters[Param.list.get_index_str()] = ids

        return self.send_message_operator(GraphMethod.deleteVertexes, parameters)

    def delete_vertex(self, id: int) -> None:
        Assert.positive_allowed(id, Param.id)

        parameters = dict()
        parameters[Param.id.get_index_str()] = id

        results = self.run(GraphMethod.deleteVertexByPk, parameter=parameters)

        self._check_results(results)

    def delete_vertex_by_pk(self, pk: str, type: str) -> None:
        Assert.not_empty_allowed(pk, Param.pk)
        Assert.not_empty_allowed(type, Param.type)

        parameters = dict()

        parameters[Param.pk.get_index_str()] = pk
        parameters[Param.type.get_index_str()] = type
        results = self.run(GraphMethod.deleteVertexByPk, parameter=parameters)

        self._check_results(results)

    def upsert_vertex_by_pk(self, pk: str, type: str, property: Dict[str, Any], is_merge:bool) -> Vertex:
        parameters = ValueUtil.vertex_info_by_pk(pk, type, property, True, is_merge=is_merge)

        results = self.run(GraphMethod.upsertVertexByPk, parameters)

        record = self._only_first_record(results)
        if record:
            node = record[0]
            if node is None:
                raise PkNotFoundException.instance(pk=pk)
            return Vertex(node, self)

    def update_vertex_by_pk(self, pk: str, type: str, property: Dict[str, Any], is_merge:bool) -> Vertex:
        parameters = ValueUtil.vertex_info_by_pk(pk, type, property, True, is_merge=is_merge)

        results = self.run(GraphMethod.updateVertexByPk, parameters)
        record = self._only_first_record(results)
        if record:
            node = record[0]
            if node is None:
                raise PkNotFoundException.instance(pk=pk)
            return Vertex(node, self)

    def update_vertex(self, id: int, property: Dict[str, Any], is_merge: bool) -> Vertex:
        parameters = ValueUtil.vertex_info_by_id(id, property, True, is_merge=is_merge)

        results = self.run(GraphMethod.updateVertex, parameters)
        record = self._only_first_record(results)
        if record:
            return Vertex(record[0], self)

    def delete_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[str]:
        parameters = {}
        parameter = []

        for info in items:
            Assert.not_empty_allowed(info.get_pk(), Param.pk)
            Assert.not_empty_allowed(info.get_type(), Param.type)

            map = {}
            map[Param.pk.get_index_str()] = info.get_pk()
            map[Param.type.get_index_str()] = info.get_type()

            parameter.append(map)

        parameters[Param.list.get_index_str()] = parameter

        return self.send_message_operator(GraphMethod.deleteVertexesByPk, parameters)

    def upsert_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        parameters = ValueUtil.vertex_info_by_pks(items, True, Param.list)
        return self.send_vertexes_operate(GraphMethod.upsertVertexesByPk, parameters)

    def update_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        parameters = ValueUtil.vertex_info_by_pks(items, True, Param.list)
        return self.send_vertexes_operate(GraphMethod.updateVertexesByPk, parameters)

    def retrieve_or_insert_vertexes_by_pk(self, items: List[VertexInfoByPk]) -> List[ResponseItem]:
        parameters = ValueUtil.vertex_info_by_pks(items, True, Param.list)
        return self.send_vertexes_operate(GraphMethod.retrieveOrInsertVertexesByPk, parameters)

    def search_vertexes_by_index(self, type_name: str, prop_name: str, data: Any, skip: int, limit: int) -> Iterator[int]:
        Assert.not_empty_allowed(type_name,  Param.typeName)
        Assert.not_empty_allowed(prop_name,  Param.propertyName)
        Assert.not_null_allowed(data,  Param.propertyValue)

        parameters = {}
        parameters[Param.type.get_index_str()] = type_name
        parameters[Param.propertyName.get_index_str()] = prop_name
        parameters[Param.propertyValue.get_index_str()] = data
        parameters[Param.limit.get_index_str()] = limit
        parameters[Param.skip.get_index_str()] = skip

        result = self.run(GraphMethod.searchVertexesByIndex, parameters)

        return map(lambda record: record[0], self._results_iter(result))

    def search_vertex_property(self, vertex_type: str,
                               predicates: Union[None, List[SearchPredicate]],
                               orders: Union[None, List[SearchOrder]], skip: int, limit: int) -> Iterator[Vertex]:
        Assert.not_empty_allowed(vertex_type, Param.type)

        parameters = {}
        parameters[Param.type.get_index_str()] = vertex_type
        parameters[Param.limit.get_index_str()] = limit
        parameters[Param.skip.get_index_str()] = skip
        parameters[Param.searchPredicate.get_index_str()] = \
            None if predicates is None else json.dumps(predicates, cls=NpEncoder, ensure_ascii=False)
        parameters[Param.searchOrder.get_index_str()] = \
            None if orders is None else json.dumps(orders, cls=NpEncoder, ensure_ascii=False)

        result = self.run(GraphMethod.searchVertexProperty, parameters)
        return map(lambda record: Vertex(record[0], self), self._results_iter(result))


    def send_vertexes_operate(self, method: GraphMethod, parameters: Dict[str, List[Any]]) -> List[ResponseItem]:
        response_items = []
        result = self.run(method, parameters)
        for record in result:
            if isinstance(record[0], str):
                response_items.append(ResponseItem.error(record[0]))
            elif isinstance(record[0], graphdbapi.types.Node):
                response_items.append(ResponseItem.success(Vertex(record[0], self)))
            else:
                response_items.append(ResponseItem.success(None))
        return response_items