#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020/3/31 16:57
# @Author : jimmy
# @File : meta.py
# @Software: PyCharm
import time
from bolt.message.TempText import TempText


package = "graphdbapi"
version = "%s"% TempText.CLIENT_VERSION.value.split("/")[-1]