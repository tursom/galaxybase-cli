# -*- coding    : utf-8 -*-
# @Time         : 2021/3/2 19:29
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :

from .types.graph import Edge