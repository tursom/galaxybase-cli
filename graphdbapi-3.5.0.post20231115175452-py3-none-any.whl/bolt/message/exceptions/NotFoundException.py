# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 14:41
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .BaseException import GraphDbException


class NotFoundException(GraphDbException):
    """
    所有 NotFound 异常的基类
    """
    def __init__(self, message):
        super(NotFoundException, self).__init__(message)