# -*- coding    : utf-8 -*-
# @Time         : 2021/3/13 16:17
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .BaseException import GraphDbException

class SecurityException(GraphDbException):
    """
    由于安全性错误，无法与服务器通信。 \n
    发生此类错误时，应修复引起错误的安全原因以确保数据的安全。 \n
    从此错误中恢复可能需要重启server/driver/cluster。 \n
    """
    def __init__(self, *args, **kwargs):
        super(SecurityException, self).__init__(*args, **kwargs)