# -*- coding    : utf-8 -*-
# @Time         : 2021/3/5 19:59
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com


class GraphDbException(RuntimeError):
    """
    所有因与远程GraphDb服务器通信引起的异常的基类。
    """
    def __init__(self, message, *args, code="N/A", **kwargs):
        self.__code = code
        self.__message = message

    def code(self):
        return self.__code

    def graph_db_error_code(self):
        return self.__code

    def __str__(self):
        return self.__message