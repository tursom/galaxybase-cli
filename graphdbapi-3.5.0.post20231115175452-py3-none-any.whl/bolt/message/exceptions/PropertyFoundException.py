# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 14:56
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .FoundException import FoundException


class PropertyFoundException(FoundException):
    """
    属性已存在引发的异常
    """
    def __init__(self, message):
        super(PropertyFoundException, self).__init__(message)