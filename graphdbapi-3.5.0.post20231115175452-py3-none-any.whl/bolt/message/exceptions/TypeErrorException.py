# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 14:57
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .BaseException import GraphDbException


class TypeErrorException(GraphDbException):
    """
    输入的起始点或终止点的类型不是作为边类型的起始类型和终止类型时引发的异常
    """
    def __init__(self, message):
        super(TypeErrorException, self).__init__(message)