# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 15:21
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .FoundException import FoundException


class VertexFoundException(FoundException):
    """
    点已存在引发的异常
    """
    def __init__(self, message):
        super(VertexFoundException, self).__init__(message)

    @staticmethod
    def instance(id="", pk="", type=""):
        if id:
            message = "Existing vertex: id = " + id
        else:
            message = "Existing vertex: pk = %s, type = %s" % (pk, type)
        return VertexFoundException(message)
