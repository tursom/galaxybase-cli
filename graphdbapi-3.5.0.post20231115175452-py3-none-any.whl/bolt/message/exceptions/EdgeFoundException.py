# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 14:14
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .FoundException import FoundException


class EdgeFoundException(FoundException):
    """
    边已存在异常
    """
    __model = {
        "found_by_id": "Existing edge: fromId = %d, toId = %d, type = %s",
        "found_by_pk": "Existing edge: fromPk = %s, fromType = %s, toPk = %s, toType = %s, type = %s",
    }

    def __init__(self, message):
        super(EdgeFoundException, self).__init__(message)

    @staticmethod
    def instance(message="", model="", params=tuple()):
        if model:
            message = EdgeFoundException.__model[model] % params
        return EdgeFoundException(message)

