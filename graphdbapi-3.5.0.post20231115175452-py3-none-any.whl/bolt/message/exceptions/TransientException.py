# -*- coding    : utf-8 -*-
# @Time         : 2021/3/13 16:22
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .BaseException import GraphDbException


class TransientException(GraphDbException):
    def __init__(self, *args, **kwargs):
        super(TransientException, self).__init__(*args, **kwargs)