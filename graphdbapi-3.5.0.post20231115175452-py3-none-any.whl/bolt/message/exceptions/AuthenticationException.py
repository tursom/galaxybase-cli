# -*- coding    : utf-8 -*-
# @Time         : 2021/3/13 16:17
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .SecurityException import SecurityException


class AuthenticationException(SecurityException):
    """
    由于提供的证书凭据错误，无法对服务器的driver进行身份验证。 发生此错误时，可以通过关闭当前driver并使用正确的证书凭据重新启动新driver来恢复错误
    """
    def __init__(self, *args, **kwargs):
        super(AuthenticationException, self).__init__(*args, **kwargs)
