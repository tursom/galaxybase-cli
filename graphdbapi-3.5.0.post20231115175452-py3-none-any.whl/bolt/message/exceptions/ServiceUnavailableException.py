from .BaseException import GraphDbException

class ServiceUnavailableException(GraphDbException):
    """
    表示driver无法与集群通信。
    """
    def __init__(self, *args, **kwargs):
        super(ServiceUnavailableException, self).__init__(*args, **kwargs)