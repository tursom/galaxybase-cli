# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 15:20
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .BaseException import GraphDbException


class ValueFormatException(GraphDbException):
    """
    输入参数值的类型与实际存储类型不一致引发的异常
    """
    def __init__(self, message):
        super(ValueFormatException, self).__init__(message)
