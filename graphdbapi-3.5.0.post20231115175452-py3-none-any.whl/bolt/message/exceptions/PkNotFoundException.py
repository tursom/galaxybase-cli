# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 14:46
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .NotFoundException import NotFoundException


class PkNotFoundException(NotFoundException):
    """
    点的外部唯一标识不存在引发的异常
    """
    def __init__(self, message):
        super(PkNotFoundException, self).__init__(message)

    @staticmethod
    def instance(*args, pk="", format=""):
        if pk:
            message = "Non-existing vertex:  Pk = " + pk
        else:
            message = format % args
        return PkNotFoundException(message)
