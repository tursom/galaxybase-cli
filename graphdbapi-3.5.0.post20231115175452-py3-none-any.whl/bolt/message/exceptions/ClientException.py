# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 13:47
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .BaseException import GraphDbException


class ClientException(GraphDbException):
    """
    表示客户端执行的操作不正确。
    """
    def __init__(self, *args, **kwargs):
        super(ClientException, self).__init__(*args, **kwargs)
