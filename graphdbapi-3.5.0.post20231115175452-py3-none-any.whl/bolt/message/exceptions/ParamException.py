# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 13:50
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .ClientException import ClientException


class ParamException(ClientException):
    """
    参数异常，用户输入的参数和接口所需要的参数无法匹配而引发的异常
    """
    def __init__(self, format, *args, code="N/A", **kwargs):
        super(ParamException, self).__init__(format % args, code=code, **kwargs)

