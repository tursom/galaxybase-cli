# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 15:24
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .NotFoundException import NotFoundException


class VertexNotFoundException(NotFoundException):
    """
    点不存在引发的异常
    """
    def __init__(self, message):
        super(VertexNotFoundException, self).__init__(message)

    @staticmethod
    def instance(id):
        message = "Non-existing vertex: id = %s" % id
        return VertexNotFoundException(message)