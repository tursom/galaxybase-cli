# -*- coding    : utf-8 -*-
# @Time         : 2021/3/9 13:59
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .BaseException import GraphDbException


class DatabaseException(GraphDbException):
    """
    表示底层数据库中抛出的问题。
    """
    def __init__(self, *args, **kwargs):
        super(DatabaseException, self).__init__(*args, **kwargs)
