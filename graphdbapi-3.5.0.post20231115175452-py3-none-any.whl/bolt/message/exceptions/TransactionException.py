# -*- coding    : utf-8 -*-
# @Time         : 2021/3/15 19:29
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
# @Comment      :
from .DatabaseException import DatabaseException


class TransactionException(DatabaseException):
    """
    事务相关的异常
    """
    def __init__(self, *args, **kwargs):
        super(TransactionException, self).__init__(*args, **kwargs)
