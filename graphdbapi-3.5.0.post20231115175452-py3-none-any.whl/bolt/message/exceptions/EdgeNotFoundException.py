# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 14:41
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .NotFoundException import NotFoundException


class EdgeNotFoundException(NotFoundException):
    """
    边不存在异常
    """
    def __init__(self, message):
        super(EdgeNotFoundException, self).__init__(message)

    @staticmethod
    def instance(edge_id):
        return EdgeNotFoundException("Non-existing edge:  edgeId = " + edge_id)