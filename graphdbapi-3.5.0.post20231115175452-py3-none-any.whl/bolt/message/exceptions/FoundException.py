# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 14:14
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .BaseException import GraphDbException


class FoundException(GraphDbException):
    """
    所有 Found 异常的基类
    """
    def __init__(self, message):
        super(FoundException, self).__init__(message)
