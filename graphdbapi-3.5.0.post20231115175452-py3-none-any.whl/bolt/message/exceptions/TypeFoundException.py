# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 14:58
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from .FoundException import FoundException


class TypeFoundException(FoundException):
    """
    点或边类型已存在引发的异常
    """
    def __init__(self, message):
        super(TypeFoundException, self).__init__(message)
