# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 11:31
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from enum import Enum


class GraphMethod(Enum):
    upsertEdges = 3, 0

    executeCypherTaskAsync = 4, 1
    getCypherTaskResult = 4, 2
    getCypherTaskStatus = 4, 3
    stopCypherTask = 4, 4

    # GLOBAL METHOD

    onInit = 0, 5
    getGraphs = 0, 6
    newGraph = 0, 7
    metrics = 4, 8

    # transaction operate

    txStart = 0, 9
    txSuccess = 0, 10
    txFailure = 0, 11
    txClose = 0, 12

    # GRAPH METHOD

    # execute cypher
    cypher = 4, 13

    getVertexIdByPk = 4, 14

    retrieveVertex = 4, 15

    retrieveVertexByPk = 4, 16

    retrieveVertexesByPk = 4, 17

    retrieveOrInsertVertexByPk = 3, 18

    retrieveOrInsertVertexesByPk = 3, 19

    retrieveOrInsertEdgeByVertexId = 3, 20

    retrieveOrInsertEdgesByVertexId = 3, 21

    insertVertexByPk = 3, 22

    upsertVertex = 3, 23

    insertVertexesByPk = 3, 24

    upsertVertexByPk = 3, 25

    upsertVertexesByPk = 3, 26

    deleteVertexByPk = 3, 27

    deleteVertexes = 3, 28

    deleteVertexesByPk = 3, 29

    retrieveVertexes = 4, 30

    retrieveEdges = 4, 31

    retrieveVertexesByType = 4, 32

    retrieveAllVertexes = 4, 33

    retrieveEdge = 4, 34

    insertEdgeByVertexId = 3, 35

    insertEdgesByVertexId = 3, 36

    deleteEdges = 3, 37

    insertEdgeByVertexPk = 3, 38

    retrieveEdgeByVertexPk = 3, 39

    deleteEdgeByVertexPk = 3, 40

    upsertEdgeAccurateByVertexPk = 3, 41

    upsertEdge = 3, 42

    upsertEdgeByVertexId = 3, 43

    upsertEdgesByVertexId = 3, 44

    upsertEdgeByVertexPk = 3, 45

    upsertEdgesByVertexPk = 3, 46

    insertEdgesByVertexPk = 3, 47

    retrieveOrInsertEdgeByVertexPk = 3, 48

    retrieveOrInsertEdgesByVertexPk = 3, 49

    deleteEdge = 3, 50

    retrieveEdgesByType = 4, 51

    retrieveAllEdges = 4, 52

    deleteVertexesAndNeighbor = 0, 53

    deleteEdgeBySrcDstOld = 0, 54

    deleteEdgeByVertexId = 0, 55

    changeEdgeDst = 0, 56

    createVertexType = 3, 57

    dropVertexType = 3, 58

    getVertexTypes = 4, 59

    createEdgeType = 3, 60

    createCombinedEdgeType = 3, 61

    dropEdgeType = 3, 62

    dropCombinedEdgeType = 3, 63

    getEdgeTypes = 4, 64

    getCombinedEdgeType = 4, 65

    getEdgeDirect = 4, 66

    getPropertyKeys = 4, 67

    getPropertyPk = 4, 68

    createProperty = 3, 69

    dropProperty = 3, 70

    editDirect = 2, 71

    renameTypeName = 3, 72

    renamePropertyName = 3, 73

    putPropertyValue = 3, 74

    removePropertyValue = 3, 75

    createPropIndex = 1, 76

    dropPropIndex = 1, 77

    getVertexCount = 4, 78

    getAllVertexCount = 4, 79

    getEdgeCount = 4, 80

    getAllEdgeCount = 4, 81

    deleteGraph = 2, 82

    clearGraph = 2, 83

    shortestPath = 4, 84

    retrieveEdgeByVertexId = 4, 85

    retrieveEdgeBySrcDst = 4, 86

    getDegree = 4, 87

    editGraphName = 2, 88

    upsertEdgesProperty = 0, 89

    viewGraphAlgo = 0, 90

    stopBfs = 0, 91

    stopBfsById = 0, 92

    listBfs = 0, 93

    bfsMaster = 4, 94

    bfsWithResultType = 4, 95

    bfsMultiConditionSpecifiedDepth = 4, 96

    isGraphNameUsed = 0, 97

    bfsDelete = 0, 98

    stopCypher = 0, 99

    getCypherMetrics = 4, 100

    subGraph = 4, 101

    # batch operate

    upsertVerticesProperty = 0, 102

    retrieveEdgeBySrcDstPk = 3, 103

    upsertVertexes = 3, 104

    getGraph = 0, 105

    routingTable = 0, 106

    updateVertex = 3, 107

    updateVertexes = 3,108

    updateVertexByPk = 3, 109

    updateVertexesByPk = 3, 110

    updateEdge = 3, 111

    updateEdges = 3, 112

    updateEdgeByVertexId = 3, 113

    updateEdgesByVertexId = 3, 114

    updateEdgesByVertexPk = 3, 115

    updateEdgeAccurateByVertexPk = 3, 116

    updateEdgeByVertexPk = 3, 117

    searchVertexesByIndex = 3, 118

    searchEdgesByIndex = 3, 119
    getCypherTaskAsyncForStatementResultStatus = 4, 120

    retrieveEdgesBySrcDstPk = 4, 121

    deleteEdgesBySrcDstId = 3, 122

    deleteEdgesBySrcDstPk = 3, 123

    executeProcedure = 4, 124

    executeProcedure_g = 4, 125

    searchVertexProperty = 4, 126

    searchEdgeProperty = 4, 127

    stopProcedure = 4, 128

    editPropDesc = 2, 129

    getPropDesc = 4, 130

    editGraphDesc = 2, 131

    getGraphDesc = 4, 132

    editTypeDesc = 2, 133

    getTypeDesc = 4, 134

    globalCypher = 0, 135

    def __init__(self, authLevel, index):
        self.__authLevel = authLevel
        self.__index = index

    def get_auth_level(self):
        return self.__authLevel

    def get_index(self):
        return self.__index
