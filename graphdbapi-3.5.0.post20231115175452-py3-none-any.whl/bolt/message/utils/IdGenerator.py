# -*- coding    : utf-8 -*-
# @Time         : 2021/3/13 12:09
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com
from bolt.meta import import_best

Bits = import_best("bolt.message.utils._Bits", "bolt.message.utils.Bits").Bits
bits = Bits()


class IdGenerator:
    @staticmethod
    def get_edge_id(from_id: int, type_index: int, to_id: int, edge_index: int):
        return bits.get_edge_id(from_id, type_index, to_id, edge_index)

    @staticmethod
    def get_vertex_part(vertex_id : int) -> int:
        part = bits.get_vertex_part(vertex_id)
        if part < 0:
            raise ValueError("vertexId error: %s. cuz part error: %s" %(vertex_id, part) )
        return part

    @staticmethod
    def get_edge_from_id(edge_id: str):
        return bits.get_edge_from_id(edge_id)
