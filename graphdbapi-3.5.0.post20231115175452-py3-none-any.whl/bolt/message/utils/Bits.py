# -*- coding    : utf-8 -*-
# @Time         : 2021/3/13 12:00
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from typing import List
import ctypes

INT64_MAX = (1 << 63) - 1
INT_MAX = (1 << 32) - 1
CHAR = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"]
CHAR2N = {
    "0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
    "A": 10, "B": 11, "C": 12, "D": 13, "E": 14, "F": 15,
    "a": 10, "b": 11, "c": 12, "d": 13, "e": 14, "f": 15
}


class Bits:
    def get_edge_from_id(self, edge_id: str):
        return int(edge_id[:16], 16) & 0xFFFFFFFFFFFFFFFF

    def get_edge_type_index(self, edge_id: str):
        return int(edge_id[16:24], 16) & 0xFFFFFFFF

    def get_edge_to_id(self, edge_id: str):
        return int(edge_id[24:40], 16) & 0xFFFFFFFFFFFFFFFF

    def get_edge_index(self, edge_id: str):
        sub = edge_id[40:]
        if not sub:
            return bytes()
        return self.parse_hex_binary(sub)

    def get_edge_id(self, from_id: int, type_index: int, to_id: int, edge_index: bytes) -> str:
        byte_array = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        self.put_long(byte_array, 0, from_id & 0xFFFFFFFFFFFFFFFF)
        self.put_int(byte_array, 8, type_index & 0xFFFFFFFF)
        self.put_long(byte_array, 12, to_id & 0xFFFFFFFFFFFFFFFF)
        byte_array.extend(edge_index)
        return self.print_hex_binary(byte_array)

    def get_vertex_part(self, vertex_id: int) -> int:
        part = (vertex_id << 24 & 0xFFFFFFFFFFFFFFFF) >> 44 & 0xFFFFFFFF
        if part > INT_MAX:
            return ctypes.c_int32(part).value
        return part

    @staticmethod
    def hash_code(st):
        h = 0
        _len = len(st)
        if h == 0 or _len  > 0:
            for i in range(_len):
                h = 31 * h + ord(st[i])
        return h

    @staticmethod
    def put_long(byte_array: List[int], off: int, val: int) -> None:
        byte_array[off + 7] = val & 0xFF
        byte_array[off + 6] = val >> 8 & 0xFF
        byte_array[off + 5] = val >> 16 & 0xFF
        byte_array[off + 4] = val >> 24 & 0xFF
        byte_array[off + 3] = val >> 32 & 0xFF
        byte_array[off + 2] = val >> 40 & 0xFF
        byte_array[off + 1] = val >> 48 & 0xFF
        byte_array[off]     = val >> 56 & 0xFF

    @staticmethod
    def put_int(byte_array: List[int], off: int, val: int) -> None:
        byte_array[off + 3] = val & 0xFF
        byte_array[off + 2] = val >> 8  & 0xFF
        byte_array[off + 1] = val >> 16  & 0xFF
        byte_array[off] = val >> 24  & 0xFF

    @staticmethod
    def print_hex_binary(byte_array: List[int]) -> str:
        st = ""
        for b in byte_array:
            st += CHAR[(b >> 4) & 0xF]
            st += CHAR[b & 0xF]
        return st

    @staticmethod
    def parse_hex_binary(s: str) -> bytes:
        length = s.__len__()
        if length % 2 != 0:
            raise ValueError("hexBinary needs to be even-length: " + s)
        return bytes([(CHAR2N[s[i * 2]] * 16 + CHAR2N[s[i * 2 + 1]]) & 0xFF for i in range(length//2)])

    @staticmethod
    def get_long(byte_array: List, off: int) -> int:
        vid =  \
            ((byte_array[off + 7] & 0xFF)         +
            ((byte_array[off + 6] & 0xFF) << 8 )  +
            ((byte_array[off + 5] & 0xFF) << 16 ) +
            ((byte_array[off + 4] & 0xFF) << 24 ) +
            ((byte_array[off + 3] & 0xFF) << 32 ) +
            ((byte_array[off + 2] & 0xFF) << 40 ) +
            ((byte_array[off + 1] & 0xFF) << 48 ) +
            (byte_array[off] << 56 & 0xFFFFFFFFFFFFFFFF)) & 0xFFFFFFFFFFFFFFFF
        if vid > INT64_MAX:
            return ctypes.c_int64(vid).value
        return vid
