# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 11:12
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com


class TipsText:
    PARAM_FORMAT = "Parameter [%s] "
    POSITIVE_FORMAT = PARAM_FORMAT + " cannot be smaller than 0"
    NOT_EMPTY_FORMAT = PARAM_FORMAT + " cannot be empty"
    FORMAT_ERROR = PARAM_FORMAT + " incorrect format"
    NOT_PROP_NAME_FORMAT = PARAM_FORMAT + " property name cannot be empty"
    RELEVANCE_PARAM_FORMAT = PARAM_FORMAT + " when it is %s " + PARAM_FORMAT + " must be %s"
    INCLUDE_PARAM_FORMAT = PARAM_FORMAT + " must contain the value of " + PARAM_FORMAT
    PROP_FORMAT = "Property [%s] "
    NOT_PROP_TYPE_FORMAT = PARAM_FORMAT + PROP_FORMAT + " property type cannot be empty"
    NOT_PROP_VALUE_FORMAT = PROP_FORMAT + " value cannot be empty."
    PROP_TYPE_ERROR_FORMAT = PROP_FORMAT + " property type cannot be: %s"
    NOT_PROP_FORMAT = PROP_FORMAT + " doesn't exist"
    PROP_FOUND_FORMAT = PROP_FORMAT + " already exists"

    PARAM_TYPE_ERROR = "Got type [%s] except [%s]"
    PARAM_LIST_ITEM_ERROR = "Got list item type [%s] except [%s]"
    PARAM_DICT_KEY_ERROR = "Got dict key type [%s] except [%s]"
    PARAM_DICT_VALUE_ERROR = "Got dict value type [%s] except [%s]"
    PARAM_SET_VALUE_ERROR = "Got set item type [%s] except [%s]"

    TYPE_FORMAT = "type [%s] "
    NOT_TYPE_FORMAT = TYPE_FORMAT + " doesn't exist"
    TYPE_FOUND_FORMAT = TYPE_FORMAT + " already exists"
    PARAM_TYPE_ERROR_FORMAT = PARAM_FORMAT + " type must be: %s"
    NOT_EQUALS_FORMAT = PARAM_FORMAT + " cannot be equal to " + PARAM_FORMAT
    TYPE_ERROR_FORMAT = PARAM_FORMAT + " data type error"
    DEPTH_ERROR_FORMAT = PARAM_FORMAT + " should be greater than %d"
    DEPTH_LIST_ERROR_FORMAT = PARAM_FORMAT + " the direction list size should be 1, or the same as the depth value"
    NOT_GRAPH_FORMAT = "Graph [%s] doesn't exist"

    DIRECTION_FORMAT = PARAM_FORMAT + " support [BOTH、OUT、IN]"
    PROPERTY_TYPE_FORMAT = PARAM_FORMAT + " support [STRING, BOOLEAN, INT, LONG, DOUBLE, DATETIME, BYTE, CHAR, UINT, FLOAT, BIGDECIMAL, GEOGRAPHICPOINT, CARTESIANPOINT, LIST, SET, MAP]"

    PROPERTY_TYPE_COLLECTION_FORMAT = PARAM_FORMAT + " support [STRING, BOOLEAN, INT, LONG, DOUBLE, DATETIME, BYTE, CHAR, UINT, FLOAT, BIGDECIMAL]"

    FIELD_CAN_NOT_NULL = "Field [%s] cannot be null"
    FIELD_CAN_NOT_NEGATIVE = "Field [%s] cannot be negative"
    FIELD_CAN_NOT_EMPTY = "Field [%s] cannot be empty"
