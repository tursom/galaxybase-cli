from enum import Enum


class TempText(Enum):
    VOID = "~void->"
    CLUSTER_URI_SCHEME = "cluster"
    BOLT_URI_SCHEME = "bolt"
    CLIENT_VERSION = "GraphDb/3.5.0"
