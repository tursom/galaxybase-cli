# -*- coding    : utf-8 -*-
# @Time         : 2021/3/8 11:13
# @Author       : 领悟悟悟
# @Email        : lsz4123@163.com

from enum import Enum


# bolt 中请求参数名，修改后将对应修改bolt所有参数的参数名，index不可重复
class Param(Enum):
    list = 0
    timeout = 1
    defLimit = 2
    cypher = 3
    taskId = 4
    pk = 5
    type = 6
    id = 7
    property = 8
    fromPk = 9
    toPk = 10
    fromType = 11
    toType = 12
    propertyName = 13
    propertyValue = 14
    edgeId = 15
    edgeIds = 16
    txId = 17
    cypherTaskId = 18
    ids = 19
    startId = 20
    depth = 21
    dirList = 22
    vertexConditionList = 23
    edgeConditionList = 24
    edgeTypeFilterList = 25
    limitNeighbor = 26
    limitEdge = 27
    hop = 28
    onlyCount = 29
    returnVertex = 30
    returnEdge = 31
    typeName = 32
    fromToList = 33
    combineKey = 34
    edgeType = 35
    vertexCondition = 36
    edgeCondition = 37
    edgeTypeFilter = 38
    getLoop = 39
    direction = 40
    closenessCentralityParams = 41
    betweennessCentralityParams = 42
    maxDepth = 43
    pageRankParams = 44

    itCount = 45
    dampingFactor = 46
    edgeTypes = 47
    startIds = 48
    isVertex = 49
    endId = 50
    pathEdgeType = 51
    value = 52
    srcId = 53
    dstId = 54
    deleteSelf = 55
    resultTypeSet = 56
    bfsId = 57
    newGraphName = 58
    fromId = 59
    toId = 60
    edgeLimit = 61
    createFrom = 62
    createTo = 63
    allowRepeat = 64
    combinedEdgeTypes = 65
    isIndex = 66
    oldPropName = 67
    newPropName = 68
    direct = 69
    classMap = 70
    newType = 71
    propertyType = 72
    pkName = 73
    graphName = 74
    limitDepth = 75
    dataType = 76
    firstSign = 77
    isMerge = 78
    snowId = 79
    skip = 80
    limit = 81
    secondSign = 82
    methodName = 83
    searchPredicate = 84
    searchOrder = 85
    desc = 86
    isolation = 87

    uri = 1001
    username = 1002
    password = 1003
    groupName = 1004

    def __init__(self, value):
        self.__index = value

    def get_index(self) -> int:
        return self.__index

    def get_index_str(self) -> str:
        return "~" + self.__index.__str__()

    def __str__(self):
        return self.name
