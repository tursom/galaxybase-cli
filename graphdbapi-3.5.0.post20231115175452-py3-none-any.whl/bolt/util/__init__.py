from bolt.compat import urlparse

schema = "schema://"


class DriverUtils:
    @staticmethod
    def resolve_host_name(uri):
        if "://" not in uri:
            uri = schema + uri
        parsed = urlparse(uri)
        return parsed.netloc or parsed.path