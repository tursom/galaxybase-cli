

class VariousMap(dict):
    pass