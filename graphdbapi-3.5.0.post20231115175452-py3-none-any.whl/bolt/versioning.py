#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020/3/31 17:44
# @Author : jimmy



class Version(tuple):

    @classmethod
    def parse(cls, string):
        from unicodedata import category
        parts = []
        last_ch = None
        for ch in string:
            if last_ch is None:
                parts.append([ch])
            elif ch == ".":
                if last_ch in ".-":
                    parts[-1][-1] += "0"
                parts[-1].append("")
            elif ch == "-":
                if last_ch in ".-":
                    parts[-1][-1] += "0"
                parts.append([""])
            else:
                if last_ch not in ".-" and category(ch)[0] != category(last_ch)[0]:
                    parts.append([ch])
                else:
                    parts[-1][-1] += ch
            last_ch = ch
        for part in parts:
            for i, x in enumerate(part):
                try:
                    part[i] = int(x)
                except (ValueError, TypeError):
                    pass
            while len(part) > 1 and not part[-1]:
                part[:] = part[:-1]
        return cls(*map(tuple, parts))

    def __new__(cls, *parts):
        parts = list(parts)
        for i, part in enumerate(parts):
            if not isinstance(part, tuple):
                parts[i] = (part,)
        return super(Version, cls).__new__(cls, parts)

    def __repr__(self):
        return "%s%r" % (type(self).__name__, tuple(self))
