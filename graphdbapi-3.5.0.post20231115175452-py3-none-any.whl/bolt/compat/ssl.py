#!/usr/bin/env python
# -*- encoding: utf-8 -*-

from __future__ import absolute_import

try:
    from ssl import SSLSocket, SSLContext, PROTOCOL_SSLv23, OP_NO_SSLv2, CERT_REQUIRED, HAS_SNI, SSLError
except ImportError:
    SSL_AVAILABLE = False
    SSLSocket = None
    SSLContext = None
    PROTOCOL_SSLv23 = None
    OP_NO_SSLv2 = None
    CERT_REQUIRED = None
    HAS_SNI = None
    SSLError = None
else:
    SSL_AVAILABLE = True
