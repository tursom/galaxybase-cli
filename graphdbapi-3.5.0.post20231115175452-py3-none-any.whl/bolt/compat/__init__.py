#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020/3/31 17:42
# @Author : jimmy
# @File : __init__.py.py
# @Software: PyCharm

map_type = type(map(str, range(0)))


try:
    unicode
except NameError:
    # Python 3

    integer = int
    string = str
    unicode = str
    unichr = chr

    def bstr(x):
        if isinstance(x, bytes):
            return x
        elif isinstance(x, str):
            return x.encode("utf-8")
        else:
            return str(x).encode("utf-8")

    def ustr(x):
        if isinstance(x, bytes):
            return x.decode("utf-8")
        elif isinstance(x, str):
            return x
        else:
            return str(x)

    xstr = ustr

    def memoryview_at(view, index):
        return view[index]

else:
    # Python 2

    integer = (int, long)
    string = (str, unicode)
    unicode = unicode
    unichr = unichr

    def bstr(x):
        if isinstance(x, str):
            return x
        elif isinstance(x, unicode):
            return x.encode("utf-8")
        else:
            return unicode(x).encode("utf-8")

    def ustr(x):
        if isinstance(x, str):
            return x.decode("utf-8")
        elif isinstance(x, unicode):
            return x
        else:
            return unicode(x)

    xstr = bstr

    def memoryview_at(view, index):
        return ord(view[index])

try:
    from multiprocessing import Array, Process
except ImportError:
    # Workaround for Jython

    from array import array
    from threading import Thread as Process

    def Array(typecode, size):
        return array(typecode, [0] * size)


# Obtain a performance timer - this varies by platform and
# Jython support is even more tricky as the standard timer
# does not support nanoseconds. The combination below
# works with Python 2, Python 3 and Jython.
try:
    from java.lang.System import nanoTime
except ImportError:
    JYTHON = False

    try:
        from time import perf_counter
    except ImportError:
        from time import time as perf_counter
else:
    JYTHON = True

    def perf_counter():
        return nanoTime() / 1000000000


# The location of urlparse varies between Python 2 and 3
try:
    from urllib.parse import urlparse, parse_qs
except ImportError:
    from urlparse import urlparse, parse_qs


try:
    from time import perf_counter
except ImportError:
    from time import clock as perf_counter