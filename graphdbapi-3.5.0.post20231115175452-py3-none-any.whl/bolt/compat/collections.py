#!/usr/bin/env python
# -*- encoding: utf-8 -*-

from __future__ import absolute_import

try:
    from collections.abc import MutableSet
except ImportError:
    from collections import MutableSet, OrderedDict
else:
    from collections import OrderedDict
