#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020/3/31 17:43
# @Author : jimmy

from bolt.message.exceptions import TransactionException,ClientException,\
    TransientException,AuthenticationException,\
    DatabaseException,EdgeFoundException,\
    EdgeNotFoundException,FoundException,\
    NotFoundException,ParamException,\
    PkNotFoundException,PropertyFoundException,\
    PropertyNotFoundException,TypeErrorException,\
    TypeFoundException,TypeNotFoundException,\
    ValueFormatException,VertexFoundException,\
    VertexNotFoundException, ServiceUnavailableException


class ProtocolError(Exception):
    """
    Raised when an unexpected or unsupported protocol event occurs.
    """


class ServiceUnavailable(Exception):
    """
    Raised when no database service is available.
    """


class IncompleteCommitError(Exception):
    """
    Raised when a disconnection occurs while still waiting for a commit
    response. For non-idempotent write transactions, this leaves the data
    in an unknown state with regard to whether the transaction completed
    successfully or not.
    """


class ConnectionExpired(Exception):
    """
    Raised when a connection is no longer available for the
    purpose it was originally acquired.
    """


class SecurityError(Exception):
    """
    Raised when an action is denied due to security settings.
    """

class CypherError(Exception):
    """
    Raised when the Cypher engine returns an error to the client.
    """

    message = None
    code = None
    classification = None
    category = None
    title = None
    metadata = None

    @classmethod
    def hydrate(cls, message=None, code=None, **metadata):
        message = message or "An unknown error occurred."
        code = code or "GraphDb.DatabaseError.General.UnknownError"
        try:
            _, classification, category, title = code.split(".")
        except ValueError:
            classification = "DatabaseError"

        inst = cls._extract_error_inst(classification, code, message)

        return inst

    @classmethod
    def _extract_error_inst(cls, classification, code, message):
        parts = code.split(".")
        if len(parts) != 4:
            return DatabaseException(message, code=code)

        if classification == "ClientError":
            if parts[2] == "Statement":
                if parts[3] == "NoGraph":
                    return (db_errors.get(parts[3]) or ClientError)(message, code=code)
                else:
                    return (db_errors.get(parts[3]) or ClientError)(message)
            elif "clienterror.security.unauthorized" in code.lower():
                return AuthenticationException(message, code=code)
            elif "clienterror.transaction.transactiontimedout" in code.lower():
                return TransactionException(message, code=code)
            else:
                return ClientException(message, code=code)

        elif classification == "TransientError":
            return TransientException(message, code=code)

        elif classification == "DatabaseError":
            return DatabaseException(message, code=code)
        else:
            return ClientException(message, code=code)


class ClientError(CypherError):
    """
    The Client sent a bad request - changing the request might yield a successful outcome.
    """


class DatabaseError(CypherError):
    """
    The database failed to service the request.
    """


class TransientError(CypherError):
    """
    The database cannot service the request right now, retrying later might yield a successful outcome.
    """


class DatabaseUnavailableError(TransientError):
    """
    """


class ConstraintError(ClientError):
    """
    """


class CypherSyntaxError(ClientError):
    """
    """


class CypherTypeError(ClientError):
    """
    """


class NotALeaderError(ClientError):
    """
    """


class Forbidden(ClientError, SecurityError):
    """
    """


class ForbiddenOnReadOnlyDatabaseError(Forbidden):
    """
    """


class AuthError(ClientError, SecurityError):
    """
    Raised when authentication failure occurs.
    """


client_errors = {

    # ConstraintError
    "GraphDb.ClientError.Schema.ConstraintValidationFailed": ConstraintError,
    "GraphDb.ClientError.Schema.ConstraintViolation": ConstraintError,
    "GraphDb.ClientError.Statement.ConstraintVerificationFailed": ConstraintError,
    "GraphDb.ClientError.Statement.ConstraintViolation": ConstraintError,

    # CypherSyntaxError
    "GraphDb.ClientError.Statement.InvalidSyntax": CypherSyntaxError,
    "GraphDb.ClientError.Statement.SyntaxError": CypherSyntaxError,

    # CypherTypeError
    "GraphDb.ClientError.Procedure.TypeError": CypherTypeError,
    "GraphDb.ClientError.Statement.InvalidType": CypherTypeError,
    "GraphDb.ClientError.Statement.TypeError": CypherTypeError,

    # Forbidden
    "GraphDb.ClientError.General.ForbiddenOnReadOnlyDatabase": ForbiddenOnReadOnlyDatabaseError,
    "GraphDb.ClientError.General.ReadOnly": Forbidden,
    "GraphDb.ClientError.Schema.ForbiddenOnConstraintIndex": Forbidden,
    "GraphDb.ClientError.Schema.IndexBelongsToConstraint": Forbidden,
    "GraphDb.ClientError.Security.Forbidden": Forbidden,
    "GraphDb.ClientError.Transaction.ForbiddenDueToTransactionType": Forbidden,

    # AuthError
    "GraphDb.ClientError.Security.AuthorizationFailed": AuthError,
    "GraphDb.ClientError.Security.Unauthorized": AuthError,

    # NotALeaderError
    "GraphDb.ClientError.Cluster.NotALeader": NotALeaderError
}

db_errors = {
    "EdgeFound": EdgeFoundException,
    "EdgeNotFound": EdgeNotFoundException,
    "Found": FoundException,
    "NotFound": NotFoundException,
    "NoGraph": DatabaseException,
    "Param": ParamException,
    "PkNotFound": PkNotFoundException,
    "PropertyFound": PropertyFoundException,
    "PropertyNotFound": PropertyNotFoundException,
    "TypeError": TypeErrorException,
    "TypeFound": TypeFoundException,
    "TypeNotFound": TypeNotFoundException,
    "ValueFormat": ValueFormatException,
    "VertexFound": VertexFoundException,
    "VertexNotFound": VertexNotFoundException,
}

transient_errors = {

    # DatabaseUnavailableError
    "GraphDb.TransientError.General.DatabaseUnavailable": DatabaseUnavailableError
}
