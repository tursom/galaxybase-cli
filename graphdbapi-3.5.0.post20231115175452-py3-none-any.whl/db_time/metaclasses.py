#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020/4/1 10:39
# @Author : jimmy



class DateType(type):

    def __getattr__(cls, name):
        try:
            return {
                "fromisoformat": cls.from_iso_format,
                "fromordinal": cls.from_ordinal,
                "fromtimestamp": cls.from_timestamp,
                "utcfromtimestamp": cls.utc_from_timestamp,
            }[name]
        except KeyError:
            raise AttributeError("%s has no attribute %r" % (cls.__name__, name))


class TimeType(type):

    def __getattr__(cls, name):
        try:
            return {
                "fromisoformat": cls.from_iso_format,
                "utcnow": cls.utc_now,
            }[name]
        except KeyError:
            raise AttributeError("%s has no attribute %r" % (cls.__name__, name))


class DateTimeType(type):

    def __getattr__(cls, name):
        try:
            return {
                "fromisoformat": cls.from_iso_format,
                "fromordinal": cls.from_ordinal,
                "fromtimestamp": cls.from_timestamp,
                "strptime": cls.parse,
                "today": cls.now,
                "utcfromtimestamp": cls.utc_from_timestamp,
                "utcnow": cls.utc_now,
            }[name]
        except KeyError:
            raise AttributeError("%s has no attribute %r" % (cls.__name__, name))
