#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2020/4/1 10:38
# @Author : jimmy


from __future__ import print_function


def main():
    from db_time import Clock, DateTime, UnixEpoch
    clock = Clock()
    time = clock.utc_time()
    print("Using %s" % type(clock).__name__)
    print("%s -> %s" % (time, DateTime.from_clock_time(time, UnixEpoch)))


if __name__ == "__main__":
    main()
